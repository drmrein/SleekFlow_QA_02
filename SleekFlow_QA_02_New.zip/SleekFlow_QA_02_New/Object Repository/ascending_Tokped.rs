<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ascending_Tokped</name>
   <tag></tag>
   <elementGuidId>6348d957-b96a-455c-b1a4-247f4fab9415</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//li[contains(@class,'css-d2qf6r e83okfj5')]//button[contains(@class, 'css-nzq9o0')])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>

package replaceDate

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.text.SimpleDateFormat

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

import keys.randomString as GenerateRandomString

public class handlePayroll {
	//function yang dipanggil
	@Keyword
	public def updateFileDate(String dirPath, String date, String param = "bba", String dateformat = "yyyyMMdd") {
		//inisialisasi Folder yang ingin di cek
		File dir = new File(dirPath)
		HashMap<String, String> resultMap =  new HashMap<String, String>();
		//generate tanggal hari ini terus di assign ke variable todayDate
		String todayDate = processDate(date, dateformat)
		//cek apakah File ini termasuk folder/directory
		if(dir.isDirectory()) {
			//list file yang ada di dalam folder
			File[] files = dir.listFiles()
			for (File f : files) {
				//cek apakah file ini merupakan file dan buka directory
				if (f.isFile()) {
					//ambil nama file contoh hasil: contohfile.txt
					String fileName = f.getName()
					//memanggil method getFileFormat untuk mengambil nilai file format dari file
					String format = getFileFormat(fileName)
					// cek file format seharusnya csv atau txt
					if(("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format)) && fileName.toLowerCase().contains(param)) {
						//memanggil method processfile dengan memasukkan input tanggal dan File
						replaceDate(todayDate, f)
						WebUI.comment("Success updating " +fileName+ " with new date: " + todayDate)
					}
				}
			}
		}
		return resultMap
	}
	//method untuk mengambil format file
	def getFileFormat(String fileName) {
		return fileName.substring(fileName.lastIndexOf(".")+1)
	}
	//method untuk membace file
	def readFile(File f) {
		String content = null
		FileInputStream fis = null
		try {
			fis= new FileInputStream(f)
			ByteArrayOutputStream baos = new ByteArrayOutputStream()
			int b = fis.read()
			while (b != -1) {
				baos.write(b)
				b = fis.read()
			}
			content = new String(baos.toByteArray())
		} catch(Exception e) {
		} finally {
			if (fis!=null) {
				try {
					fis.close();
				}catch (Exception e) {
				}
			}
		}
		return content
	}
	//method untuk menulis content file
	def writeFile(String content, File f) {
		FileOutputStream fos= null
		try {
			fos = new FileOutputStream(f)
			fos.write(content.getBytes())
			fos.flush()
		} catch (Exception e) {
		} finally {
			if (fos != null) {
				try {
					fos.close()
				} catch (Exception e) {
				}
			}
		}
	}
	//method untuk mengganti nama file
	def renameFile(File f1, String newFileName) {
		File fNew = new File(newFileName)
		//cek apakah nama file baru sudah ada
		if (fNew.exists())
			throw new java.io.IOException("file exists");

		// Rename file (or directory)
		boolean success = f1.renameTo(fNew);

		if (!success) {
			// File was not successfully renamed
			WebUI.comment("File was not successfully renamed")
		}else {
			// File was successfully renamed
			WebUI.comment("File was successfully renamed")
		}
	}
	//method untuk mengganti nama file
	String generatedRandomID(String initial, String date) {
		//mengimport method dari custom keyword keys.randomString
		GenerateRandomString randomString = new GenerateRandomString()

		String result = initial + " " + date + " "

		result = randomString.generateRandomString(result, "first", 2)
		return result
	}

	String processDate(String date, String format = "yyyyMMdd") {
		String valueDate = null
		SimpleDateFormat sdf = new SimpleDateFormat(format)
		if ("today".equalsIgnoreCase(date)) {
			valueDate = sdf.format(new Date())
		} else if ("next day".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, 1)
			valueDate = sdf.format(cal.getTime())
		} else if ("yesterday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, -1)
			valueDate = sdf.format(cal.getTime())
		} else {
			valueDate = date
		}

		return valueDate
	}

	def replaceDate(String date, File f) {
		//mengambil format file
		String fileFormat = getFileFormat(f.getName())
		//membaca content file lalu di assign ke variable content
		String content = readFile(f)
		//memisahkan tiap line pada file
		String[] lines = content.split("\n")

		//membuat variable untuk menampung nilai baru
		def newContent = new StringBuilder()
		for (int i = 0; i < lines.length; i++) {
			//melakukan pengecekan format file
			if(fileFormat.equalsIgnoreCase("csv")) {
				//mengambil nilai baris pada file sesuai dengan urutan index (0 == line 1 pada file)
				String currentContent = lines[i]
				//memisahkan tiap nilai menjadi field dengan indikator pemisah ,
				String[] fields = currentContent.split(",")
				for (int j = 0; j < fields.length; j++) {
					//mengambil nilai field sesuai dengan urutan index (0 == line 1 pada file)
					String currentFields = fields[j]
					if(j==0){
						newContent += currentFields
					}else if(i==0 && j==2) {
						//melakukan update pada tanggal di baris header
						newContent += "," + date
					}else{
						//mencetak ulang konten yang sama pada field lain
						newContent += "," + currentFields
					}
				}
			}else if(fileFormat.equalsIgnoreCase("txt")) {
				//mengambil nilai baris pada file sesuai dengan urutan index (0 == line 1 pada file)
				String currentContent = lines[i]
				if(i==0) {
					//jika file memiliki panjang baris lebih dari 255 dan kurang dari 282 maka nilai eInvoice ID diganti dengan eInvoiceID baru
					//					currentContent = newID + currentContent.substring(currentContent.indexOf(newID.length())+newID.length(), currentContent.length())
					currentContent = currentContent.substring(0, 2) + date + currentContent.substring(date.length()+2, currentContent.length())

				}
				newContent += currentContent
			}
			if(i != lines.length-1) {
				newContent +="\n"
			}

		}
		writeFile(newContent, f)

	}

}

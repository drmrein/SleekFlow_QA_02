package replaceDate

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class SpecialRateRefNo {

	def readFile(String path) {
		def content = null
		FileInputStream fis= null
		try {
			File f = new File(path)
			if (f.isFile()) {
				fis = new FileInputStream(f)

				ByteArrayOutputStream baos = new ByteArrayOutputStream()
				int b = fis.read()
				while (b != -1) {
					baos.write(b)
					b = fis.read()
				}
				content = new String(baos.toByteArray())
			}
		} catch(Exception e) {
			println("Failed to read " + path)
		} finally {
			if (fis != null) {
				try {
					fis.close()
				} catch (Exception e) {
					println("Failed to close "+ path)
				}
			}
		}
		return content
	}

	def writeFile(String content, String path) {
		FileOutputStream fos = null;
		try {
			File file = new File(path)
			fos = new FileOutputStream(file)
			fos.write(content.getBytes())
			fos.flush()
		} catch (Exception e) {
			println("Failed to write file " + path+ ", " + e.getMessage())
		} finally {
			if (fos != null) {
				try {
					fos.close()
				} catch (Exception e) {
					println("Failed to close file " + path)
				}
			}
		}
	}

	@Keyword
	def replaceReferenceNo(String filePath, int indexRefNo) {
		// def elRefNo = new TestObject()
		// elRefNo.addProperty("xpath", ConditionType.EQUALS, "//*[@id='specialRateForm']/div[2]/label[3]")
		// def refNo = elRefNo.findPropertyValue("text")
		// println(String.format("refNo: %s", refNo))

		WebDriver driver = DriverFactory.getWebDriver()
		def loginFrame = driver.findElement(By.xpath("//*[@id='login']"))
		driver.switchTo().frame(loginFrame)

		def mainFrame = driver.findElement(By.xpath("//iframe[@id='mainFrame']"))
		driver.switchTo().frame(mainFrame)

		def elRefNo = driver.findElement(By.xpath("//*[@id='specialRateForm']")) // /div[2]/label[3]
		// println("elRefNo: " + elRefNo)
		def arrDiv = elRefNo.findElements(By.tagName("div"))
		// println("arrDiv.size(): " + arrDiv.size())

//		for (int i = 0; i < arrDiv.size(); i++) {
//		 	def o =arrDiv[i]
//			println("["+i+"]: " +o.text)
//		}

//		def arrLabel = arrDiv[4].findElements(By.tagName("label"))
//		// println("arrLabel.size(): " + arrLabel.size())
//		if (arrLabel.size() < 1 || !arrLabel[0].text.toLowerCase().contains("ef")) {
//			arrLabel = arrDiv[1].findElements(By.tagName("label"))
//		}
		def refNo = null
//		if (arrLabel[2] !=null) {
//			refNo = arrLabel[2].text
//		} else {
//			def arrInput = arrDiv[0].findElements(By.tagName("input"))
//		}
		
		def arrInput = arrDiv[0].findElements(By.tagName("input"))
		if (arrInput.size() > 0) {
			refNo = arrInput[0].getAttribute("value")
		} else {
			def arrLabel = arrDiv[4].findElements(By.tagName("label"))
			// println("arrLabel.size(): " + arrLabel.size())
			if (arrLabel.size() < 1 || !arrLabel[0].text.toLowerCase().contains("ef")) {
				arrLabel = arrDiv[1].findElements(By.tagName("label"))
			}
			if (arrLabel[2] !=null) {
				refNo = arrLabel[2].text
			}
		}
		
		println("refNo: " + refNo)

		def content = readFile(filePath)

		def separator = null
		if (filePath.toLowerCase().endsWith(".txt")) {
			separator = ";"
		} else {
			separator = ","
		}
		
		// replace file content
		def newContent = new StringBuilder()
		def lines = content.toString().split("\r")
		println("lines.length: " + lines.length)
		for (int i = 0; i < lines.length; i++) {
			if (i > 0) {
				newContent.append("\r")
			}
			def line = lines[i]
			if (i == 1) {
				def fields = line.toString().split(separator)
				println("fields.length: " + fields.length)
				def newLine = new StringBuilder()
				for (int j = 0; j < fields.length; j++) {
					def field = fields[j]
					//if (j == (fields.length - 2)) {
					if (j == (indexRefNo - 1)) {
						println("appended refNo")
						field = refNo
					}
					if (j > 0) {
						newLine.append(separator)
					}
					newLine.append(field)
				}
				line = newLine.toString()
			}
			newContent.append(line);
		}

		println(String.format("refNo: %s", refNo))
		println(String.format("content: %s", content))
		println(String.format("newContent: %s", newContent))

		writeFile(newContent.toString(), filePath)
		driver.switchTo().defaultContent()

	}
}

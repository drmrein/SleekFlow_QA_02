package replaceDate

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.text.SimpleDateFormat

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

import keys.randomString as GenerateRandomString

public class handleEinvoice {
	//function yang dipanggil
	@Keyword
	public def updateFile(String dirPath) {
		//inisialisasi Folder yang ingin di cek
		File dir = new File(dirPath)
		HashMap<String, String> resultMap =  new HashMap<String, String>();
		//generate tanggal hari ini terus di assign ke variable todayDate
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		String todayDate = sdf.format(new Date())
		//cek apakah File ini termasuk folder/directory
		if(dir.isDirectory()) {
			//list file yang ada di dalam folder
			File[] files = dir.listFiles()
			for (File f : files) {
				//cek apakah file ini merupakan file dan buka directory
				if (f.isFile()) {
					//ambil nama file contoh hasil: contohfile.txt
					String fileName = f.getName()
					//memanggil method getFileFormat untuk mengambil nilai file format dari file
					String format = getFileFormat(fileName)
					// cek file format seharusnya csv atau txt
					if(("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format))) {
						//memanggil method processfile dengan memasukkan input tanggal dan File
						processFile(todayDate, f)
						//membuat variable untuk menyimpan nama file sebelum di update
						String oldFileName = fileName
						//mengganti nama file
						if(fileName.contains("_UPDATED")) {
							fileName = fileName.substring(0, fileName.indexOf("_UPDATED"))
							oldFileName = fileName
						}else {
							fileName = fileName.substring(0, fileName.lastIndexOf("."))
							oldFileName = fileName
						}
						String newFilePath = fileName + "_UPDATED"
						newFilePath = dirPath+"/" + generatedRandomID(newFilePath, todayDate) + "." + format
						renameFile(f, newFilePath)
						WebUI.comment("original: "+oldFileName)
						resultMap.put(oldFileName, newFilePath)

					}
				}
			}
		}
		return resultMap
	}
	//method untuk mengambil format file
	def getFileFormat(String fileName) {
		return fileName.substring(fileName.lastIndexOf(".")+1)
	}
	//method untuk membace file
	def readFile(File f) {
		String content = null
		FileInputStream fis = null
		try {
			fis= new FileInputStream(f)
			ByteArrayOutputStream baos = new ByteArrayOutputStream()
			int b = fis.read()
			while (b != -1) {
				baos.write(b)
				b = fis.read()
			}
			content = new String(baos.toByteArray())
		} catch(Exception e) {
		} finally {
			if (fis!=null) {
				try {
					fis.close();
				}catch (Exception e) {
				}
			}
		}
		return content
	}
	//method untuk menulis content file
	def writeFile(String content, File f) {
		FileOutputStream fos= null
		try {
			fos = new FileOutputStream(f)
			fos.write(content.getBytes())
			fos.flush()
		} catch (Exception e) {
		} finally {
			if (fos != null) {
				try {
					fos.close()
				} catch (Exception e) {
				}
			}
		}
	}
	//method untuk mengganti nama file
	def renameFile(File f1, String newFileName) {
		File fNew = new File(newFileName)
		//cek apakah nama file baru sudah ada
		if (fNew.exists())
			throw new java.io.IOException("file exists");

		// Rename file (or directory)
		boolean success = f1.renameTo(fNew);

		if (!success) {
			// File was not successfully renamed
			WebUI.comment("File was not successfully renamed")
		}else {
			// File was successfully renamed
			WebUI.comment("File was successfully renamed")
		}
	}
	//method untuk mengganti nama file
	String generatedRandomID(String initial, String date) {
		//mengimport method dari custom keyword keys.randomString
		GenerateRandomString randomString = new GenerateRandomString()

		String result = initial + " " + date + " "

		result = randomString.generateRandomString(result, "first", 2)
		return result
	}

	def processFile(String date, File f) {
		//mengambil format file
		String fileFormat = getFileFormat(f.getName())
		//membaca content file lalu di assign ke variable content
		String content = readFile(f)
		//memisahkan tiap line pada file
		String[] lines = content.split("\n")

		//membuat variable untuk menampung nilai baru
		def newContent = new StringBuilder()
		for (int i = 0; i < lines.length; i++) {
			//generate random eInvoice ID baru
			String newID = generatedRandomID("eInvoice", date)
			//melakukan pengecekan format file
			if(fileFormat.equalsIgnoreCase("csv")) {
				//mengambil nilai baris pada file sesuai dengan urutan index (0 == line 1 pada file)
				String currentContent = lines[i]
				//memisahkan tiap nilai menjadi field dengan indikator pemisah ,
				String[] fields = currentContent.split(",")
				for (int j = 0; j < fields.length; j++) {
					//mengambil nilai field sesuai dengan urutan index (0 == line 1 pada file)
					String currentFields = fields[j]
					if(j==0){
						//jika field pertama maka nilai diganti menjadi eInvoice ID baru
						currentFields = ""
						newContent += newID
					}else if((fields.length == 8) && j==5) {
						//jika file memiliki 8 field maka nilai field ke 5 diganti dengan today date
						newContent += "," + date
					}else{
						//mencetak ulang konten yang sama pada field lain
						newContent += "," + currentFields
					}
				}
			}else if(fileFormat.equalsIgnoreCase("txt")) {
				//mengambil nilai baris pada file sesuai dengan urutan index (0 == line 1 pada file)
				String currentContent = lines[i]
				if(currentContent.length() > 255 &&currentContent.length() <= 282) {
					//jika file memiliki panjang baris lebih dari 255 dan kurang dari 282 maka nilai eInvoice ID diganti dengan eInvoiceID baru
					//					currentContent = newID + currentContent.substring(currentContent.indexOf(newID.length())+newID.length(), currentContent.length())
					currentContent = newID + currentContent.substring(currentContent.indexOf(0)+newID.length()+1)

				}else if(currentContent.length()<=255){
					//jika file memiliki panjang baris 255 maka nilai tanggal pada file diganti menjadi today date

					currentContent = newID + currentContent.substring(currentContent.indexOf(0)+newID.length()+1, 139) + date + currentContent.substring(147, currentContent.length())

				}
				newContent += currentContent
			}
			if(i != lines.length-1) {
				newContent +="\n"
			}

		}
		writeFile(newContent, f)

	}


}

package replaceDate

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.text.SimpleDateFormat

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
//import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class ReplaceDate {
	@Keyword
	public def replaceDateStanding(String date, String dirPath) {
		File dir = new File(dirPath)
		if(dir.isDirectory()) {
			File[] files = dir.listFiles()
			for (File f : files) {
				if (f.isFile()) {
					String fileName = f.getName()
					String format = getFileFormat(fileName)
					if(("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format)) && fileName.toLowerCase().contains("standing")) {
						processFile(date, f)
					}
				}
			}
		}
	}

	@Keyword
	public def replaceDateforSeparate(String date, String dirPath) {
		File dir = new File(dirPath)
		if(dir.isDirectory()) {
			File[] files = dir.listFiles()
			for (File f : files) {
				if (f.isFile()) {
					String fileName = f.getName()
					String format = getFileFormat(fileName)
					if("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format)) {
						processFileforSeparate(date, f)
					}
				}
			}
		}
	}

	@Keyword
	public def replaceDateWithParameter(String date, String dirPath, int colIndex, int rowIndex) {
		File dir = new File(dirPath)
		println("dir: "+ dir.getAbsolutePath() + " " + dir.isDirectory());
		if(dir.isDirectory()) {
			File[] files = dir.listFiles()
			for (File f : files) {
				if (f.isFile()) {
					String fileName = f.getName()
					String format = getFileFormat(fileName)
					println(String.format("fileName: %s,format: %s", fileName, format))
					if("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format)) {
						processFileWithParameter(date, f, colIndex, rowIndex)
					}
				}
			}
		}
	}


	@Keyword
	public def replaceDateforRecurring(String dirPath) {
		File dir = new File(dirPath)
		if(dir.isDirectory()) {
			File[] files = dir.listFiles()
			for (File f : files) {
				if (f.isFile()) {
					String fileName = f.getName()
					String format = getFileFormat(fileName)
					if(("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format))&& fileName.toLowerCase().contains("recurring")) {
						processFileRecurring(f)
					}
				}
			}
		}
	}

	@Keyword
	public def replaceDateSeparatedStandingImmediate(String date, String dirPath) {
		File dir = new File(dirPath)
		if(dir.isDirectory()) {
			File[] files = dir.listFiles()
			for (File f : files) {
				if (f.isFile()) {
					String fileName = f.getName()
					String format = getFileFormat(fileName)
					if(("csv".equalsIgnoreCase(format)||
					"txt".equalsIgnoreCase(format)) && fileName.contains("Sep")) {
						processFileSeparatedStandingImmediate(date, f)
					}
				}
			}
		}
	}

	def getFileFormat(String fileName) {
		return fileName.substring(fileName.lastIndexOf(".")+1)
	}

	def readFile(File f) {
		String content = null
		FileInputStream fis = null
		try {
			fis= new FileInputStream(f)
			ByteArrayOutputStream baos = new ByteArrayOutputStream()
			int b = fis.read()
			while (b != -1) {
				baos.write(b)
				b = fis.read()
			}
			content = new String(baos.toByteArray())
		} catch(Exception e) {
		} finally {
			if (fis!=null) {
				try {
					fis.close();
				}catch (Exception e) {
				}
			}
		}
		return content
	}

	def writeFile(String content, File f) {
		FileOutputStream fos= null
		try {
			fos = new FileOutputStream(f)
			fos.write(content.getBytes())
			fos.flush()
		} catch (Exception e) {
		} finally {
			if (fos != null) {
				try {
					fos.close()
				} catch (Exception e) {
				}
			}
		}
	}

	def processFile(String date, File f) {
		String SEPARATOR = "txt".equalsIgnoreCase(getFileFormat(f.getName())) ? ";" : ","
		String content = readFile(f)
		String[] lines = content.split("\n")
		String firstLine = lines[0]
		String[] fields = firstLine.split(SEPARATOR)
		String valueDate = null
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		if ("today".equalsIgnoreCase(date)) {
			valueDate = sdf.format(new Date())
		} else if ("nextday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, 1)
			valueDate = sdf.format(cal.getTime())
		} else if ("prevday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, -11)
			valueDate = sdf.format(cal.getTime())
		} else {
			valueDate = date
		}
		firstLine = fields[0]
		for (int i = 1; i < fields.length; i++) {
			if((i==3 && !f.getName().contains("MFTU") )|| (i == 2 && f.getName().contains("MFTU"))){
				firstLine += SEPARATOR + valueDate
			}else{
				firstLine += SEPARATOR + fields[i]
			}
		}
		String newContent =firstLine
		for (int i = 1; i < lines.length; i++) {
			newContent +="\n" + lines[i]
		}
		writeFile(newContent, f)
		//
	}

	def processFileSeparatedStandingImmediate(String date, File f) {
		String SEPARATOR = "txt".equalsIgnoreCase(getFileFormat(f.getName())) ? ";" : ","
		String content = readFile(f)
		String[] lines = content.split("\n")
		String firstLine = lines[0]
		String[] fields = firstLine.split(SEPARATOR)
		String valueDate = null
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		if ("today".equalsIgnoreCase(date)) {
			valueDate = sdf.format(new Date())
		} else if ("nextday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, 1)
			valueDate = sdf.format(cal.getTime())
		} else if ("prevday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, -11)
			valueDate = sdf.format(cal.getTime())
		} else {
			valueDate = date
		}

		def newContent = new StringBuilder()
		for (int i = 0; i < lines.length; i++) {

			String[] currfields = lines[i].split(SEPARATOR)
			for(int l = 0; l < currfields.length; l++) {
				if(l==0){
					newContent.append(currfields[l])
				}else if((l==6 && currfields[2] == "2") || (l==9 && currfields[2] == "1")){
					newContent.append(SEPARATOR).append(valueDate)
				}else{
					newContent.append(SEPARATOR).append(currfields[l])
				}
			}
			newContent.append("\n")
		}
		writeFile(newContent.toString(), f)
		//
	}



	def processFileforSeparate(String date, File f) {
		String SEPARATOR = "txt".equalsIgnoreCase(getFileFormat(f.getName())) ? ";" : ","
		String content = readFile(f)
		String[] lines = content.split("\n")
		String firstLine = lines[0]
		String[] fields = firstLine.split(SEPARATOR)
		String valueDate = null
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		if ("today".equalsIgnoreCase(date)) {
			valueDate = sdf.format(new Date())
		} else if ("nextday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, 1)
			valueDate = sdf.format(cal.getTime())
		} else if ("prevday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, -1)
			valueDate = sdf.format(cal.getTime())
		} else {
			valueDate = date
		}
		firstLine = fields[0] + SEPARATOR + fields[1] + SEPARATOR + valueDate
		for (int i = 3; i < fields.length; i++) {
			firstLine += SEPARATOR + fields[i]
		}
		String newContent =firstLine
		for (int i = 1; i < lines.length; i++) {
			newContent +="\n" + lines[i]
		}
		writeFile(newContent, f)
		//
	}

	def processFileWithParameter(String date, File f, int colIndex, int rowIndex){

		String SEPARATOR = "txt".equalsIgnoreCase(getFileFormat(f.getName())) ? ";" : ","
		String content = readFile(f)
		println("content: " + content + "\n" + content.indexOf("\n") + "\n" + content.indexOf("\r") + " " + (content.bytes[52]) + " "  + (content.bytes[53]) +" " + (content.bytes[54]))
		String[] lines = content.split(new String((char) 13))
		String firstLine = lines[0]
		String valueDate = null
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		if ("today".equalsIgnoreCase(date)) {
			valueDate = sdf.format(new Date())
		} else if ("nextday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, 1)
			valueDate = sdf.format(cal.getTime())
		} else if ("prevday".equalsIgnoreCase(date)) {
			Calendar cal= Calendar.getInstance()
			cal.add(Calendar.DATE, -1)
			valueDate = sdf.format(cal.getTime())
		} else {
			valueDate = date
		}
		String fileName = f.getName()
		def separator = null
		if (fileName.toLowerCase().endsWith(".txt")) {
			separator = ";"
		} else {
			separator = ","
		}

		def newContent = new StringBuilder()

		println("lines.length: " + lines.length)
		for (int i = 0; i < lines.length; i++) {
			if (i > 0) {
				newContent.append(new String((char) 13))
			}
			def line = lines[i]
			if (i == (rowIndex-1)) {
				def fields = line.toString().split(separator)
				println("fields.length: " + fields.length)
				def newLine = new StringBuilder()
				for (int j = 0; j < fields.length; j++) {
					def field = fields[j]
					//if (j == (fields.length - 2)) {
					if (j == (colIndex - 1)) {
						println("appended refNo")
						field = valueDate
					}
					if (j > 0) {
						newLine.append(separator)
					}
					newLine.append(field)
				}
				line = newLine.toString()
			}
			newContent.append(line);
		}

		writeFile(newContent.toString(), f)
	}

	def processFileRecurring(File f) {
		String SEPARATOR = "txt".equalsIgnoreCase(getFileFormat(f.getName())) ? ";" : ","
		String content = readFile(f)
		String[] lines = content.split("\n")
		String firstLine = lines[0]
		String[] fields = firstLine.split(SEPARATOR)

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd")
		String fromValueDate = sdf.format(new Date())
		Calendar cal= Calendar.getInstance()
		cal.add(Calendar.DATE, 1)
		String toValueDate = sdf.format(cal.getTime())

		firstLine = fields[0]
		for (int i = 1; i < fields.length; i++) {
			if(i==6){
				firstLine += SEPARATOR + fromValueDate
			}else if(i == 7){
				firstLine += SEPARATOR + toValueDate
			}else{
				firstLine += SEPARATOR + fields[i]
			}
		}
		String newContent =firstLine
		for (int i = 1; i < lines.length; i++) {
			newContent +="\n" + lines[i]
		}
		writeFile(newContent, f)
		//
	}
}
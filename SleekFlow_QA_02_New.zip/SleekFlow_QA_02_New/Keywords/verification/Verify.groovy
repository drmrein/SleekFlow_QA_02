package verification

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.util.KeywordUtil


public class Verify {

	@Keyword
	def verifyFileIsDownloaded(String fileName){

		String downloadPath = System.getProperty("user.home") + '\\Downloads\\';

		def lastFilepath = getLatestFilefromDir(downloadPath)
		lastFilepath = lastFilepath.getName()
		println(lastFilepath)

		if (lastFilepath.contains(fileName.substring(0, fileName.indexOf('.'))) && lastFilepath.contains(fileName.substring(fileName.lastIndexOf(".")))) {
			KeywordUtil.logInfo("file is downloaded")
		}else{
			KeywordUtil.markFailedAndStop("file is not found")
		}
	}

	/* Get the latest file from a specific directory*/
	private File getLatestFilefromDir(String dirPath){

		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}
		Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

	@Keyword
	def verifyFilePartialNameString(String fileName){

		String downloadPath = System.getProperty("user.home") + '\\Downloads\\';

		def lastFilepath = getLatestFilefromDir(downloadPath)
		lastFilepath = lastFilepath.toString()
		println(lastFilepath)

		if (lastFilepath.contains(fileName.substring(0, fileName.indexOf('.'))) && lastFilepath.contains(fileName.substring(fileName.lastIndexOf(".")))) {
			KeywordUtil.logInfo("file is downloaded")
		}else{
			KeywordUtil.markFailedAndStop("file is not found")
		}
	}
}

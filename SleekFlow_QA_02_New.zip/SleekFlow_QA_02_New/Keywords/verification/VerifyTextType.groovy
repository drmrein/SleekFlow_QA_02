package verification

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.util.KeywordUtil

public class VerifyTextType {

	@Keyword
	def verifyTextIsNumerical(String text, Integer indexBegin = 0 , Integer indexEnd = 0){
		String target = text
		if(indexBegin != 0 && indexEnd != 0){
			target = text.substring(indexBegin-1, indexEnd)
		}else if(indexBegin != 0 && indexEnd ==0){
			target = text.substring(indexBegin-1, text.length())
		}
		Boolean isNumeric = true;
		try {
			double d = Double.parseDouble(target);
		} catch (NumberFormatException nfe) {
			return false;
		}

		if(isNumeric == true){
			KeywordUtil.markPassed("$target is numeric")
		}else{
			KeywordUtil.markFailed("$target is not numeric")
		}
	}

	@Keyword
	def verifyTextIsAlphabetical(String text, Integer indexBegin = 0, Integer indexEnd = 0){
		String target = text
		if(indexBegin != 0 && indexEnd != 0){
			target = text.substring(indexBegin-1, indexEnd)
		}else if(indexBegin != 0 && indexEnd ==0){
			target = text.substring(indexBegin-1, text.length())
		}
		Boolean isAlphabetical = true;
		try {
			isAlphabetical = target.matches("[a-zA-Z]+");
		} catch (NumberFormatException nfe) {
			return false;
		}

		if(isAlphabetical == true){
			KeywordUtil.markPassed("$target contain alphabet only")
		}else{
			KeywordUtil.markFailed("$target do not containing alphabet only")
		}
	}

	@Keyword
	def verifyTextIsAlphaNumeric(String text, Integer indexBegin = 0, Integer indexEnd = 0){
		String target = text
		if(indexBegin != 0 && indexEnd != 0){
			target = text.substring(indexBegin-1, indexEnd)
		}else if(indexBegin != 0 && indexEnd ==0){
			target = text.substring(indexBegin-1, text.length())
		}
		Boolean isAlphanumeric = true;
		try {
			isAlphanumeric = target.matches("^[a-zA-Z0-9]*");
		} catch (NumberFormatException nfe) {
			return false;
		}

		if(isAlphabetical == true){
			KeywordUtil.markPassed("$target is Alphanumeric ")
		}else{
			KeywordUtil.markFailed("$target is not Alphanumeric ")
		}
	}
}

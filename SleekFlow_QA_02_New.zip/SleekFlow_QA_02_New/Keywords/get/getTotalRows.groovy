package get

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.webui.driver.DriverFactory

public class getTotalRows {
	KeywordLogger log = new KeywordLogger()
	@Keyword
	def countRowsPerPage(String xpath){

		WebDriver driver = DriverFactory.getWebDriver()

		//Find the table element on the page
		WebElement Webtable=driver.findElement(By.xpath(xpath));

		//Determine the number of elements in the table
		List TotalRowCount=Webtable.findElements(By.xpath(xpath));

		//Get the size of the List, this is the number of rows
		int totalNumberOfRows=TotalRowCount.size()

		return totalNumberOfRows

	}
}

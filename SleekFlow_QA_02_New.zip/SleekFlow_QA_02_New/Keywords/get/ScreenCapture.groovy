package get

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData

import org.apache.commons.lang.SystemUtils

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData

import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import internal.GlobalVariable
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW

import tcVariable.tcVariable as DynamicVar

public class ScreenCapture {
	DynamicVar dynamicVar = new DynamicVar()


	@Keyword
	def getEntirePage(String filename, Boolean generatedValue = true){
		String currentTc = dynamicVar.getVariable("currTestCaseID")
		String stepIndex = dynamicVar.getVariable("currTestCaseIndex")
		List<String> listStepGroup = dynamicVar.getVariable("currTestCaseStepGroup")
		String reportpath = RunConfiguration.getReportFolder()
		if(generatedValue == true) {
			String tcID = currentTc.substring(currentTc.lastIndexOf("/")+1)
			if(filename.contains("Step Group") || filename.contains("Verify Group")){
				String theFileName = filename.substring(filename.lastIndexOf("/")+1).trim()
				String lastFolderFull = filename.substring(0, filename.lastIndexOf("/")).trim()
				String lastFolder = lastFolderFull.substring(lastFolderFull.lastIndexOf("/")+1).trim()+"_"+stepIndex
		
				String newFileName = tcID+"/"+tcID+"_"+stepIndex+"_"+lastFolder + ".png"
				Integer intStepIndex = Integer.valueOf(stepIndex) + 1
				stepIndex = String.valueOf(intStepIndex)
				dynamicVar.setVariable('currTestCaseIndex', stepIndex)
				reportpath = reportpath + '/'+newFileName
			}else {
				filename = tcID + "/" + tcID + "_" + stepIndex + ".png"
		
				reportpath = reportpath + '/'+filename
				Integer intStepIndex = Integer.valueOf(stepIndex) + 1
				stepIndex = String.valueOf(intStepIndex)
				dynamicVar.setVariable('currTestCaseIndex', stepIndex)
			}
		}else {
			if(filename.contains("Step Group")){

				WebUI.comment(RunConfiguration.getExecutionSource().toString())
				String theFileName = filename.substring(filename.lastIndexOf("/")+1).trim()
				String lastFolderFull = filename.substring(0, filename.lastIndexOf("/")).trim()
				String lastFolder = lastFolderFull.substring(lastFolderFull.lastIndexOf("/")+1).trim()
				String secondLastFolderFull = lastFolderFull.substring(0, lastFolderFull.lastIndexOf("/")).trim()
				String newFileName = secondLastFolderFull +"/"+ currentTc+"/"+lastFolder+"/"+theFileName
				WebUI.comment(newFileName)
				reportpath = RunConfiguration.getReportFolder() + '/'+newFileName
			}
		}

		println reportpath
		List<TestObject> ignoredObject = []

		if(GlobalVariable.IgnoredElement != null){
			List<String> objectCollection = GlobalVariable.IgnoredElement
			for( String values : objectCollection ){
				WebUI.comment("$values")
				TestObject currentObject = findTestObject(values)

				ignoredObject.add(currentObject)
			}
		}
		WebUI.comment("$ignoredObject")
		try{
			if(ignoredObject.size() != 0 ){
				WebUI.takeFullPageScreenshot(reportpath, ignoredObject)
				WebUI.scrollToPosition(0, 0)
			}else{
				WebUI.takeFullPageScreenshot(reportpath)
				WebUI.scrollToPosition(0, 0)
			}
		}catch(Exception e){
			WebUI.comment("failed to take screenshot, attempt to take screenshot again")
			if(ignoredObject.size() != 0 ){
				WebUI.takeFullPageScreenshot(reportpath, ignoredObject)
				WebUI.scrollToPosition(0, 0)
			}else{
				WebUI.takeFullPageScreenshot(reportpath)
				WebUI.scrollToPosition(0, 0)
			}
		}
	}
}

//	KeywordLogger log = new KeywordLogger();
//
//
//	@Keyword
//	public void getEntirePage(String fileName) {
//		WebDriver driver = DriverFactory.getWebDriver();
//		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
//		String path = getImgPath("llllll");
//
//		ImageIO.write(screenshot.getImage(), "JPG", new File(path));
//
//		log.logPassed("Taking screenshot successfully\n[[ATTACHMENT|"+path+"]]");
//	}
//
//
//	private String getImgPath(String fileName){
//
//		String format = ".JPG"
//
//		if(fileName.equals("")){
//			fileName = new Date().getTime().toString() + format.toLowerCase();
//		}else{
//			if(!fileName.toLowerCase().contains(format.toLowerCase())){
//				fileName = (fileName + format).toLowerCase()
//			}else{
//				fileName = fileName.toLowerCase()
//			}
//		}
//
//		KeywordLogger logging = new KeywordLogger('')//KeywordLogger.getInstance();
//		String reportFolder = logging.getLogFolderPath()
//
//		return reportFolder+File.separator+fileName;
//	}
//}

package webCalendar

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.text.SimpleDateFormat

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import keys.ClickUsingJS
import keys.SendKeys
import keys.basicOperation as BasicOperation
import keys.scrollElementAdjusted as ScrollElement

public class calendarEngine {

	def Object[][] arrDays = [
		["Sun", "//input[@id='week1SunFlag']", "//input[@id='hourFromSun']", "//input[@id='minuteFromSun']", "//input[@id='hourToSun']", "//input[@id='minuteToSun']"],
		["Mon", "//input[@id='week1MonFlag']", "//input[@id='hourFromMon']", "//input[@id='minuteFromMon']", "//input[@id='hourToMon']", "//input[@id='minuteToMon']"],
		["Tue", "//input[@id='week1TueFlag']", "//input[@id='hourFromTue']", "//input[@id='minuteFromTue']", "//input[@id='hourToTue']", "//input[@id='minuteToTue']"],
		["Wed", "//input[@id='week1WedFlag']", "//input[@id='hourFromWed']", "//input[@id='minuteFromWed']", "//input[@id='hourToWed']", "//input[@id='minuteToWed']"],
		["Thu", "//input[@id='week1ThuFlag']", "//input[@id='hourFromThu']", "//input[@id='minuteFromThu']", "//input[@id='hourToThu']", "//input[@id='minuteToThu']"],
		["Fri", "//input[@id='week1FriFlag']", "//input[@id='hourFromFri']", "//input[@id='minuteFromFri']", "//input[@id='hourToFri']", "//input[@id='minuteToFri']"],
		["Sat", "//input[@id='week1SatFlag']", "//input[@id='hourFromSat']", "//input[@id='minuteFromSat']", "//input[@id='hourToSat']", "//input[@id='minuteToSat']"]
	]

	@Keyword
	public def resetCalendar(String[] arr) {

		TestObject iframe1 = new TestObject()
		iframe1.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='login']")
		WebUI.switchToFrame(iframe1, 0)
		println ("success switch to frame login")

		//switch to frame username mainFrame
		TestObject iframe2 = new TestObject()
		iframe2.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='mainFrame']")
		WebUI.switchToFrame(iframe2, 0)
		println ("success switch to frame username mainFrame")

		for (i in arr) {
			String day = i.trim()
			for (a in arrDays) {
				if (((String)a[0]).equals(i)) {
					/*
					 TestObject checkbox = (TestObject)a[1]
					 String checked = WebUI.getAttribute(checkbox, "checked")
					 if (checked != null && "true".equalsIgnoreCase(checked)) {
					 WebUI.click(checkbox)
					 }
					 */

					WebDriver driver = DriverFactory.getWebDriver();
					WebElement element = driver.findElement(By.xpath((String) a[1]))
					((JavascriptExecutor) driver).executeScript(
							"if (arguments[0].checked) arguments[0].checked = false;",
							element
							);

					String hourFrom = "";
					String minuteFrom = "";
					String hourTo = "";
					String minuteTo = "";
					WebElement elHourFrom = driver.findElement(By.xpath((String) a[2]))
					((JavascriptExecutor) driver).executeScript(
							"arguments[0].value = arguments[1];",
							elHourFrom, hourFrom
							);
					WebElement elMinuteFrom = driver.findElement(By.xpath((String) a[3]))
					((JavascriptExecutor) driver).executeScript(
							"arguments[0].value = arguments[1];",
							elMinuteFrom, minuteFrom
							);
					WebElement elHourTo = driver.findElement(By.xpath((String) a[4]))
					((JavascriptExecutor) driver).executeScript(
							"arguments[0].value = arguments[1];",
							elHourTo, hourTo
							);
					WebElement elMinuteTo = driver.findElement(By.xpath((String) a[5]))
					((JavascriptExecutor) driver).executeScript(
							"arguments[0].value = arguments[1];",
							elMinuteTo, minuteTo
							);

					driver.switchTo().defaultContent()
					WebUI.switchToDefaultContent()

				}
			}
		}
		WebUI.switchToDefaultContent()
	}

	@Keyword
	public def selectCalendar( String days, String businessDay = "false", String fromTime, String toTime) {

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		ClickUsingJS clickjs = new ClickUsingJS()

		BasicOperation mathOperation = new BasicOperation()

		String currentRow ="//tr[.//div[contains(@id, 't-working_time-days') and text()='"+days+"']]"

		String droplistOk = '//div[contains(@class, "ant-picker-dropdown") and not(contains(@class, "hidden"))]//li[@class="ant-picker-ok"]//button//span[text()="Ok"]'

		TestObject ddlOkButton = new TestObject()
		ddlOkButton.addProperty("xpath", ConditionType.EQUALS, droplistOk)

		TestObject businessDayInputObject = new TestObject()
		businessDayInputObject.addProperty("xpath", ConditionType.EQUALS, currentRow+"//input[@type='checkbox' and @value='workdayFlag']")

		WebUI.verifyElementPresent(businessDayInputObject, 0)
		def checkedBusinessDay = WebUI.verifyElementChecked(businessDayInputObject, 0, FailureHandling.OPTIONAL)
		if(checkedBusinessDay.equals(false) && businessDay.equals("true")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.check(businessDayInputObject)
			WebUI.verifyElementChecked(businessDayInputObject, 0)
			WebUI.comment("successfully check business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("false")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.uncheck(businessDayInputObject)
			WebUI.verifyElementNotChecked(businessDayInputObject, 0)
			WebUI.comment("successfully uncheck business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("true")){
			WebUI.comment("checkbox on targeted row have been checked")
		}else if(checkedBusinessDay.equals(false) && businessDay.equals("false")){
			WebUI.comment("checkbox on targeted row have been unchecked")
		}

		TestObject fromTimeObject = new TestObject()
		fromTimeObject.addProperty("xpath", ConditionType.EQUALS, currentRow+"//input[contains(@id,'from_time')]")

		TestObject toTimeObject = new TestObject()
		toTimeObject.addProperty("xpath", ConditionType.EQUALS, currentRow+"//input[contains(@id,'to_time')]")

		WebUI.verifyElementPresent(fromTimeObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(fromTimeObject, 0, 50)
		WebUI.click(fromTimeObject)
		//kalo input text bisa diganti
		//		newKeys.handleInput(startTimeInputObject, "Keys.CONTROL, a")
		//		newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		String startTimeHour = fromTime.substring(0, fromTime.indexOf(":"))
		String startTimeMin = fromTime.split(":")[1]

		String startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+startTimeHour+"']"
		String startTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][2]//li//div[text()='"+startTimeMin+"']"
		String currentTimeHour = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li[@class='ant-picker-time-panel-cell ant-picker-time-panel-cell-selected']//div"
		String currentTimeMinute = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][2]//li[@class='ant-picker-time-panel-cell ant-picker-time-panel-cell-selected']//div"

		TestObject startTimeChosenHour = new TestObject()
		startTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)

		TestObject startTimeChosenMinute = new TestObject()
		startTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, startTimeMinuteChoice)

		TestObject currentHourStartTime = new TestObject()
		currentHourStartTime.addProperty("xpath", ConditionType.EQUALS, currentTimeHour)

		Boolean currentStart = WebUI.verifyElementPresent(currentHourStartTime, 0, FailureHandling.OPTIONAL)

		if(currentStart == true) {

			String currentStartHour = WebUI.getText(currentHourStartTime)

			if(currentStartHour == startTimeHour) {
				clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
			}else {

				Boolean clickStatus = WebUI.verifyElementClickable(startTimeChosenHour)

				if(clickStatus == true) {
					clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
				}else {
					if(currentStartHour < startTimeHour) {
						while(currentStartHour != startTimeHour) {
							String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "DD")
							startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							startTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
							clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
							currentStartHour = WebUI.getText(currentHourStartTime)
						}
					}else {
						TestObject nowButton = new TestObject()
						nowButton.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//a[@class='ant-picker-now-btn']")

						WebUI.click(nowButton)
						WebUI.click(fromTimeObject)

						while(currentStartHour != startTimeHour) {
							String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
							startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							startTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
							clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
							currentStartHour = WebUI.getText(currentHourStartTime)
						}
					}
				}
			}
		}else {
			Boolean clickStatus = WebUI.verifyElementClickable(startTimeChosenHour)

			if(clickStatus == true) {
				clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
			}else {
				String currentStartHour = "00"
				while(currentStartHour != startTimeHour) {
					String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
					startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
					startTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
					clickjs.ClickUsingJavaScript(startTimeChosenHour, 0)
					currentStartHour = WebUI.getText(currentHourStartTime)
				}

			}
		}

		TestObject currentMinuteStartTime = new TestObject()
		currentMinuteStartTime.addProperty("xpath", ConditionType.EQUALS, currentTimeMinute)

		Boolean currentStart2 = WebUI.verifyElementPresent(currentMinuteStartTime, 0, FailureHandling.OPTIONAL)

		if(currentStart2 == true) {

			String currentStartMin = WebUI.getText(currentMinuteStartTime)

			if(currentStartMin == startTimeHour) {
				clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
			}else {

				Boolean clickStatus = WebUI.verifyElementClickable(startTimeChosenMinute)

				if(clickStatus == true) {
					clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
				}else {
					if(currentStartMin < startTimeMin) {
						while(currentStartMin != startTimeMin) {
							String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "hh")
							startTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							startTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
							clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
							currentStartMin = WebUI.getText(currentMinuteStartTime)
						}
					}else {
						TestObject nowButton = new TestObject()
						nowButton.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//a[@class='ant-picker-now-btn']")

						WebUI.click(nowButton)
						WebUI.click(fromTimeObject)

						while(currentStartMin != startTimeMin) {
							String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "mm")
							startTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							startTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
							clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
							currentStartMin = WebUI.getText(currentMinuteStartTime)
						}
					}
				}
			}
		}else {
			Boolean clickStatus = WebUI.verifyElementClickable(startTimeChosenMinute)

			if(clickStatus == true) {
				clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
			}else {
				String currentStartMin = "00"
				while(currentStartMin != startTimeMin) {
					String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "mm")
					startTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
					startTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, startTimeMinuteChoice)
					clickjs.ClickUsingJavaScript(startTimeChosenMinute, 0)
					currentStartMin = WebUI.getText(currentMinuteStartTime)
				}

			}
		}

		WebUI.click(ddlOkButton)

		WebUI.verifyElementPresent(toTimeObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(toTimeObject, 0, 50)
		WebUI.click(toTimeObject)

		String endTimeHour = toTime.substring(0, toTime.indexOf(":"))
		String endTimeMin = toTime.split(":")[1]

		String endTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+endTimeHour+"']"
		String endTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][2]//li//div[text()='"+endTimeMin+"']"

		TestObject endTimeChosenHour = new TestObject()
		endTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, endTimeHourChoice)

		if(currentStart == true) {

			String currentStartHour = WebUI.getText(currentHourStartTime)

			if(currentStartHour == endTimeHour) {
				clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
			}else {

				Boolean clickStatus = WebUI.verifyElementClickable(endTimeChosenHour)

				if(clickStatus == true) {
					clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
				}else {
					if(currentStartHour < endTimeHour) {
						while(currentStartHour != endTimeHour) {
							String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
							endTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							endTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, endTimeHourChoice)
							clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
							currentStartHour = WebUI.getText(currentHourStartTime)
						}
					}else {
						TestObject nowButton = new TestObject()
						nowButton.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//a[@class='ant-picker-now-btn']")

						WebUI.click(nowButton)
						WebUI.click(toTimeObject)

						while(currentStartHour != endTimeHour) {
							String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
							endTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							endTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, endTimeHourChoice)
							clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
							currentStartHour = WebUI.getText(currentHourStartTime)
						}
					}
				}
			}
		}else {
			Boolean clickStatus = WebUI.verifyElementClickable(endTimeChosenHour)

			if(clickStatus == true) {
				clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
			}else {
				String currentStartHour = "00"
				while(currentStartHour != endTimeHour) {
					String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
					startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
					startTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
					clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
					currentStartHour = WebUI.getText(currentHourStartTime)
				}

			}
		}

		TestObject endTimeChosenMinute = new TestObject()
		endTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, endTimeMinuteChoice)

		if(currentStart2 == true) {

			String currentStartMin = WebUI.getText(currentMinuteStartTime)

			if(currentStartMin == endTimeMin) {
				clickjs.ClickUsingJavaScript(currentMinuteStartTime, 0)
			}else {

				Boolean clickStatus = WebUI.verifyElementClickable(endTimeChosenMinute)

				if(clickStatus == true) {
					clickjs.ClickUsingJavaScript(endTimeChosenMinute, 0)
				}else {
					if(currentStartMin < endTimeMin) {
						while(currentStartMin != endTimeMin) {
							String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "mm")
							endTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							endTimeChosenMinute.addProperty("xpath", ConditionType.EQUALS, endTimeMinuteChoice)
							clickjs.ClickUsingJavaScript(endTimeChosenMinute, 0)
							currentStartMin = WebUI.getText(currentMinuteStartTime)
						}
					}else {
						TestObject nowButton = new TestObject()
						nowButton.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//a[@class='ant-picker-now-btn']")

						WebUI.click(nowButton)
						WebUI.click(fromTimeObject)

						while(currentStartMin != endTimeMin) {
							String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "mm")
							endTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
							endTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, endTimeMinuteChoice)
							clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
							currentStartMin = WebUI.getText(currentMinuteStartTime)
						}
					}
				}
			}
		}else {
			Boolean clickStatus = WebUI.verifyElementClickable(endTimeChosenMinute)

			if(clickStatus == true) {
				clickjs.ClickUsingJavaScript(endTimeChosenMinute, 0)
			}else {
				String currentStartMin = "00"
				while(currentStartMin != endTimeMin) {
					String gap = mathOperation.sumResultInString([currentStartMin, 1], false, 0, "mm")
					endTimeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
					endTimeChosenHour.addProperty("xpath", ConditionType.EQUALS, endTimeMinuteChoice)
					clickjs.ClickUsingJavaScript(endTimeChosenHour, 0)
					currentStartMin = WebUI.getText(currentMinuteStartTime)
				}

			}
		}
		
		WebUI.click(ddlOkButton)
	}

	@Keyword
	public def selectTodayCalendar( boolean isWorkday) {

		SimpleDateFormat sdf = new SimpleDateFormat("E")
		Date today = new Date();
		String dayToday = sdf.format(today)
		//		dayToday = "Tue";
		println("dayToday: " + dayToday)

		String[] arr = [dayToday]
		println("arr: " + arr)
		resetCalendar(arr)

		println("isWorkday: " + isWorkday)
		if (isWorkday) {

			TestObject iframe1 = new TestObject()
			iframe1.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='login']")
			WebUI.switchToFrame(iframe1, 0)
			println ("success switch to frame login")

			//switch to frame username mainFrame
			TestObject iframe2 = new TestObject()
			iframe2.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='mainFrame']")
			WebUI.switchToFrame(iframe2, 0)
			println ("success switch to frame username mainFrame")

			for (i in arr) {
				String day = i.trim()
				println(i)
				for (a in arrDays) {
					if (((String)a[0]).equals(i)) {
						/*
						 TestObject checkbox = (TestObject)a[1]
						 WebUI.click(checkbox)
						 println(a)
						 */
						println("Checking " + a[0])

						WebDriver driver = DriverFactory.getWebDriver();
						WebElement element = driver.findElement(By.xpath((String) a[1]))
						((JavascriptExecutor) driver).executeScript(
								"arguments[0].checked = true;",
								element
								);

						String hourFrom = "00";
						String minuteFrom = "01";
						String hourTo = "23";
						String minuteTo = "59";
						WebElement elHourFrom = driver.findElement(By.xpath((String) a[2]))
						((JavascriptExecutor) driver).executeScript(
								"arguments[0].value = arguments[1];",
								elHourFrom, hourFrom
								);
						WebElement elMinuteFrom = driver.findElement(By.xpath((String) a[3]))
						((JavascriptExecutor) driver).executeScript(
								"arguments[0].value = arguments[1];",
								elMinuteFrom, minuteFrom
								);
						WebElement elHourTo = driver.findElement(By.xpath((String) a[4]))
						((JavascriptExecutor) driver).executeScript(
								"arguments[0].value = arguments[1];",
								elHourTo, hourTo
								);
						WebElement elMinuteTo = driver.findElement(By.xpath((String) a[5]))
						((JavascriptExecutor) driver).executeScript(
								"arguments[0].value = arguments[1];",
								elMinuteTo, minuteTo
								);

						driver.switchTo().defaultContent()
						WebUI.switchToDefaultContent()
						break;
					}
				}
			}
			WebUI.switchToDefaultContent()
		}
	}

	@Keyword
	public def addCalendar(String description, String currency) {

		TestObject inputDescription = findTestObject("calender engine/Page_Danamon Cash Connect/input_description")
		WebUI.setText(inputDescription, description)

		TestObject inputCalendarType = findTestObject("calender engine/Page_Danamon Cash Connect/select_eventTypeCode")
		WebUI.selectOptionByLabel(inputCalendarType, "Holiday", false)

		TestObject inputParameterType = findTestObject("calender engine/Page_Danamon Cash Connect/select_parameterType")
		WebUI.selectOptionByLabel(inputParameterType, "Currency", false)

		TestObject labelCurrencySearch = findTestObject("calender engine/Page_Danamon Cash Connect/label_currency_search")
		WebUI.click(labelCurrencySearch)

		TestObject inputCurrencySearch = findTestObject("calender engine/Page_Danamon Cash Connect/input_currency_search")
		WebUI.setText(inputCurrencySearch, currency)
		WebUI.delay(2)
		WebUI.sendKeys(inputCurrencySearch, "\n")

		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = sdf.format(today);

		TestObject inputFrom = findTestObject("calender engine/Page_Danamon Cash Connect/input_effectiveDateFrom")
		WebUI.setText(inputFrom, strDate)

		TestObject inputTo = findTestObject("calender engine/Page_Danamon Cash Connect/input_effectiveDateTo")
		WebUI.setText(inputTo, strDate)

		/*
		 WebDriver driver = DriverFactory.getWebDriver();
		 WebElement webElement = driver.findElement(By.xpath("//*[@id='description']"));
		 ((JavascriptExecutor) driver).executeScript(
		 "arguments[0].value(arguments[1]);",
		 inputDescription, description
		 );
		 driver.switchTo().defaultContent()
		 WebUI.switchToDefaultContent()
		 */

	}

}

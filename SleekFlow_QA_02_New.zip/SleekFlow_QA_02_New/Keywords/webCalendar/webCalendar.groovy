package webCalendar

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
//import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty
import java.text.SimpleDateFormat
import java.util.Calendar;
//import keys.scrollElementAdjusted as ScrollElement

import internal.GlobalVariable

import java.text.SimpleDateFormat
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.*;

public class webCalendar {

	//variable selector that represent date
	static final String DATE_CUSTOMIZE = "{calendarDate}"

	@Keyword
	public def customizedNextDate(String target){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);


		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday + targetDay) //generate desired target date, + for target date after today

		String targetMonth = dateModify.format("MM")
		String targetYear = dateModify.format("yyyy")

		TestObject year = new TestObject()
		year.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-year-btn']")

		TestObject month = new TestObject()
		month.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-month-btn']")

		String currentMonth = WebUI.getText(month)

		String currentYear = WebUI.getText(year)
		WebUI.comment(currentYear)
		String chosenTargetDate= dateModify.format("yyyy-MM-dd")
		if(targetMonth == currentMonth && targetYear == currentYear){

			//verify date picker are visible
			TestObject datePicker = new TestObject()
			datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell') and @title='$chosenTargetDate']")
			WebUI.verifyElementVisible(datePicker)
			println ("success verify datePicker are visible")

			WebUI.click(datePicker)
		}else{
			customizedExactDate(chosenTargetDate)
		}
	}

	@Keyword
	public def customizedPrevDate(String target){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);

		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday - targetDay) //generate desired target date, + for target date after today

		String targetMonth = dateModify.format("MM")
		String targetYear = dateModify.format("yyyy")

		TestObject year = new TestObject()
		year.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-year-btn']")

		TestObject month = new TestObject()
		month.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-month-btn']")

		String currentMonth = WebUI.getText(month)

		String currentYear = WebUI.getText(year)
		WebUI.comment(currentYear)
		String chosenTargetDate= dateModify.format("yyyy-MM-dd")
		if(targetMonth == currentMonth && targetYear == currentYear){
			//verify date picker are visible
			TestObject datePicker = new TestObject()
			datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell') and @title='$chosenTargetDate']")
			WebUI.verifyElementVisible(datePicker)
			println ("success verify datePicker are visible")

			WebUI.click(datePicker)

		}else{

			customizedExactDate(chosenTargetDate)
		}
	}


	@Keyword
	public def customizedTodayDate(){ //date format are dd mmmm yyyy
		//println(targetDate)

		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only

		String chosenTargetDate= dateToday.format("yyyy-MM-dd")
		// as Integer //target month are formed to int
		println ("$chosenTargetDate")
		//verify date picker are visible
		TestObject datePicker = new TestObject()

		datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell') and @title='$chosenTargetDate']")

		def dateStatus = WebUI.verifyElementVisible(datePicker, FailureHandling.OPTIONAL)
		println ("success verify datePicker are visible")
		if(dateStatus) {
			WebUI.click(datePicker)
		}else {
			customizedExactDate(chosenTargetDate)
		}

	}



	@Keyword
	public def customizedExactDate(String targetDate){ //date format are dd/mmm/yyyy
		println(targetDate)
		//		ScrollElement scrollAdjusted = new ScrollElement()

		//2021-10-20
		def yearTarget = targetDate.split("-")[0].trim()
		String monthTarget = yearTarget + "-" + targetDate.split("-")[1].trim()

		TestObject year = new TestObject()
		year.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-year-btn']")
		TestObject pickYear = new TestObject()
		pickYear.addProperty("xpath", ConditionType.EQUALS, "//td[@title='$yearTarget']")

		TestObject month = new TestObject()
		month.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-month-btn']")
		TestObject pickMonth = new TestObject()
		pickMonth.addProperty("xpath", ConditionType.EQUALS, "//td[@title='$monthTarget']")

		TestObject firstYear = new TestObject()
		firstYear.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class,'ant-picker-dropdown') and not(contains(@style, '-'))][1]//div[@class='ant-picker-panel ant-picker-panel-has-range' or @class='ant-picker-panel'][1]//button[@class='ant-picker-year-btn']")

		TestObject datePicker = new TestObject()
		datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell') and @title='$targetDate']")
		//		scrollAdjusted.scrollIntoElementWithOffset(year, 500, 50)

		def yearMatch = WebUI.verifyElementText(firstYear, yearTarget, FailureHandling.OPTIONAL)
		if(yearMatch == false){
			WebUI.click(year)
			WebUI.comment("year has been clicked")
			//			scrollAdjusted.scrollIntoElementWithOffset(pickYear, 500, 50)
			WebUI.click(pickYear)
			WebUI.comment("pickyear has been clicked")
		}
		def monthPick = WebUI.verifyElementVisible(month, FailureHandling.OPTIONAL)
		if(monthPick == true) {
			def monthPicker = WebUI.verifyElementText(month, monthTarget, FailureHandling.OPTIONAL)
			WebUI.comment("$monthPicker")
			if(monthPicker == true){
				//			scrollAdjusted.scrollIntoElementWithOffset(pickMonth, 500, 50)
				WebUI.click(pickMonth)
			}else{
				WebUI.click(month)
				//			scrollAdjusted.scrollIntoElementWithOffset(pickMonth, 500, 50)
				WebUI.click(pickMonth)
			}
		}
		
		WebUI.verifyElementVisible(datePicker)
		println ("success verify datePicker are visible")
		WebUI.click(datePicker)

	}


	@Keyword
	public def verifyNextDateDisabled(String target){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);

		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday + targetDay) //generate desired target date, + for target date after today

		String chosenTargetDate= dateModify.format("yyyy-MM-dd")
		// as Integer //target month are formed to int
		//begin step to switch frame
		//switch to frame login

		//verify date picker are visible
		TestObject datePicker = new TestObject()
		datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell-disabled') and @title='$chosenTargetDate']")
		WebUI.verifyElementPresent(datePicker,0)

		TestObject datePicker2 = new TestObject()
		datePicker2.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[not(contains(@class,'ant-picker-cell-disabled')) and @title='$chosenTargetDate']")
		WebUI.verifyElementNotPresent(datePicker2,0)

		WebUI.comment("success verify $chosenTargetDate disabled")

	}

	@Keyword
	public def verifyPrevDateDisabled(String target){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);

		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday - targetDay) //generate desired target date, + for target date after today

		String chosenTargetDate= dateModify.format("yyyy-MM-dd")
		// as Integer //target month are formed to int

		//verify date picker are visible
		TestObject datePicker = new TestObject()
		datePicker.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[contains(@class,'ant-picker-cell-disabled') and @title='$chosenTargetDate']")
		WebUI.verifyElementPresent(datePicker,0)

		TestObject datePicker2 = new TestObject()
		datePicker2.addProperty("xpath", ConditionType.EQUALS, "//div[not(contains(@class,'ant-picker-dropdown-hidden'))]/div[@class='ant-picker-panel-container']//*[not(contains(@class,'ant-picker-cell-disabled')) and @title='$chosenTargetDate']")
		WebUI.verifyElementNotPresent(datePicker2,0)

		WebUI.comment("success verify $chosenTargetDate disabled")


	}

	@Keyword
	public def customizedPrevDateFormat(String target, String format = "dd MMM yyyy"){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);


		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday - targetDay) //generate desired target date, + for target date after today

		String currentMonth = dateToday.format("MM")
		String targetMonth = dateModify.format("MM")

		String targetFormat= dateModify.format(format)
		WebUI.comment("$targetFormat")
		return targetFormat;
	}

	@Keyword
	public def customizedNextDateFormat(String target, String format = "dd MMM yyyy"){ //date format are dd mmmm yyyy
		println(target)
		int targetDay = Integer.parseInt(target);


		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only
		def dateModify = (dateToday + targetDay) //generate desired target date, + for target date after today

		String currentMonth = dateToday.format("MM")
		String targetMonth = dateModify.format("MM")



		String targetFormat= dateModify.format(format)
		WebUI.comment("$targetFormat")
		return targetFormat;


	}

	@Keyword
	public def customizedTodayDateFormat(String format = "dd MMM yyyy"){ //date format are dd mmmm yyyy
		//println(targetDate)



		def dateToday = new Date()//.parse("dd MM yyyy", '05 05 2020') //for testing purpose only

		//String targetFormat= dateToday.format("dd MMM yyyy")
		String targetFormat= dateToday.format(format)
		WebUI.comment("$targetFormat")
		return targetFormat;

	}

	@Keyword
	public def customizedTodayDateDisplay(){ //date format are dd mmmm yyyy
		//println(targetDate)



		Calendar calendar = Calendar.getInstance();
		String resultDate = String.valueOf(calendar.get(Calendar.DATE))
		WebUI.comment(resultDate)

		String resultMonth = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())
		WebUI.comment(resultMonth)

		String resultYear = String.valueOf(calendar.get(Calendar.YEAR))
		WebUI.comment(resultYear)

		String result = resultDate + " " + resultMonth + " " + resultYear
		WebUI.comment(result)
		return result
	}

	@Keyword
	public def getPreviousMonth(Integer month){ //date format are dd mmmm yyyy
		Calendar calendar = Calendar.getInstance();
		System.out.println("Current Date = " + calendar.getTime());
		// Subtract months from current date
		calendar.add(Calendar.MONTH, (~(month - 1)));
		System.out.println("Updated Date = " + calendar.getTime());
		String resultMonth = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())
		WebUI.comment(resultMonth)

		String resultYear = String.valueOf(calendar.get(Calendar.YEAR))
		WebUI.comment(resultYear)

		String result = resultMonth + " - " + resultYear
		WebUI.comment(result)
		return result
	}

	@Keyword
	public def changeDateFormat(String inputDate, String originalformat, String newformat, String removeText = ""){
		if ((removeText != "") && (removeText != null)){
			inputDate = inputDate.replace(removeText, "").trim()
		}

		SimpleDateFormat sdf= new SimpleDateFormat(originalformat)
		SimpleDateFormat sdfNew= new SimpleDateFormat(newformat)
		def dateCurrent = sdf.parse(inputDate);
		WebUI.comment("success parsing " + dateCurrent)
		def dateNew = sdfNew.format(dateCurrent);
		WebUI.comment("successfully change format to: " + dateNew)
		return dateNew
	}

	public def parseRangeintoDates(String inputRange, String dateFormat) {
		List<String> parseResult = new ArrayList()

		LocalDateTime dateFrom = LocalDateTime.now()
		LocalDateTime dateTo = LocalDateTime.now()
		DateTimeFormatter formmat1 = DateTimeFormatter.ofPattern(dateFormat, Locale.ENGLISH);

		//		def dateFrom = new Date()
		//		def dateTo = new Date()
		if(inputRange.equalsIgnoreCase("last week")){
			dateFrom = dateFrom.minusWeeks(1).withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.withHour(23).withMinute(59).withSecond(59)
			//			dateFrom.setDate(dateFrom.getDate() - (dateFrom.getDay() + 6) % 7)//get this monday date
			//			dateFrom.setDate(dateFrom.getDate() - 7)//-7 day to find the previous week date
			//			dateTo.setDate(dateTo.getDate() - (dateTo.getDay()) % 7)//find sunday date of last week
		}else if(inputRange.equalsIgnoreCase("this week")){
			dateFrom = dateFrom.withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.plusDays(7).withHour(23).withMinute(59).withSecond(59)
			//			dateTo.setDate(dateTo.getDate() + 7)//-7 day to find the next week date
		}else if(inputRange.equalsIgnoreCase("next week")){
			dateFrom = dateFrom.plusDays(7).withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.plusDays(14).withHour(23).withMinute(59).withSecond(59)
			//			dateFrom.setDate(dateFrom.getDate() - (dateFrom.getDay() + 6) % 7)//get this monday date
			//			dateFrom.setDate(dateFrom.getDate() + 7)//-7 day to find the next week date
			//			dateTo.setDate(dateTo.getDate() - (dateTo.getDay()) % 7)//find sunday date of next week
			//			dateTo.setDate(dateTo.getDate() + 14)//-7 day to find the next week date
		}else if(inputRange.equalsIgnoreCase("last month") || inputRange.equalsIgnoreCase("last 2 month") || inputRange.equalsIgnoreCase("last 3 month")){
			int monthTotal = 1

			if(!inputRange.equalsIgnoreCase("last month")) {
				inputRange = inputRange.toLowerCase()
				String monthText = inputRange.substring(inputRange.indexOf("last")+4, inputRange.indexOf("month"))
				monthTotal = Integer.valueOf(monthText.trim())
			}
			dateFrom = dateFrom.minusMonths(monthTotal).withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.withHour(23).withMinute(59).withSecond(59)
			//			dateFrom.setDate(1);
			//			dateFrom.setMonth(dateFrom.getMonth()- monthTotal);
			//			dateTo.setDate(1); // going to 1st of the month
			//			dateTo.setSeconds(-1); // going to last hour before this date even started.
		}else if(inputRange.equalsIgnoreCase("next month")){
			dateFrom = dateFrom.withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.plusMonths(1).plusDays(1).withHour(23).withMinute(59).withSecond(59)
			//			dateFrom.setDate(1);
			//			dateFrom.setMonth(dateFrom.getMonth()+1);
			//			dateTo.setMonth(dateFrom.getMonth()+1); // going to last hour before this date even started.
			//			dateTo.setDate(0);
		}else {
			dateFrom = dateFrom.withHour(0).withMinute(0).withSecond(0)
			dateTo = dateTo.withHour(23).withMinute(59).withSecond(59)
		}

		String fromDate = dateFrom.format(formmat1)
		String toDate = dateTo.format(formmat1)
		WebUI.comment("from : $fromDate, to: $toDate");

		parseResult.add(fromDate)
		parseResult.add(toDate)

		return parseResult
	}

}

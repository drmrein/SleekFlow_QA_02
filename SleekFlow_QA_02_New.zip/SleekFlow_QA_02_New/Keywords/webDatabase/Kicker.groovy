package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import webDatabase.PostgreConnection

public class Kicker extends PostgreConnection{
	// def Kicker (String hostDb, Integer portDB, String usernameDB, String passwordDB, String nameDB) {
	//	 super(hostDb, portDB, usernameDB, passwordDB, nameDB)
	// }

	@Keyword
	def releaseLoginFO(String userId, String corpId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			String sql = "update idm_user set is_still_login = 'N' where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?)"
			ps = getConnection().prepareStatement(
					sql)
			println(String.format("SQL: %s, user_id: %s", sql, userId))
			ps.setString(1, userId.toUpperCase())
			ps.setString(2, corpId)
			updated = ps.executeUpdate()
			println(String.format("Updated %s row", updated))
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
			e.printStackTrace()
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def unlockLoginFO(String userId, String corpId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			String sql = "update idm_user set status = 'ACTIVE', login_count = 0, is_inactive = 'N' where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?) and status = 'LOCKED' and login_count >= 3"
			ps = getConnection().prepareStatement(
					sql)
			println(String.format("SQL: %s, user_id: %s", sql, userId))
			ps.setString(1, userId.toUpperCase())
			ps.setString(2, corpId)
			updated = ps.executeUpdate()
			println(String.format("Updated %s row", updated))
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
			e.printStackTrace()
		} finally {
			closeConnection()
		}
		return updated

	}

	@Keyword
	def activeFO(String userId, String corpId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update idm_user set is_inactive = 'N' , status = 'ACTIVE' where where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?)")
			ps.setString(1, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def releaseLoginBO(String userId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set is_still_login = 'N' "
					+ "where user_id = ?")
			ps.setString(1, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def unlockLoginBO(String userId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			String sql = "update bo_idm_user set status = 'ACTIVE', login_count = 0, is_inactive = 'N' where upper(user_id) = ? and status = 'LOCKED' and login_count >= 3"
			ps = getConnection().prepareStatement(
					sql)
			println(String.format("SQL: %s, user_id: %s", sql, userId))
			ps.setString(1, userId.toUpperCase())
			updated = ps.executeUpdate()
			println(String.format("Updated %s row", updated))
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
			e.printStackTrace()
		} finally {
			closeConnection()
		}
		return updated

	}

	@Keyword
	def activeBO(String userId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user set is_inactive = 'N' , status = 'ACTIVE' where user_id = ?")
			ps.setString(1, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to kick user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

}

package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import java.util.UUID
import java.sql.PreparedStatement
import java.sql.Timestamp

import internal.GlobalVariable
import keys.RandomNumber as RandNumberGenerator

public class DownloadReportBO extends PostgreConnection{

	@Keyword
	def generateFailCSV(String updatedBy) {
		RandNumberGenerator randNum = new RandNumberGenerator()
		PreparedStatement ps = null
		int updated = 0
		Timestamp currentTime = new Timestamp(new Date().getTime())
		String uuidvar = String.valueOf(UUID.randomUUID());
		WebUI.comment(uuidvar)
		String randRefID = randNum.generateRandomNumber(6)
		WebUI.comment(randRefID)
		try {
			connect()
			ps = getConnection().prepareStatement(
					"INSERT INTO agcm.fgen_file (id, ref_id, status, gen_by, gen_dt, err_log, valid_day, engine, tmpl_nm, elps, ext, dload_file_nm, fl_size, module_nm, fgen_parent_id)"
					+ "VALUES("
					+ "?, "
					+ "?,"
					+ "'F',"
					+ "?,"
					+ "?,"
					+ "'Report not found',"
					+ "0,"
					+ "'CSV',"
					+ "'bank_activity_log_report_delimiter',"
					+ "0,"
					+ "'csv',"
					+ "'testFile',"
					+ "0,"
					+ "'DEFAULT',"
					+ "NULL);"
					)
			ps.setString(1, uuidvar)
			ps.setString(2, randRefID)
			ps.setString(3, updatedBy)
			ps.setTimestamp(4, currentTime)
			updated = ps.executeUpdate()
			
			ps = getConnection().prepareStatement(
				'INSERT INTO agcm.pc_report_gen_list (id, "version", nm, dscp, requested_by, requested_dt, file_format, updated_by, updated_dt, rperiode_typ, rperiode_param, media_typ, media_val, download_sts, report_gen_list_val, report_menu_cd, app_cd, report_gen_setup_id, file_id) VALUES('
				+ "?, "
				+ "0,"
				+ "NULL,"
				+ "NULL,"
				+ "?,"
				+ "?,"
				+ "NULL,"
				+ "NULL,"
				+ "NULL,"
				+ "NULL,"
				+ "0,"
				+ "NULL,"
				+ "NULL,"
				+ "NULL,"
				+ "NULL,"
				+ "'BO_BANK_ACTIVITY_LOG_REPORT',"
				+ "NULL,"
				+ "NULL,"
				+ "NULL);"
				)
			
			ps.setString(1, randRefID)
			ps.setString(2, updatedBy)
			ps.setTimestamp(3, currentTime)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to generate Fail: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
}

package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

public class KickerLogin {

	@Keyword
	public def releaseLoginFO(String username, String password, String corpId, String dbAlias, String stepGroupName) {

		println(String.format("password: %s", password))

		// TestObject iframe1 = new TestObject()
		// iframe1.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='login']")
		// WebUI.switchToFrame(iframe1, 0)
		// println ("success switch to frame login")

		TestObject objErrorMessage = new TestObject();
		objErrorMessage.addProperty("xpath", ConditionType.EQUALS, "//*[@id='t-msg-error-content']")

		TestObject objDashboardTitle = new TestObject();
		objDashboardTitle.addProperty("xpath", ConditionType.EQUALS, "//h1[contains(@class, 'Dashboard-title')]")


		//while (WebUI.verifyElementPresent(objErrorMessage, 5, FailureHandling.CONTINUE_ON_FAILURE)) {
		boolean isLoggedIn = false
		boolean isLoggedIn2 = false
		WebDriver driver = DriverFactory.getWebDriver()
		try {
			driver.switchTo().defaultContent()
			// driver.switchTo().frame("login")
			WebUI.delay(2)
			isLoggedIn = WebUI.verifyElementPresent(objErrorMessage, GlobalVariable.delaysmall, FailureHandling.OPTIONAL)
			isLoggedIn2 = WebUI.verifyElementPresent(objDashboardTitle, GlobalVariable.delaysmall, FailureHandling.OPTIONAL)
		} catch(Exception e) {
			isLoggedIn = false;
		} finally {
			driver.switchTo().defaultContent()
		}

		if(isLoggedIn && isLoggedIn2 == false){
			//while (isLoggedIn) {
			// WebUI.switchToFrame(iframe1, 0)
			def msg = WebUI.getText(objErrorMessage)
			println("msg: " + msg)
			if (msg.equalsIgnoreCase("User is still login")) {
				println("Still login, try to kick session")
				try {
					// TODO
					//					LoginReleaser loginReleaser = new LoginReleaser();
					//					loginReleaser.releaseLoginFO(username, dbAlias);
					Kicker kicker = new Kicker()
					kicker.releaseLoginFO(username, corpId)
					WebUI.switchToDefaultContent()
					WebUI.delay(5)
					WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password, ('corp') : corpId], FailureHandling.STOP_ON_FAILURE)
				} catch (Exception e) {
					e.printStackTrace();
				}

			} else if (msg.equalsIgnoreCase("User ID is Locked")) {
				Kicker kicker = new Kicker()
				kicker.unlockLoginFO(username, corpId)
				WebUI.switchToDefaultContent()
				WebUI.delay(5)
				WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password, ('corp') : corpId], FailureHandling.STOP_ON_FAILURE)

			}else if (msg.equalsIgnoreCase("User ID Inactive")) {
				Kicker kicker = new Kicker()
				kicker.activeFO(username, corpId)
				WebUI.switchToDefaultContent()
				WebUI.delay(5)
				WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password, ('corp') : corpId], FailureHandling.STOP_ON_FAILURE)

			}
		}


	}

	@Keyword
	public def releaseLoginBO(String username, String password, String dbAlias, String stepGroupName) {

		println(String.format("password: %s", password))

		// TestObject iframe1 = new TestObject()
		// iframe1.addProperty("xpath", ConditionType.EQUALS, "//iframe[@id='login']")
		// WebUI.switchToFrame(iframe1, 0)
		// println ("success switch to frame login")

		TestObject objErrorMessage = new TestObject();
		objErrorMessage.addProperty("xpath", ConditionType.EQUALS, "//*[@id='t-msg-error-content']")

		TestObject objDashboardTitle = new TestObject();
		objDashboardTitle.addProperty("xpath", ConditionType.EQUALS, "//div[text()='Dashboard']")

		//while (WebUI.verifyElementPresent(objErrorMessage, 5, FailureHandling.CONTINUE_ON_FAILURE)) {
		boolean isLoggedIn = false
		boolean isLoggedIn2 = true
		WebDriver driver = DriverFactory.getWebDriver()
		try {
			driver.switchTo().defaultContent()
			WebUI.delay(5)
			// driver.switchTo().frame("login")
			isLoggedIn = WebUI.verifyElementPresent(objErrorMessage, GlobalVariable.delaysmall, FailureHandling.OPTIONAL)
			isLoggedIn2 = WebUI.verifyElementPresent(objDashboardTitle, GlobalVariable.delaysmall, FailureHandling.OPTIONAL)

			println(String.format("isLoggedIn: %s", isLoggedIn))
			println(String.format("isLoggedIn2: %s", isLoggedIn2))
		} catch(Exception e) {
			isLoggedIn = false;
		} finally {
			driver.switchTo().defaultContent()
		}

		if(isLoggedIn && isLoggedIn2 == false){
			//while (isLoggedIn) {
			// WebUI.switchToFrame(iframe1, 0)
			def msg = WebUI.getText(objErrorMessage)
			println("msg: " + msg)
			if (msg.equalsIgnoreCase("User is still login")) {
				println("Still login, try to kick session")
				try {
					// TODO
					//					LoginReleaser loginReleaser = new LoginReleaser();
					//					loginReleaser.releaseLoginFO(username, dbAlias);
					Kicker kicker = new Kicker()
					kicker.releaseLoginBO(username)
					WebUI.switchToDefaultContent()
					WebUI.delay(5)
					WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password], FailureHandling.STOP_ON_FAILURE)
				} catch (Exception e) {
					e.printStackTrace();
				}

			} else if (msg.equalsIgnoreCase("User ID is Locked")) {
				Kicker kicker = new Kicker()
				kicker.unlockLoginBO(username)
				WebUI.switchToDefaultContent()
				WebUI.delay(5)
				WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password], FailureHandling.STOP_ON_FAILURE)

			}else if (msg.equalsIgnoreCase("User ID Inactive")) {
				Kicker kicker = new Kicker()
				kicker.activeBO(username)
				WebUI.switchToDefaultContent()
				WebUI.delay(5)
				WebUI.callTestCase(findTestCase(stepGroupName), [('user') : username, ('pass') : password], FailureHandling.STOP_ON_FAILURE)

			}


		}


	}

}

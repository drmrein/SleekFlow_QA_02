package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement
import java.sql.Timestamp

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows


public class RoleUser extends PostgreConnection {
	
	@Keyword
	def insertRoleIntoUser(String userId, String userCode, String roleCode) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"INSERT INTO agcm.bo_idm_user_role (id,user_cd,role_cd,created_by,created_dt) VALUES "
					+ "(?,?,?,'SYSTEM',NULL);")
					
			ps.setString(1, userId)
			ps.setString(2, userCode)
			ps.setString(3, roleCode)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to inactivate user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
}

package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement
import java.sql.Timestamp

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class BankUserManager extends PostgreConnection {

	@Keyword
	def reset(String updatedBy,
			String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set status = 'RESET', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to reset user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def stillLoggedIn(String userId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set is_still_login = 'Y' "
					+ "where user_id = ?")
			ps.setString(1, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to set user to still logged in: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def release(String updatedBy, String userId) {
		PreparedStatement ps = null
		Timestamp currentTime = new Timestamp(new Date().getTime())
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user set "
					+ "is_still_login = 'N', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to release user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def inactive(String updatedBy, String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user set "
					+ "status = 'INACTIVE', "
					+ "is_inactive = 'Y', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to inactive user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def activate(String updatedBy, String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user set "
					+ "status = 'ACTIVE', "
					+ "is_inactive = 'N', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to activate user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def lock(String userId) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user set "
					+ "status = 'LOCKED', "
					+ "login_count = 3 "
					+ "where user_id = ?")
			ps.setString(1, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to lock user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def unlock(String updatedBy, String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set status = 'ACTIVE', "
					+ "login_count = 0, "
					+ "is_inactive = 'N', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to unlock user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
	@Keyword
	def delete(String updatedBy, String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set is_delete = 'Y', "
					+ "status = 'DELETED', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to delete user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
	@Keyword
	def rollback(String updatedBy, String userId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update bo_idm_user "
					+ "set is_delete = 'N', "
					+ "status = 'ACTIVE', "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where user_id = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, currentTime)
			ps.setString(3, userId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to rollback user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
}

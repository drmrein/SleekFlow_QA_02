package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement
import java.sql.Timestamp

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class DeviceRegistration extends PostgreConnection{

	@Keyword
	def unregister( String registeredBy,
			Timestamp registeredDate, String updatedBy, Timestamp updatedDate,
			String deviceNo, String serialNo) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
				"update "
				+ "mobile_token set "
				+ "retry = 0,"
				+ "status = 0 "
				+ "where serial_no = ?")
			ps.setString(1, serialNo)
			updated = ps.executeUpdate()
			
			ps = getConnection().prepareStatement(
					"update "
					+ "idm_auth_device set "
					+ "downloaded_flag ='Y',"
					+ "registered_flag = 'N', "
					+ "registered_by = ?, "
					+ "registered_dt = ?, "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where device_no = ?")
			ps.setString(1, registeredBy)
			ps.setTimestamp(2, registeredDate)
			ps.setString(3, updatedBy)
			ps.setTimestamp(4, updatedDate)
			ps.setString(5, deviceNo)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to register device: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def unlock(String serialNo, String updatedBy, Timestamp updatedDate) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update "
					+ "mobile_token set "
					+ "status = 0 "
					+ "where serial_no = ?")
			ps.setString(1, serialNo)
			updated = ps.executeUpdate()

			ps = getConnection().prepareStatement(
					"update idm_auth_device set "
					+ "retry = 0, "
					+ "downloaded_flag ='Y',"
					+ "registered_flag ='Y,"
					+ "status = 0, "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where device_no = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, updatedDate)
			ps.setString(3, serialNo)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to unlock device: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
	@Keyword
	def lock(String serialNo, String updatedBy, Timestamp updatedDate) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update "
					+ "mobile_token set "
					+ "status = 1 "
					+ "where serial_no = ?")
			ps.setString(1, serialNo)
			updated = ps.executeUpdate()

			ps = getConnection().prepareStatement(
					"update idm_auth_device set "
					+ "retry = 0, "
					+ "status = 1, "
					+ "where device_no = ?")
			ps.setString(1, serialNo)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to unlock device: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def register(Timestamp lastActivity, String serialNo,
			String updatedBy, Timestamp updatedDate) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update mobile_token set "
					+ "activation_key = null, "
					+ "challenge_no = null, "
					+ "data_field = null, "
					+ "generated_date = null, "
					+ "last_activity = ?, "
					+ "retry = 0, "
					+ "signature = null, "
					+ "status = 0 "
					+ "where serial_no = ?")
			ps.setTimestamp(1, lastActivity)
			ps.setString(2, serialNo)
			updated = ps.executeUpdate()

			ps = getConnection().prepareStatement(
					"update idm_auth_device set "
					+ "registered_flag = 'Y', "
					+ "downloaded_flag = 'Y', "
					+ "retry = 0, "
					+ "status = 1, "
					+ "updated_by = ?, "
					+ "updated_dt = ? "
					+ "where device_no = ?")
			ps.setString(1, updatedBy)
			ps.setTimestamp(2, updatedDate)
			ps.setString(3, serialNo)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to unregister device: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
}

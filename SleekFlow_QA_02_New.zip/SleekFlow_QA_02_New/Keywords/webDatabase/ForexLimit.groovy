package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class ForexLimit extends PostgreConnection {

	@Keyword
	def reset(String id) {
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement("update pc_bank_forex_lmt pbfl set usage = 0, usage_eq = 0 where app_cd = 'BO' and ccy_cd = ?")
			ps.setString(1, id)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to reset forex limit: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
	
	@Keyword
	def update(String id, String nominal) {
		PreparedStatement ps = null
		int updated = 0
		String statementVal = "update pc_bank_forex_lmt pbfl set usage = $nominal, usage_eq = $nominal where app_cd = 'BO' and ccy_cd = ?"
		try {
			connect()
			ps = getConnection().prepareStatement(statementVal)
			ps.setString(1, id)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to reset forex limit: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
}

package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.Timestamp

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class eInvoice extends PostgreConnection{
	@Keyword
	def getDueDate(String eInvoiceNo) {
		PreparedStatement ps = null
		ResultSet rslt = null
		String result = null
		try {
			connect()
			ps = getConnection().prepareStatement(
					"select einv_due_dt "
					+ "from fsc_corp_einv "
					+ "where einv_no = ?")
			ps.setString(1, eInvoiceNo)
			rslt = ps.executeQuery()
			while(rslt.next()) {
				result = rslt.getString(1)
			}
		} catch (Exception e) {
			println(String.format("Failed to set user to still logged in: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return result
	}
}

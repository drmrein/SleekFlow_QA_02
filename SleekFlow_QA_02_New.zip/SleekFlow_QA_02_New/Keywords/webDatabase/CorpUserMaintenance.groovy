package webDatabase

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.sql.PreparedStatement
import java.sql.Timestamp

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

public class CorpUserMaintenance extends PostgreConnection {

	@Keyword
	def inactivate(String userId, String corpId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update IDM_USER set "
					+ "is_inactive = 'Y', "
					+ "status = 'INACTIVE' "
					+ "where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?);")
			ps.setString(1, userId)
			ps.setString(2, corpId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to inactivate user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def lock(String userId, String corpId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update IDM_USER set "
					+ "status = 'LOCKED', "
					+ "login_count = 99 "
					+ "where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?);")
			ps.setString(1, userId)
			ps.setString(2, corpId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to lock user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}

	@Keyword
	def activate(String userId, String corpId) {
		Timestamp currentTime = new Timestamp(new Date().getTime())
		PreparedStatement ps = null
		int updated = 0
		try {
			connect()
			ps = getConnection().prepareStatement(
					"update IDM_USER set "
					+ "is_inactive = 'N', "
					+ "status = 'ACTIVE' "
					+ "where user_id in (select id from pcc_corp_usr where user_id = ? and corp_id = ?);")
			ps.setString(1, userId)
			ps.setString(2, corpId)
			updated = ps.executeUpdate()
		} catch (Exception e) {
			println(String.format("Failed to activate or reset user: %s", e.getMessage()))
		} finally {
			closeConnection()
		}
		return updated
	}
}

package report

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.text.SimpleDateFormat
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
//import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import groovy.transform.CompileStatic
import internal.GlobalVariable

public class CompareCSV {

	static def String SEPARATOR = ",";
	static def String LINEBREAK = "\r\n";

	@CompileStatic
	@Keyword
	static def extractDownloadedReport(String dirPath, boolean shouldExtract) {
		// def dirPath = "C:\\users\\fiqa.taufik\\Downloads"
		File dir = new File(dirPath);
		String[] files = dir.list();
		File downloadedFile = null;
		for (def f in files) {
			if (downloadedFile == null) {
				downloadedFile = new File(dirPath + "\\" + f)
			} else {
				def fO = new File(dirPath + "\\" + f)
				if (fO.lastModified() > downloadedFile.lastModified()) {
					downloadedFile = new File(dirPath + "\\" + f)
				}
			}
		}

		//	if file is in zip, then extract
		def ext = downloadedFile.getName().substring(downloadedFile.getName().indexOf(".")+1)
		if (ext.equalsIgnoreCase("zip") && shouldExtract) {
			// def extracted =
			ZipInputStream zip = new ZipInputStream(new FileInputStream(downloadedFile))
			ZipEntry entry = zip.getNextEntry(); // get 1 file in zip

			//
			def outputPath = dirPath + "\\" + entry;
			def outputstream = new BufferedOutputStream(new FileOutputStream(outputPath));
			def bytesIn = new byte[4096]
			int read = 0
			while ((read = zip.read(bytesIn)) != -1) {
				outputstream.write(bytesIn,0,read)
			}
			outputstream.close()

			println("extracted: " + outputPath)
			downloadedFile = new File(outputPath)
		}
		return downloadedFile
	}

	static def readFile(File file) {
		FileInputStream fs = null;
		StringBuilder sb = new StringBuilder()
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		fs = new FileInputStream(file);
		int i = fs.read();
		while (i != -1) {
			baos.write(i);
			i = fs.read();
		}
		sb.append(new String(baos.toByteArray()));
		return sb.toString()
	}

	@CompileStatic
	@Keyword
	static def doCompare(List listContent, File csvAutomate, String startPeriod,
			String endPeriod, String requestDate, String filename, File downloadedZip) {
		// println("CSV Manual: " + csvManual.getAbsolutePath());
		// println("CSV Automate: " + csvAutomate.getAbsolutePath());

		def isEquals = true;

		//	validasi nama file
		String fileNameWeb = filename;
		if (filename.indexOf(".") > 0) {
			filename = filename.substring(0, filename.indexOf("."))
		}
		String fileNameDownload = downloadedZip.getName()
		fileNameDownload = fileNameDownload.substring(0, fileNameDownload.indexOf("."))
		println("Validate filename: Manual " + fileNameWeb + ", Automate: " + fileNameDownload)
		if (!fileNameWeb.equals(fileNameDownload)) {
			println("Filename doesn't match: Manual " + fileNameWeb + ", Automate: " + fileNameDownload)
			isEquals = false
			return isEquals
		}

		// String contentManual = readFile(csvManual);
		String contentAutomate = readFile(csvAutomate);

		// String[] arrayManual = contentManual.split(LINEBREAK);
		List listHeader = listContent.get(0);
		String[] arrayAutomate = contentAutomate.split(LINEBREAK);

		// String headerManual = arrayManual[0];
		String headerAutomate = arrayAutomate[0];

		// String[] arrHeaderManual = headerManual.split(SEPARATOR);
		String[] arrHeaderAutomate = headerAutomate.split(SEPARATOR);

		//	jika jumlah header tidak sama
		if (listHeader.size() != arrHeaderAutomate.length) {
			isEquals = false;
			println("Different number of header: Manual ("+listHeader.size()+"), Automate ("+arrHeaderAutomate.length+")")
		} else {
			for(int i = 0; i < listHeader.size(); i++) {
				String strHeaderManual = (String) listHeader.get(i);
				if (!strHeaderManual.equalsIgnoreCase(arrHeaderAutomate[i])) {
					println("Header #"+(i + 1)+" doesn't match: Manual ("+strHeaderManual+"), Automate ("+arrHeaderAutomate[i]+")")
					isEquals = false;
					break;
				}
			}
		}

		// compare content
		if (isEquals) {
			if (listContent.size() != arrayAutomate.length) {
				isEquals = false;
				println("Num of rows doesn't match: Manual " + listContent.size() + ", Automate: " + arrayAutomate.length)
			} else {
				for (int i = 1; i < listContent.size(); i++) {
					List arrLineManual = listContent.get(i);
					String[] arrLineAutomate = arrayAutomate[i].split(SEPARATOR);
					for (int j = 0; j < arrLineManual.size(); j++) {
						if (!arrLineManual.get(j).equals(arrLineAutomate[j])) {
							isEquals = false
							println ("Content doesn't match at row " + (i + 1) + ", column: " + (j+1) + ": Manual " + arrLineManual.get(j) + ", Automate: " + arrLineAutomate[j])
							break
						}
					}
				}
			}
		}

		return isEquals;
	}

	@CompileStatic
	@Keyword
	static def getInquiryListContent(String idFrameLogin, String idMainFrame, String idTable){
		
		List listHeaderTable = new ArrayList()
		List listContentTable = new ArrayList()

		// def tableHeaders = findTestObject('inquiry/Page_Danamon Cash Connect/tableHeader_cols')
		def driver = DriverFactory.getWebDriver()

		((WebDriver) driver).switchTo().frame(((WebDriver) driver).findElement(By.xpath("//iframe[@id='"+idFrameLogin+"']")))
		((WebDriver) driver).switchTo().frame(((WebDriver) driver).findElement(By.xpath("//iframe[@id='"+idMainFrame+"']")))
		def tableData = ((WebDriver) driver).findElement(By.xpath("//*[@id='"+idTable+"']"))

		//	Baca Header
		def tableHeader = ((WebElement) tableData).findElement(By.xpath("//thead/tr"))
		def arrElHeader = ((WebElement) tableHeader).findElements(By.tagName("th")) as WebElement[]

		List header = new ArrayList()
		for (o in arrElHeader) {
			// listHeaderTable.add(((WebElement) o).getText())
			header.add(((WebElement) o).getText())
		}
		listContentTable.add(header)

		//	Baca Content
		def tableBody = ((WebElement) tableData).findElement(By.xpath("//tbody")) as WebElement
		def arrContentRows = ((WebElement) tableBody).findElements(By.tagName("tr")) as WebElement[]

		for (o in arrContentRows) {
			List content = new ArrayList()
			def cols = ((WebElement) o).findElements(By.tagName("td")) as WebElement
			for (p in cols) {
				content.add(((WebElement) p).getText())
			}
			listContentTable.add(content)
		}

		// driver = DriverFactory.getWebDriver()
		// ((WebDriver) driver).switchTo().frame(((WebDriver) driver).findElement(By.xpath("//iframe[@id='login']")))
		((WebDriver) driver).switchTo().defaultContent()


		return listContentTable
	}

	@CompileStatic
	@Keyword
	static def getDownloadParameter(String idFrameLogin, String idMainFrame, String idTable, String idFromDate, String idToDate){
		// login
		// mainFrame
		// globalTable
		// fromDate
		// toDate
		def startPeriod = null
		def endPeriod = null
		def requestDate = null
		def filename = null

		//	Baca Content
		def driver = DriverFactory.getWebDriver()

		((WebDriver) driver).switchTo().frame(((WebDriver) driver).findElement(By.xpath("//iframe[@id='"+idFrameLogin+"']")))
		((WebDriver) driver).switchTo().frame(((WebDriver) driver).findElement(By.xpath("//iframe[@id='"+idMainFrame+"']")))
		def oTableDownload = ((WebDriver) driver).findElement(By.xpath("//*[@id='"+idTable+"']"))

		def tableBody = ((WebElement) oTableDownload).findElement(By.xpath("//tbody")) as WebElement
		def arrContentRows = ((WebElement) tableBody).findElements(By.tagName("tr")) as WebElement[]
		def cols = ((WebElement) arrContentRows[0]).findElements(By.tagName("td")) as WebElement[]
		def tdRequestDate = (WebElement) cols[3]
		def tdFileName = (WebElement) cols[1]
		println("Request Date: " +  ((WebElement) tdRequestDate).getText() )

		def oFromDate = ((WebDriver) driver).findElement(By.xpath("//*[@id='"+idFromDate+"']"))
		def oToDate = ((WebDriver) driver).findElement(By.xpath("//*[@id='"+idToDate+"']"))

		requestDate = ((WebElement) tdRequestDate).getText()
		startPeriod = ((WebElement) oFromDate).getAttribute("value")
		endPeriod = ((WebElement) oToDate).getAttribute("value")
		filename = ((WebElement) tdFileName).getText()

		println("requestDate: " + requestDate)
		println("startPeriod: " + startPeriod)
		println("endPeriod: " + endPeriod)
		println("filename: " + filename)

		((WebDriver) driver).switchTo().defaultContent()

		Map map = new HashMap ();
		map.put("requestDate", requestDate)
		map.put("startPeriod", startPeriod)
		map.put("endPeriod", endPeriod)
		map.put("filename", filename)
		return map
	}

	@CompileStatic
	@Keyword
	static def compareCsvToWeb(List inqListContentTable, String idFrameLogin, String idMainFrame,
			String idTable, String idFromDate, String idToDate, String dirPath) {

		//	baca parameter di halaman download
		def mapDownload = CompareCSV.getDownloadParameter(idFrameLogin, idMainFrame, idTable, idFromDate, idToDate)
		def startPeriod = ((Map) mapDownload).get("startPeriod")
		def endPeriod = ((Map) mapDownload).get("endPeriod")
		def requestDate = ((Map) mapDownload).get("requestDate")
		def filename = ((Map) mapDownload).get("filename")
		//	sampai sini
	
		def downloadedZip = CompareCSV.extractDownloadedReport(dirPath, false)
		def downloadedFile = CompareCSV.extractDownloadedReport(dirPath, true)

		def dStartPeriod = CompareCSV.parseDate((String)startPeriod, "dd MMM yyyy")
		startPeriod = CompareCSV.formatDate((Date) dStartPeriod, "MMMM dd, yyyy")

		def dEndPeriod = CompareCSV.parseDate((String)endPeriod, "dd MMM yyyy")
		endPeriod = CompareCSV.formatDate((Date) dEndPeriod, "MMMM dd, yyyy")

		def dRequestDate = CompareCSV.parseDate((String)requestDate, "dd-MM-yyyy HH:mm:ss")
		requestDate = CompareCSV.formatDate((Date) dRequestDate, "MMMM dd, yyyy HH:mm")

		Boolean isEquals = CompareCSV.doCompare(inqListContentTable, (File) downloadedFile, (String)startPeriod, (String)endPeriod, (String)requestDate, (String)filename, (File) downloadedZip)
		return isEquals
	}

	@CompileStatic
	@Keyword
	static def parseDate(String inputDate, String format) {
		Date date = null
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		date = dateFormatter.parse(inputDate)
		return date
	}

	@CompileStatic
	@Keyword
	static def formatDate(Date inputDate, String format) {
		String date = null
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		date = dateFormatter.format(inputDate)
		return date
	}


}

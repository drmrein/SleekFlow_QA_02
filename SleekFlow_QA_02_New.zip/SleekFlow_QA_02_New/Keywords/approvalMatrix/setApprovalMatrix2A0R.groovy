package approvalMatrix

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class setApprovalMatrix2A0R {

	TestObject pr = new TestObject()

	TestObject pr2 = new TestObject()
	@Keyword
	def runsetApprovalMatrix2A0R(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		//approval listing
		String xpath = "//div[@class='overFlowTable' and contains(.,'Approval Listing')]//tr[@class='parent odd'][1]"

		String rangeLimitApproval = xpath +"//td[2]"
		String autoApproveReject = xpath + "//td[3]"
		String autoAuthorize = xpath + "//td[4]"
		String schema = xpath + "//td[5]"
		String checkBoxAll = "//input[@type= 'checkbox' and @class='checkAll']"
		String deleteList = "//button[@id= 'btnRemoveList']"
		String addToList = "//button[@id= 'btnAddToList']"


		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testcheckBoxAll = new TestObject()
		TestObject testdeleteList = new TestObject()
		TestObject testaddToList = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testcheckBoxAll.setParentObject(pr2)
		testdeleteList.setParentObject(pr2)
		testaddToList.setParentObject(pr2)

		testObject.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval)
		testObject2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject)
		testObject3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize)
		testObject4.addProperty("xpath", ConditionType.EQUALS, schema)
		testcheckBoxAll.addProperty("xpath", ConditionType.EQUALS, checkBoxAll)
		testdeleteList.addProperty("xpath", ConditionType.EQUALS, deleteList)
		testaddToList.addProperty("xpath", ConditionType.EQUALS, addToList)

		//add new listing
		String xpath2 = "//div[@class='overFlowTable' and contains(.,'Add New')]//tr[@class='parent odd'][1]"


		String rangeLimitApproval2 = xpath2 +"//td[1]//input[@placeholder='Range Limit Approval']"
		String autoApproveReject2 = xpath2 + "//td[2]//input[@placeholder='Days Before Auto Reject/Approve']"
		String autoAuthorize2 = xpath2 + "//td[3]//div[@id='s2id_autogen1']"
		String approvalLevel = "//div[@id='s2id_autogen2']"
		String userGroup = "//div[@id='s2id_autogen3']"
		String schema2 = xpath2 + "//td[4]"
		String approver = "//input[@placeholder='Input No. Of User']"
		String approvalNo = "//input[@placeholder='No. Of Approval']"
		String releaserCheckbox = "//input[@id='lastApprovalReleaser']"
		String releaserStatus = "//span[@class='label label-warning label_width' and contains(.,'No')]"

		TestObject testObjectRes = new TestObject()
		TestObject testObjectRes2= new TestObject()
		TestObject testObjectRes3 = new TestObject()
		TestObject testObjectRes4 = new TestObject()
		TestObject testApprover = new TestObject()
		TestObject testReleaser = new TestObject()
		TestObject testauthorize= new TestObject()
		TestObject testReleaserStatus = new TestObject()
		TestObject testApprovalLevel = new TestObject()
		TestObject testApprovallevelChoice = new TestObject()
		TestObject testUserGroup = new TestObject()
		TestObject testUserGroupChoice = new TestObject()
		TestObject testapprovalNo = new TestObject()

		testObjectRes.setParentObject(pr2)
		testObjectRes2.setParentObject(pr2)
		testObjectRes3.setParentObject(pr2)
		testObjectRes4.setParentObject(pr2)
		testApprover.setParentObject(pr2)
		testReleaser.setParentObject(pr2)
		testauthorize.setParentObject(pr2)
		testReleaserStatus.setParentObject(pr2)
		testApprovalLevel.setParentObject(pr2)
		testApprovallevelChoice.setParentObject(pr2)
		testUserGroup.setParentObject(pr2)
		testUserGroupChoice.setParentObject(pr2)
		testapprovalNo.setParentObject(pr2)

		testObjectRes.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval2)
		testObjectRes2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject2)
		testObjectRes3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize2)
		testObjectRes4.addProperty("xpath", ConditionType.EQUALS, schema2)
		testApprover.addProperty("xpath", ConditionType.EQUALS, approver)
		testReleaser.addProperty("xpath", ConditionType.EQUALS, releaserCheckbox)
		testReleaserStatus.addProperty("xpath", ConditionType.EQUALS, releaserStatus)
		testApprovalLevel.addProperty("xpath", ConditionType.EQUALS, approvalLevel)
		testUserGroup.addProperty("xpath", ConditionType.EQUALS, userGroup)
		testapprovalNo.addProperty("xpath", ConditionType.EQUALS, approvalNo)


		def rangeLimit = WebUI.getText(testObject)
		def autoApproveRejectLimit = WebUI.getText(testObject2)
		def autoAuthorizeLimit = WebUI.getText(testObject3)
		String authorizexpath = '//div[@class="select2-result-label" and contains(.,"'+autoAuthorizeLimit+'")]'
		testauthorize.addProperty("xpath", ConditionType.EQUALS, authorizexpath)
		String approvallvlxpath = '//div[@class="select2-result-label" and contains(.,"any")]'
		testApprovallevelChoice.addProperty("xpath", ConditionType.EQUALS, approvallvlxpath)
		String userGroupxpath = '//div[@class="select2-result-label" and contains(.,"Any Group")]'
		testUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, userGroupxpath)
		def schemaLimit = WebUI.getText(testObject4)

		KeywordUtil.logInfo("$rangeLimit is the range limit")
		KeywordUtil.logInfo("$autoApproveRejectLimit is the range limit")
		KeywordUtil.logInfo("$autoAuthorizeLimit is the range limit")
		KeywordUtil.logInfo("$schemaLimit is the range limit")

		try{
			if(WebUI.verifyElementNotPresent(testReleaserStatus, 5)){
				WebUI.uncheck(testReleaser)
			}
		}catch(Exception e){
			KeywordUtil.logInfo("element already not checked")
		}

		WebUI.setText(testObjectRes, rangeLimit)
		WebUI.setText(testObjectRes2, autoApproveRejectLimit)
		WebUI.click(testObjectRes3)
		WebUI.click(testauthorize)
		//		for(int it = 1; it < schemaLimit; it++){
		//			WebUI.click(testObjectRes4)
		//		}

		WebUI.check(testcheckBoxAll)
		WebUI.click(testdeleteList)

		WebUI.clearText(testapprovalNo)
		WebUI.setText(testapprovalNo, "2")
		WebUI.setText(testApprover, "2")
		WebUI.scrollToElement(testApprovalLevel, 0)
		WebUI.click(testApprovalLevel)
		WebUI.click(testApprovallevelChoice)
		WebUI.scrollToElement(testUserGroup, 0)
		WebUI.click(testUserGroup)
		WebUI.click(testUserGroupChoice)
		WebUI.click(testaddToList)


	}

}

package approvalMatrix

import java.math.RoundingMode
import java.text.NumberFormat;

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class SetApprovalMatrix {

	TestObject pr = new TestObject()

	TestObject pr2 = new TestObject()

	@Keyword
	def setApprovalMatrixSingleSequence(String rangelimitapproval, String NoofApproval, String NoofUser, String ApprovalLevel, String UserGroupOption, List<String> TargetUserGroup = [], List<String> TargetUser = []){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		//add new listing
		String xpath2 = "//tr[@data-row-key and not(@aria-hidden = 'true')]"

		String rangeLimitApproval = xpath2 +"//input[@id='t-range_limit_approval']"
		//		String sequential = xpath2 + "//input[@id='t-checkbox-sequential-SEQUENTIAL']"
		String approvalTotal = xpath2 + "//input[@id='t-no_of_approval']"
		String approvalUserTotal = xpath2 + "//input[@id='t-no_of_user-0']"
		String approvalLevelDDL = xpath2 + "//div[@id='t-select-approval_level-0-trigger']"
		String approvalLevelChoice = "//li[contains(@id, 't-approval_level') and text()='$ApprovalLevel']"
		String userGroupDDL = xpath2 + "//div[@id='t-select-user_group_option-0-trigger']"
		String userGroupChoice = "//li[contains(@id, 't-user_group_option') and text()='$UserGroupOption']"


		TestObject objectRangeLimitApproval = new TestObject()
		//		TestObject objectSequential= new TestObject()
		TestObject objectApprovalTotal = new TestObject()
		TestObject objectApprovalUserTotal = new TestObject()
		TestObject objectApprovalLevelDDL = new TestObject()
		TestObject objectApprovalLevelChoice = new TestObject()
		TestObject objectUserGroupDDL= new TestObject()
		TestObject objectUserGroupChoice = new TestObject()

		objectRangeLimitApproval.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval)
		//		objectSequential.addProperty("xpath", ConditionType.EQUALS, sequential)
		objectApprovalTotal.addProperty("xpath", ConditionType.EQUALS, approvalTotal)
		objectApprovalUserTotal.addProperty("xpath", ConditionType.EQUALS, approvalUserTotal)
		objectApprovalLevelDDL.addProperty("xpath", ConditionType.EQUALS, approvalLevelDDL)
		objectApprovalLevelChoice.addProperty("xpath", ConditionType.EQUALS, approvalLevelChoice)
		objectUserGroupDDL.addProperty("xpath", ConditionType.EQUALS, userGroupDDL)
		objectUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, userGroupChoice)

		//object for scroll
		TestObject objectTitleApprovalMatrix = new TestObject()
		objectTitleApprovalMatrix.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,'Approval Matrix')]")


		//input range limit approval
		WebUI.verifyElementPresent(objectRangeLimitApproval, 0)
		WebUI.scrollToElement(objectTitleApprovalMatrix, 0)
		WebUI.click(objectRangeLimitApproval)
		WebUI.setText(objectRangeLimitApproval, rangelimitapproval)


		//input no of approval
		WebUI.verifyElementPresent(objectApprovalTotal, 0)
		WebUI.click(objectApprovalTotal)
		WebUI.setText(objectApprovalTotal, NoofApproval)

		//input no of approval user
		WebUI.verifyElementPresent(objectApprovalUserTotal, 0)
		WebUI.click(objectApprovalUserTotal)
		WebUI.setText(objectApprovalUserTotal, NoofUser)

		//select approval level
		WebUI.verifyElementPresent(objectApprovalLevelDDL, 0)
		WebUI.click(objectApprovalLevelDDL)
		WebUI.click(objectApprovalLevelChoice)

		//select user group option
		WebUI.verifyElementPresent(objectUserGroupDDL, 0)
		WebUI.click(objectUserGroupDDL)
		WebUI.click(objectUserGroupChoice)

		if(UserGroupOption.equals("Specific Group")){

			String targetUserGroupDDL = xpath2 + "//div[@id='t-select-target_user_group-0-trigger']"

			TestObject objectTargetUserGroupDDL = new TestObject()

			objectTargetUserGroupDDL.addProperty("xpath", ConditionType.EQUALS, targetUserGroupDDL)

			WebUI.verifyElementPresent(objectTargetUserGroupDDL, 0)
			WebUI.click(objectTargetUserGroupDDL)

			for(int ug = 0; ug <TargetUserGroup.size(); ug++){
				String currentTarget = TargetUserGroup.get(ug)

				String targetUserGroupChoice = "//li[contains(@id, 't-target_user_group') and contains(.,'$currentTarget')]"

				TestObject objectTargetUserGroupChoice = new TestObject()

				objectTargetUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, targetUserGroupChoice)

				WebUI.click(objectTargetUserGroupChoice)

			}

			String targetUserDDL = xpath2 + "//div[@id='t-select-target_user-0-trigger']"

			TestObject objectTargetUserDDL = new TestObject()

			objectTargetUserDDL.addProperty("xpath", ConditionType.EQUALS, targetUserDDL)

			WebUI.verifyElementPresent(objectTargetUserDDL, 0)
			WebUI.click(objectTargetUserDDL)

			for(int u = 0; u <TargetUser.size(); u++){
				String currentTarget = TargetUser.get(u)

				String targetUserChoice = "//li[contains(@id, 't-target_user') and contains(.,'$currentTarget')]"

				TestObject objectTargetUserChoice = new TestObject()

				objectTargetUserChoice.addProperty("xpath", ConditionType.EQUALS, targetUserChoice)

				WebUI.click(objectTargetUserChoice)

			}

		}

		//add to list

		TestObject objectAddtoList = new TestObject()
		objectAddtoList.addProperty("xpath", ConditionType.EQUALS, "//button[@id='t-add-to-list']")

		WebUI.verifyElementPresent(objectAddtoList, 0)
		WebUI.click(objectAddtoList)

		//verify added to list
		String xpathVerify = "//div[@role='separator' and contains(.,'Approval Listing')]/following-sibling::div//tr[@data-row-key and not(@aria-hidden = 'true')][last()]"

		String rangeLimitApprovalVerify = xpathVerify +"//div[@id='t-ApprovalMatrixInput-range_amount_limit']"
		//		String sequentialVerify = xpathVerify + "//div[@id='t-ApprovalMatrixInput-sequence']"
		String approvalTotalVerify = xpathVerify + "//div[@id='t-ApprovalMatrixInput-no_of_approval']"
		String approvalUserTotalVerify = xpathVerify + "//div[@id='t-ApprovalMatrixInput-no_of_user']"
		String approvalLevelDDLVerify = xpathVerify + "//div[@id='t-ApprovalMatrixInput-approval_level']"
		String userGroupDDLVerify = xpathVerify + "//div[@id='t-ApprovalMatrixInput-user_group_option']"

		TestObject objectRangeLimitApprovalVerify = new TestObject()
		//		TestObject objectSequentialVerify= new TestObject()
		TestObject objectApprovalTotalVerify = new TestObject()
		TestObject objectApprovalUserTotalVerify = new TestObject()
		TestObject objectApprovalLevelDDLVerify = new TestObject()
		TestObject objectApprovalLevelChoiceVerify = new TestObject()
		TestObject objectUserGroupDDLVerify= new TestObject()
		TestObject objectUserGroupChoiceVerify = new TestObject()

		objectRangeLimitApprovalVerify.addProperty("xpath", ConditionType.EQUALS, rangeLimitApprovalVerify)
		//		objectSequentialVerify.addProperty("xpath", ConditionType.EQUALS, sequentialVerify)
		objectApprovalTotalVerify.addProperty("xpath", ConditionType.EQUALS, approvalTotalVerify)
		objectApprovalUserTotalVerify.addProperty("xpath", ConditionType.EQUALS, approvalUserTotalVerify)
		objectApprovalLevelDDLVerify.addProperty("xpath", ConditionType.EQUALS, approvalLevelDDLVerify)
		objectUserGroupDDLVerify.addProperty("xpath", ConditionType.EQUALS, userGroupDDLVerify)

		//object for scroll
		TestObject objectTitleApprovalList = new TestObject()
		objectTitleApprovalList.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,'Approval Listing')]")

		//verify range limit approval
		WebUI.verifyElementPresent(objectRangeLimitApprovalVerify, 0)
		WebUI.scrollToElement(objectTitleApprovalList, 0)
		String rangelimitResult = WebUI.getText(objectRangeLimitApprovalVerify)
		//format rangelimitResult into currency format
		BigDecimal bd = new BigDecimal(rangelimitapproval);
		bd = bd.setScale(2, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		rangelimitapproval = String.valueOf(format.format(bd)).replace('$', '')

		WebUI.verifyEqual(rangelimitapproval, rangelimitResult)
		WebUI.comment("range limit approval value successfully verified : $rangelimitResult")
		//verify approval total
		WebUI.verifyElementPresent(objectApprovalTotalVerify, 0)
		String approvalTotalResult = WebUI.getText(objectApprovalTotalVerify)
		WebUI.verifyEqual(approvalTotalResult, NoofApproval)
		WebUI.comment("no of approval value successfully verified : $approvalTotalResult")

		//verify approval user total
		WebUI.verifyElementPresent(objectApprovalUserTotalVerify, 0)
		String approvalUserTotalResult = WebUI.getText(objectApprovalUserTotalVerify)
		WebUI.verifyEqual(approvalUserTotalResult, NoofUser)
		WebUI.comment("no of user for approval value successfully verified : $approvalUserTotalResult")

		//verify approval level
		WebUI.verifyElementPresent(objectApprovalLevelDDLVerify, 0)
		String approvalLevelResult = WebUI.getText(objectApprovalLevelDDLVerify)
		WebUI.verifyEqual(approvalLevelResult, ApprovalLevel)
		WebUI.comment("approval level value successfully verified : $approvalLevelResult")

		//verify user group
		WebUI.verifyElementPresent(objectUserGroupDDLVerify, 0)
		String userGroupResult = WebUI.getText(objectUserGroupDDLVerify)
		WebUI.verifyEqual(userGroupResult, UserGroupOption)
		WebUI.comment("user group value successfully verified : $userGroupResult")

		if(UserGroupOption.equals("Specific Group")){


			for(int ug = 0; ug <TargetUserGroup.size(); ug++){
				String currentTarget = TargetUserGroup.get(ug)
				int counter = ug+1
				String targetUserGroupChoice = xpathVerify + "//div[@id='t-ApprovalMatrixInput-target_user_group']//span[$counter]"

				TestObject objectTargetUserGroupChoice = new TestObject()

				objectTargetUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, targetUserGroupChoice)

				WebUI.verifyElementPresent(objectTargetUserGroupChoice, 0)
				String targetUserGroupResult = WebUI.getText(objectTargetUserGroupChoice)
				if(currentTarget.contains(targetUserGroupResult)){
					WebUI.comment("target user group value successfully verified : $currentTarget")
				}

			}


			for(int u = 0; u <TargetUser.size(); u++){
				String currentTarget = TargetUser.get(u)
				int counter = u+1
				String targetUserChoice = xpathVerify + "//div[@id='t-ApprovalMatrixInput-target_user']//span[$counter]"

				TestObject objectTargetUserChoice = new TestObject()

				objectTargetUserChoice.addProperty("xpath", ConditionType.EQUALS, targetUserChoice)

				WebUI.verifyElementPresent(objectTargetUserChoice, 0)
				String targetUserResult = WebUI.getText(objectTargetUserChoice)
				if(currentTarget.contains(targetUserResult)){
					WebUI.comment("target user value successfully verified : $currentTarget")
				}

			}

		}

		WebUI.comment("new approval successfully added to approval listing")
	}


	@Keyword
	def setApprovalMatrix1A0R(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		//approval listing
		String xpath = "//div[@class='overFlowTable' and contains(.,'Approval Listing')]//tr[@class='parent odd'][1]"

		String rangeLimitApproval = xpath +"//td[2]"
		String autoApproveReject = xpath + "//td[3]"
		String autoAuthorize = xpath + "//td[4]"
		String schema = xpath + "//td[5]"


		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		testObject.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval)
		testObject2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject)
		testObject3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize)
		testObject4.addProperty("xpath", ConditionType.EQUALS, schema)

		//add new listing
		String xpath2 = "//div[@class='overFlowTable' and contains(.,'Add New')]//tr[@class='parent odd'][1]"

		String rangeLimitApproval2 = xpath2 +"//td[1]//input[@placeholder='Range Limit Approval']"
		String autoApproveReject2 = xpath2 + "//td[2]//input[@placeholder='Days Before Auto Reject/Approve']"
		String autoAuthorize2 = xpath2 + "//td[3]//div[@id='s2id_autogen1']"
		String approvalLevel = "//div[@id='s2id_autogen2']"
		String userGroup = "//div[@id='s2id_autogen3']"
		String schema2 = xpath2 + "//td[4]"
		String approver = "//input[@placeholder='Input No. Of User']"
		String releaserCheckbox = "//input[@id='lastApprovalReleaser']"
		String releaserStatus = "//span[@class='label label-warning label_width' and contains(.,'No')]"

		TestObject testObjectRes = new TestObject()
		TestObject testObjectRes2= new TestObject()
		TestObject testObjectRes3 = new TestObject()
		TestObject testObjectRes4 = new TestObject()
		TestObject testApprover = new TestObject()
		TestObject testReleaser = new TestObject()
		TestObject testauthorize= new TestObject()
		TestObject testReleaserStatus = new TestObject()
		TestObject testApprovalLevel = new TestObject()
		TestObject testApprovallevelChoice = new TestObject()
		TestObject testUserGroup = new TestObject()
		TestObject testUserGroupChoice = new TestObject()

		testObjectRes.setParentObject(pr2)
		testObjectRes2.setParentObject(pr2)
		testObjectRes3.setParentObject(pr2)
		testObjectRes4.setParentObject(pr2)
		testApprover.setParentObject(pr2)
		testReleaser.setParentObject(pr2)
		testauthorize.setParentObject(pr2)
		testReleaserStatus.setParentObject(pr2)
		testApprovalLevel.setParentObject(pr2)
		testApprovallevelChoice.setParentObject(pr2)
		testUserGroup.setParentObject(pr2)
		testUserGroupChoice.setParentObject(pr2)

		testObjectRes.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval2)
		testObjectRes2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject2)
		testObjectRes3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize2)
		testObjectRes4.addProperty("xpath", ConditionType.EQUALS, schema2)
		testApprover.addProperty("xpath", ConditionType.EQUALS, approver)
		testReleaser.addProperty("xpath", ConditionType.EQUALS, releaserCheckbox)
		testReleaserStatus.addProperty("xpath", ConditionType.EQUALS, releaserStatus)
		testApprovalLevel.addProperty("xpath", ConditionType.EQUALS, approvalLevel)
		testUserGroup.addProperty("xpath", ConditionType.EQUALS, userGroup)



		def rangeLimit = WebUI.getText(testObject)
		def autoApproveRejectLimit = WebUI.getText(testObject2)
		def autoAuthorizeLimit = WebUI.getText(testObject3)
		String authorizexpath = '//div[@class="select2-result-label" and contains(.,"'+autoAuthorizeLimit+'")]'
		testauthorize.addProperty("xpath", ConditionType.EQUALS, authorizexpath)
		String approvallvlxpath = '//div[@class="select2-result-label" and contains(.,"any")]'
		testApprovallevelChoice.addProperty("xpath", ConditionType.EQUALS, approvallvlxpath)
		String userGroupxpath = '//div[@class="select2-result-label" and contains(.,"Any Group")]'
		testUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, userGroupxpath)
		def schemaLimit = WebUI.getText(testObject4)

		KeywordUtil.logInfo("$rangeLimit is the range limit")
		KeywordUtil.logInfo("$autoApproveRejectLimit is the range limit")
		KeywordUtil.logInfo("$autoAuthorizeLimit is the range limit")
		KeywordUtil.logInfo("$schemaLimit is the range limit")

		if(WebUI.verifyElementNotPresent(testReleaserStatus, 5)){
			WebUI.uncheck(testReleaser)
		}

		WebUI.setText(testObjectRes, rangeLimit)
		WebUI.setText(testObjectRes2, autoApproveRejectLimit)
		WebUI.click(testObjectRes3)
		WebUI.click(testauthorize)
		//		for(int it = 1; it < schemaLimit; it++){
		//			WebUI.click(testObjectRes4)
		//		}

		WebUI.setText(testApprover, "1")
		WebUI.scrollToElement(testApprovalLevel, 0)
		WebUI.click(testApprovalLevel)
		WebUI.click(testApprovallevelChoice)
		WebUI.scrollToElement(testUserGroup, 0)
		WebUI.click(testUserGroup)
		WebUI.click(testUserGroupChoice)


	}

	@Keyword
	def setApprovalMatrix2A0R(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		//approval listing
		String xpath = "//div[@class='overFlowTable' and contains(.,'Approval Listing')]//tr[@class='parent odd'][1]"

		String rangeLimitApproval = xpath +"//td[2]"
		String autoApproveReject = xpath + "//td[3]"
		String autoAuthorize = xpath + "//td[4]"
		String schema = xpath + "//td[5]"


		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		testObject.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval)
		testObject2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject)
		testObject3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize)
		testObject4.addProperty("xpath", ConditionType.EQUALS, schema)

		//add new listing
		String xpath2 = "//div[@class='overFlowTable' and contains(.,'Add New')]//tr[@class='parent odd'][1]"


		String rangeLimitApproval2 = xpath2 +"//td[1]//input[@placeholder='Range Limit Approval']"
		String autoApproveReject2 = xpath2 + "//td[2]//input[@placeholder='Days Before Auto Reject/Approve']"
		String autoAuthorize2 = xpath2 + "//td[3]//div[@id='s2id_autogen1']"
		String approvalLevel = "//div[@id='s2id_autogen2']"
		String userGroup = "//div[@id='s2id_autogen3']"
		String schema2 = xpath2 + "//td[4]"
		String approver = "//input[@placeholder='Input No. Of User']"
		String releaserCheckbox = "//input[@id='lastApprovalReleaser']"
		String releaserStatus = "//span[@class='label label-warning label_width' and contains(.,'No')]"

		TestObject testObjectRes = new TestObject()
		TestObject testObjectRes2= new TestObject()
		TestObject testObjectRes3 = new TestObject()
		TestObject testObjectRes4 = new TestObject()
		TestObject testApprover = new TestObject()
		TestObject testReleaser = new TestObject()
		TestObject testauthorize= new TestObject()
		TestObject testReleaserStatus = new TestObject()
		TestObject testApprovalLevel = new TestObject()
		TestObject testApprovallevelChoice = new TestObject()
		TestObject testUserGroup = new TestObject()
		TestObject testUserGroupChoice = new TestObject()

		testObjectRes.setParentObject(pr2)
		testObjectRes2.setParentObject(pr2)
		testObjectRes3.setParentObject(pr2)
		testObjectRes4.setParentObject(pr2)
		testApprover.setParentObject(pr2)
		testReleaser.setParentObject(pr2)
		testauthorize.setParentObject(pr2)
		testReleaserStatus.setParentObject(pr2)
		testApprovalLevel.setParentObject(pr2)
		testApprovallevelChoice.setParentObject(pr2)
		testUserGroup.setParentObject(pr2)
		testUserGroupChoice.setParentObject(pr2)

		testObjectRes.addProperty("xpath", ConditionType.EQUALS, rangeLimitApproval2)
		testObjectRes2.addProperty("xpath", ConditionType.EQUALS, autoApproveReject2)
		testObjectRes3.addProperty("xpath", ConditionType.EQUALS, autoAuthorize2)
		testObjectRes4.addProperty("xpath", ConditionType.EQUALS, schema2)
		testApprover.addProperty("xpath", ConditionType.EQUALS, approver)
		testReleaser.addProperty("xpath", ConditionType.EQUALS, releaserCheckbox)
		testReleaserStatus.addProperty("xpath", ConditionType.EQUALS, releaserStatus)
		testApprovalLevel.addProperty("xpath", ConditionType.EQUALS, approvalLevel)
		testUserGroup.addProperty("xpath", ConditionType.EQUALS, userGroup)



		def rangeLimit = WebUI.getText(testObject)
		def autoApproveRejectLimit = WebUI.getText(testObject2)
		def autoAuthorizeLimit = WebUI.getText(testObject3)
		String authorizexpath = '//div[@class="select2-result-label" and contains(.,"'+autoAuthorizeLimit+'")]'
		testauthorize.addProperty("xpath", ConditionType.EQUALS, authorizexpath)
		String approvallvlxpath = '//div[@class="select2-result-label" and contains(.,"any")]'
		testApprovallevelChoice.addProperty("xpath", ConditionType.EQUALS, approvallvlxpath)
		String userGroupxpath = '//div[@class="select2-result-label" and contains(.,"Any Group")]'
		testUserGroupChoice.addProperty("xpath", ConditionType.EQUALS, userGroupxpath)
		def schemaLimit = WebUI.getText(testObject4)

		KeywordUtil.logInfo("$rangeLimit is the range limit")
		KeywordUtil.logInfo("$autoApproveRejectLimit is the range limit")
		KeywordUtil.logInfo("$autoAuthorizeLimit is the range limit")
		KeywordUtil.logInfo("$schemaLimit is the range limit")


		if(WebUI.verifyElementNotPresent(testReleaserStatus, 5)){
			WebUI.uncheck(testReleaser)
		}

		WebUI.setText(testObjectRes, rangeLimit)
		WebUI.setText(testObjectRes2, autoApproveRejectLimit)
		WebUI.click(testObjectRes3)
		WebUI.click(testauthorize)
		//		for(int it = 1; it < schemaLimit; it++){
		//			WebUI.click(testObjectRes4)
		//		}


		WebUI.setText(testApprover, '2')
		WebUI.scrollToElement(testApprovalLevel, 0)
		WebUI.click(testApprovalLevel)
		WebUI.click(testApprovallevelChoice)
		WebUI.scrollToElement(testUserGroup, 0)
		WebUI.click(testUserGroup)
		WebUI.click(testUserGroupChoice)


	}

}

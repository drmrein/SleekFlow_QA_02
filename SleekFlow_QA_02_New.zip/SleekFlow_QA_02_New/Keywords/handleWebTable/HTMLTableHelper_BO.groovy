package handleWebTable

import java.text.Normalizer
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.stream.Collectors

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class HTMLTableHelper_BO {

	TestObject to = new TestObject()
	def BUTTON_NEXT_ON_TABLE = to.addProperty("xpath", ConditionType.EQUALS, "//button[@class='next btn grid-nextpage']")

	TestObject pr = new TestObject()

	TestObject pr2 = new TestObject()

	String ROW_IN_SPECIFIC_COLUMN_XPATH = '//*[@class="rt-tr-group"][{indexOfRow}]//*[@role="gridcell"][{indexOfColumn}]'//"(//tr/td[{indexOfColumn}])[{indexOfRow}]"
	//variable xpath that represent column header for table in a popup
	//	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'Nomor Rekening')]"
	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'{dinamicValue}')]"
	//variable xpath that represent every row for table in a popup
	static final String TABLE_ROW_POPUP_XPATH = "//tr[@role='row' or @class='odd' or @class='even']"

	//**@role='columnheader' is must be different in every web application. hence, it should be changed to another attribute or selector
	//variable xpath that represent column header
	static final String COLUMN_HEADER_XPATH = "//th[@role='row' or @role='columnheader' or not(@role) and contains(.,'{dinamicValue}')]"
	//variable xpath that represent every row on the table
	static final String TABLE_ROW_XPATH = "//*[@class='odd' or @class='even']"
	//variable xpath that represent the next button on the table

	@Keyword
	def verifyColumnHeader(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders = null){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		TestObject to = new TestObject()

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_XPATH.replace('{dinamicValue}', it))
			to.setParentObject(pr2)

			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def getTotalRowPerPage(){
		WebDriver driver = DriverFactory.getWebDriver()

		try {

			driver.switchTo().frame('login')
			driver.switchTo().frame('mainFrame')
			WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
			List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of list per page: "+list.size())
			WebUI.switchToDefaultContent()
			return list.size()

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of list per page: 0")
			return 0
		}
	}

	@Keyword
	def verifyListOnTableContainsSpecificValue(List<String> data){
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even' or @class='parent odd' or @class='parent even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}


	@Keyword
	def verifyListOnTableContainsSpecificValueBO(List<String> data){
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}


	//belum bisa dipakai
	@Keyword
	def getTotalListOnTableAllPages(){
		int totalAllList = getTotalRowPerPage()
		//		String iframe1 = "//iframe[@id='login']"
		//		String iframe2 = "//iframe[@id='mainFrame']"
		//
		//		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		//		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)
		to.setParentObject(pr2)
		try {

			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				totalAllList += getTotalRowPerPage()
			}

		} catch (Exception e) {
			e.printStackTrace()
		}
		KeywordUtil.logInfo("total number of list on the table: "+totalAllList)
		return totalAllList

	}
	//belum bisa dipakai
	@Keyword
	def verifyAscendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyAscendingByColumnIndex'('3', 'not date')
		//***


		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		to.setParentObject(pr2)

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k < totalRowPerPage+1; k++){
					def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"

					KeywordUtil.logInfo(k.toString())

					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFKD);
					KeywordUtil.logInfo(getText)
					if(!getText.equals('') && !getText.equals(' ') && !getText.equals(null)){
						listOfRowValue.add(getText)
						sort_listOfRowValue.add(getText)
					}

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k < totalRowPerPage+1; k++){

				def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFKD);
				KeywordUtil.logInfo(getText)
				if(!getText.equals('') && !getText.equals(' ') && !getText.equals(null)){
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)
				}
			}
		}

		println "before sort...: "+listOfRowValue
		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
		}
		//		List<String> sorted_ListValue = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder())).collect(Collectors.toList());
		//		List<String> sorted_ListValue2 = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.reverseOrder())).collect(Collectors.toList());

		if(listOfRowValue == sort_listOfRowValue.sort()){
			KeywordUtil.markPassed("List is sorting in ascending order")
		}else{
			if(listOfRowValue == sort_listOfRowValue){
				KeywordUtil.markPassed("List is sorting in ascending order")
			}else{
				KeywordUtil.markFailed("List is not sorting in ascending order")
			}
		}
		println "after sort: "+sort_listOfRowValue

	}
	//belum bisa dipakai
	@Keyword
	def verifyDescendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyDescendingByColumnIndex'('3', 'not date')
		//***


		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		to.setParentObject(pr2)


		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)

		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFD);
					KeywordUtil.logInfo(getText)
					if(!getText.equals('') && !getText.equals(' ') && !getText.equals(null)){
						listOfRowValue.add(getText)
						sort_listOfRowValue.add(getText)
					}

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFD);
				KeywordUtil.logInfo(getText)
				if(!getText.equals('') && !getText.equals(' ') && !getText.equals(null)){
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)
				}

			}
		}

		println "before sort...: "+listOfRowValue
		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
		}
		List<String> sorted_ListValue = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder())).collect(Collectors.toList());
		//		List<String> sorted_ListValue = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.reverseOrder())).collect(Collectors.toList());
		sort_listOfRowValue.sort()
		if(listOfRowValue == sort_listOfRowValue.reverse()){
			KeywordUtil.markPassed("List is sorting in descending order")
		}else{
			if(listOfRowValue == sorted_ListValue.reverse()){
				KeywordUtil.markPassed("List is sorting in descending order")
			}else{
				KeywordUtil.markFailed("List is not sorting in descending order")
			}
		}
		listOfRowValue.sort()
		println "after sort reverse: "+sort_listOfRowValue.reverse()
		println "after sort reverse: "+sorted_ListValue.reverse()

	}
	//belum bisa dipakai
	@Keyword
	def verifySortedRandomlyByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifySortedRandomlyByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sortAsc_listOfRowValue= []
		List sortDesc_listOfRowValue= []
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText = WebUI.getText(rowInSpecificColumn)
					listOfRowValue.add(getText)
					sortAsc_listOfRowValue.add(getText)
					sortDesc_listOfRowValue.add(getText)
				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText = WebUI.getText(rowInSpecificColumn)
				listOfRowValue.add(getText)
				sortAsc_listOfRowValue.add(getText)
				sortDesc_listOfRowValue.add(getText)
			}
		}

		"convert list of string to  list of date"
		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)

			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			for (int i=0; i < sortAsc_listOfRowValue.size(); i++) {
				sortAsc_listOfRowValue[i] =  dateFormat.parse(sortAsc_listOfRowValue[i])
			}
			for (int n=0; n < sortDesc_listOfRowValue.size(); n++) {
				sortDesc_listOfRowValue[n] =  dateFormat.parse(sortDesc_listOfRowValue[n])
			}
		}
		sortDesc_listOfRowValue.sort()
		if(listOfRowValue == sortAsc_listOfRowValue.sort()){ //verify asc
			KeywordUtil.markFailed("List is sorted in ascending order")
		}else if(listOfRowValue == sortDesc_listOfRowValue.reverse()){// verify desc
			KeywordUtil.markFailed("List is sorted in descending order")
		}else{//verify random
			KeywordUtil.markPassed("List is not sorted in descending or ascending order. The data is randomly listed")
		}
		println "listOfRowValue: "+listOfRowValue
		println "sortAsc_listOfRowValue: "+listOfRowValue.sort()
		println "sortDesc_listOfRowValue: "+listOfRowValue.reverse()
	}
	//belum bisa dipakai
	@Keyword
	def verifyDateIsMatchWithSearchDate(String input_dateFrom, String input_dateTo, List<Integer> columnIndexes, String formatDate){
		// input_dateFrom/input_dateTo/formatDate can be for example: yyyy-MM-dd or yyyy-MM-dd hh:mm:ss.sss depends on the web table date format
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper_Kaltim_BO.verifyDateIsMatchWithSearchDate'('2018-05-01', '2049-05-01', [2, 3], 'yyyy-MM-dd')
		//***


		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().defaultContent();
		TestObject testObject = new TestObject()
		def datefrom
		def dateTo
		int totalRowPerPage

		List listOfDate= []
		def getText_dateFrom
		def getText_dateTo

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.delay(1)
				totalRowPerPage = getTotalRowPerPage()
				for(int i=1; i<= totalRowPerPage; i++){
					if(columnIndexes.size() > 1){
						//WebUI.delay(1)
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						//WebUI.delay(1)
						getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
						listOfDate.add(getText_dateFrom)
						listOfDate.add(getText_dateTo)
					}else{
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						listOfDate.add(getText_dateFrom)

					}

				}
				println "list perpage: "+ listOfDate
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				WebUI.delay(1)
			}

		} catch (Exception e) {
			WebUI.delay(1)
			totalRowPerPage = getTotalRowPerPage()
			for(int i=1; i<= totalRowPerPage; i++){
				if(columnIndexes.size() > 1){
					//WebUI.delay(1)
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					//WebUI.delay(1)
					getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
					listOfDate.add(getText_dateFrom)
					listOfDate.add(getText_dateTo)
				}else{
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					listOfDate.add(getText_dateFrom)

				}

			}
			println "list perpage: "+ listOfDate
		}


		driver.switchTo().defaultContent();

		println "before remove: "+ listOfDate

		'remove the empty value in the list'
		for(int x=0; x< listOfDate.size(); x++){
			if(listOfDate[x] == ''){
				listOfDate.remove(x)
				x = x-1
			}
		}
		println "after remove: "+listOfDate
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)//("yyyy-mm-dd")
		'convert list of string listOfDate to list of dates '
		for (int k=0; k < listOfDate.size(); k++) {
			listOfDate[k] =  dateFormat.parse(listOfDate[k])

			if(listOfDate[k] > dateFormat.parse(input_dateFrom) && listOfDate[k] < dateFormat.parse(input_dateTo)){
				KeywordUtil.markPassed("date is match")
			}else{
				KeywordUtil.markFailed("date is not match for date: "+ listOfDate[k])
			}
		}
		println listOfDate

	}

	@Keyword
	def checkOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"
		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		WebUI.delay(5)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}



		WebUI.check(objectSpecifiList)
		WebUI.verifyElementChecked(objectSpecifiList, 0)

	}

	@Keyword
	def unCheckOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"

		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.uncheck(objectSpecifiList)
		WebUI.verifyElementNotChecked(objectSpecifiList, 0)

	}
	//belum bisa dipakai
	@Keyword
	def checkOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.check(checkbox_header)
		WebUI.verifyElementChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementChecked(testObject, 0)
		}

	}
	@Keyword
	def unCheckOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.uncheck(checkbox_header)
		WebUI.verifyElementNotChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementNotChecked(testObject, 0)
		}

	}

	@Keyword
	def clickEditIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@class='btn_Edit']"
		println xpath

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickEyeIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[1]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

	}

	@Keyword
	def clickDeleteIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@class='btn_Delete']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeleteIconOnSpecificRowPayroll(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		try{
			String iframe1 = "//iframe[@id='login']"
			String iframe2 = "//iframe[@id='mainFrame']"

			pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
			pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

			pr2.setParentObject(pr)

			String temp = ""
			String xpath = "//tr[@class='odd' or @class='even']["
			String value
			for(int i= 0; i< data.size(); i++){
				value = data.get(i)
				if(i != data.size()-1){
					temp = 'contains(.,"'+value+'") and '
				}else{
					temp = 'contains(.,"'+value+'")'
				}
				xpath = xpath + temp
			}
			xpath = xpath + "]//a[@class='btn_Delete']"
			println xpath
			TestObject testObject = new TestObject()
			testObject.setParentObject(pr2)
			def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
			WebUI.comment(xpath)
			WebUI.click(objectSpecifiList)

		}catch(Exception e){
			WebUI.comment("File not found, continue executing test case")
		}

	}

	//belum bisa dipakai
	@Keyword
	def clickDeleteIconOnSpecificRow_downloadReportMenu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@text='Delete']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDownloadIconOnSpecificRow_downloadReportMenu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@class='btn_Download']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Lock']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Unlocked']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Reset']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Active']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Inactive']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Resend']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Release']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def verifyColumnHeaderPopUp(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		TestObject to = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_POPUP_XPATH.replace('{dinamicValue}', it))
			to.setParentObject(pr2)
			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def verifyListOnPopUpTableContainsSpecificValue(List<String> data){

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}

	@Keyword
	def checkOnSpecificRowPopUp(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.check(objectSpecifiList)
		WebUI.verifyElementChecked(objectSpecifiList, 0)

	}

	@Keyword
	def uncheckOnSpecificRowPopUp(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.uncheck(objectSpecifiList)
		WebUI.verifyElementNotChecked(objectSpecifiList, 0)

	}

	@Keyword
	def clickNameHyperLink(String data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//td//a" + "[text()='"+data+"']"
		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectHyperlink = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		while(WebUI.verifyElementNotPresent(objectHyperlink, 0, FailureHandling.OPTIONAL).equals(true)){

			WebUI.click(objectNextButton)
			WebUI.delay(5)
		}
		WebUI.click(objectHyperlink)

	}


	@Keyword
	def clickNameHyperLinkPopUp(String data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='detailRecordFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//td//a" + "[text()='"+data+"']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectHyperlink = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectHyperlink)

	}

	@Keyword
	def getLimitPerDayDefaultPackage(List<String> data, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		xpath = xpath + "]//td[3]"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def limitVal = WebUI.getText(objectSpecifiList)
		KeywordUtil.logInfo(limitVal)
		if(limitVal.equals("Unlimited")){
			limitVal = 999999999
		}
		return limitVal


	}


	@Keyword
	def editAmountTransactionPerDayDefaultPackage(String menuName, String hierarchy, String amount, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+menuName+'") and contains(.,"'+hierarchy+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		xpath = xpath + "]//input[@class='tableMaxTransactionDay' or @class='tableMaxTransactionDay valid']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String limitVal = WebUI.getAttribute(objectSpecifiList, "value")
		KeywordUtil.logInfo(limitVal)
		if(limitVal.equals("Unlimited")){
			limitVal = 999999999
		}


		WebUI.setText(objectSpecifiList, amount)
		KeywordUtil.logInfo(limitVal)
		return limitVal


	}

	@Keyword
	def editMinMaxAmountTransactionDefaultPackage(String menuName, String hierarchy, String min, String max, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+menuName+'") and contains(.,"'+hierarchy+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		String xpathmin = xpath + "]//input[@placeholder='Minimum Amount']"

		String xpathmax = xpath + "]//input[@class='tableMaxAmountTransaction' or @class='tableMaxAmountTransaction valid']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		def objectMin= testObject.addProperty("xpath", ConditionType.EQUALS, xpathmin)
		def objectMax = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathmax)

		WebUI.setText(objectMin, min)
		KeywordUtil.logInfo(min)
		WebUI.setText(objectMax, max)
		KeywordUtil.logInfo(max)



	}


	@Keyword
	def editLimitPerDayDefaultPackage(String menuName, String hierarchy, String limitValue, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+menuName+'") and contains(.,"'+hierarchy+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		xpath = xpath + "]//td[3]//input[@class='tableMaxNoTransaction' or @class='tableMaxNoTransaction valid']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		KeywordUtil.logInfo(limitValue)
		WebUI.scrollToElement(objectSpecifiList, 10)
		WebUI.setText(objectSpecifiList, limitValue)
		//		WebUI.verifyElementAttributeValue(objectSpecifiList, "value", limitValue, 10)


	}

	@Keyword
	def editLimitBusinessDayDefaultPackage(String menuName, String value, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+menuName+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		xpath = xpath + "]//td//input[@class='tableCheck']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.scrollToElement(objectSpecifiList, 10)
		if(WebUI.getAttribute(objectSpecifiList, 'value').equals("Y") && value.equals('N')){

			WebUI.uncheck(objectSpecifiList)
		}else if(WebUI.getAttribute(objectSpecifiList, 'value').equals("N") && value.equals('Y')){
			WebUI.check(objectSpecifiList)
		}
		//		WebUI.verifyElementAttributeValue(objectSpecifiList, "value", limitValue, 10)


	}

	@Keyword
	def editLimitServiceHourDefaultPackage(String menuName, String startDate, String endDate, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+menuName+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		String xpath1 =  xpath + "]//input[@class='tableStartTime' or @class='tableStartTime valid']"
		String xpath2 = xpath + "]//input[@class='tableEndTime' or @class='tableEndTime valid']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath1)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpath2)
		WebUI.scrollToElement(objectSpecifiList, 10)
		WebUI.setText(objectSpecifiList, startDate)
		WebUI.setText(objectSpecifiList2, endDate)
		//		WebUI.verifyElementAttributeValue(objectSpecifiList, "value", limitValue, 10)


	}


	@Keyword
	def getLimitPerDayServicePackage(String menuName, String productName, String hierarchy, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxNmbrTrxPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)

		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		def limitVal = WebUI.getAttribute(objectSpecifiListTarget, 'value')
		KeywordUtil.logInfo(limitVal)
		return limitVal
		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}


	}



	@Keyword
	def editLimitAmountPerDayServicePackage(String menuName, String productName, String hierarchy, String amount, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class="sorting_2" and not(@value)]'
		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'
		}

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxTrxAmntPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)

		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		String limitVal = WebUI.getAttribute(objectSpecifiListTarget, 'value')
		if(limitVal.contains(".")){
			limitVal = limitVal.substring(0, limitVal.indexOf("."))
		}
		KeywordUtil.logInfo(limitVal)
		WebUI.setText(objectSpecifiListTarget, amount)
		KeywordUtil.logInfo(limitVal)
		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}

		return limitVal



	}

	@Keyword
	def editMinMaxAmountTransactionServicePackage(String menuName, String productName, String hierarchy, String min, String max, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class="sorting_2" and not(@value)]'
		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'
		}
		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMinAmntPerTrxProduct"]'

		String xpathTarget2 = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxAmntPerTrxProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2 = testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)

		WebUI.setText(objectSpecifiListTarget, min)
		WebUI.setText(objectSpecifiListTarget2, max)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}





	}


	@Keyword
	def editLimitServiceHourServicePackage(String menuName, String productName, String startDate, String endDate, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class="sorting_2" and not(@value)]'
		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'
		}
		String xpathTarget = '//td[@id="tableStartTime"]//input[@class="tableStartTime"]'

		String xpathTarget2 = '//td[@id="tableEndTime"]//input[@class="tableEndTime"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2 = testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)

		WebUI.setText(objectSpecifiListTarget, startDate)
		WebUI.setText(objectSpecifiListTarget2, endDate)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,' Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}





	}

	@Keyword
	def editLimitBusinessDayServicePackage(String menuName, String productName, String value, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class="sorting_2" and not(@value)]'
		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'
		}
		String xpathTarget = '//td//input[@id="bd"]'

		String xpathTarget2 = '//td//input[@id="cd"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2 = testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)

		if(value.equals('Y')){
			WebUI.check(objectSpecifiListTarget)
		}else{
			WebUI.check(objectSpecifiListTarget2)
		}


		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,' Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}





	}



	@Keyword
	def editLimitPerDayServicePackage(String menuName, String productName , String hierarchy, String limitValue, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group]'
		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class="sorting_2" and not(@value)]'
		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class="sorting_2" and text()="'+productName+'" and not(@style)]'
		}

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxNmbrTrxPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)

		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 10)
		WebUI.setText(objectSpecifiListTarget, limitValue)
		//		WebUI.scrollToElement(objectDialogEnter, 10)
		WebUI.delay(5)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}




		//		WebUI.verifyElementAttributeValue(objectSpecifiList, "value", limitValue, 10)


	}

	@Keyword
	def getLimitPerDayCustomPackage(String menuName, String productName, String hierarchy, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[not(@style)]'

		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[text()="'+productName+'" and not(@style)]'
		}

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxNmbrTrxPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		def limitVal = WebUI.getAttribute(objectSpecifiListTarget, 'value')
		KeywordUtil.logInfo(limitVal)
		return limitVal


	}

	@Keyword
	def editLimitAmountPerDayCustomPackage(String menuName, String productName, String hierarchy, String amount,String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[not(@style)]'

		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[text()="'+productName+'" and not(@style)]'
		}

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxTrxAmntPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()


		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.scrollToElement(objectSpecifiList, 1)
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		def limitVal = WebUI.getAttribute(objectSpecifiListTarget, 'value')
		KeywordUtil.logInfo(limitVal)
		WebUI.setText(objectSpecifiListTarget, amount)
		KeywordUtil.logInfo(limitVal)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}

		return limitVal


	}


	@Keyword
	def editMinMaxAmountTransactionCustomPackage(String menuName, String productName, String hierarchy, String min, String max,String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[not(@style)]'

		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[text()="'+productName+'" and not(@style)]'
		}

		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMinAmntPerTrxProduct"]'

		String xpathTarget2 = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxAmntPerTrxProduct"]'


		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()



		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2 = testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.scrollToElement(objectSpecifiList, 1)
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)

		WebUI.setText(objectSpecifiListTarget, min)
		WebUI.setText(objectSpecifiListTarget2, max)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}



	}


	@Keyword
	def editLimitPerDayCustomPackage(String menuName, String productName, String hierarchy, String limitValue, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[not(@style)]'

		if(productName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[text()="'+productName+'" and not(@style)]'
		}
		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxNmbrTrxPerDayProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="limit"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)


		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)

		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 10)
		WebUI.setText(objectSpecifiListTarget, limitValue)
		//		WebUI.scrollToElement(objectDialogEnter, 10)
		WebUI.delay(2)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}




		//		WebUI.verifyElementAttributeValue(objectSpecifiList, "value", limitValue, 10)


	}




	@Keyword
	def accessDetailApprovalMatrix(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***



		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//td[1]//a"
		println xpath
		KeywordUtil.logInfo(xpath)
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		//		WebUI.scrollToElement(objectSpecifiList, 5)
		WebUI.click(objectSpecifiList)


	}


	@Keyword
	def setOnBusinessDayCustomPackage(String menuName, String product, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")][1]//td[2]'

		if(product != "null"){
			xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")]//td[2][text()="'+product+'"]'
		}

		String xpathTarget = '//input[@name="isBusinessDay" and @value ="Y"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		WebUI.check(objectSpecifiListTarget)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}

	}

	@Keyword
	def setOffBusinessDayCustomPackage(String menuName, String product, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")][1]//td[2]'

		if(product != "null"){
			xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")]//td[2][text()="'+product+'"]'
		}
		String xpathTarget = '//input[@name="isBusinessDay" and @value ="N"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		WebUI.check(objectSpecifiListTarget)


		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}



	}


	@Keyword
	def editLimitServiceHourCustomPackage(String menuName, String product, String startDate, String endDate, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group]'

		String xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")][1]//td[2]'

		if(product != "null"){
			xpath = '//div[@id="windowTime"]//tr[@data-group and contains(.,"'+menuName+'")]//td[2][text()="'+product+'"]'
		}
		String xpathTarget = '//input[@class="tableStartTime"]'

		String xpathTarget2 = '//input[@class="tableEndTime"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//div[@id="windowTime"]//tr//td[contains(.,"'+menuName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2= testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)
		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objectSpecifiListTarget, 0)
		WebUI.setText(objectSpecifiListTarget, startDate)
		WebUI.setText(objectSpecifiListTarget2, endDate)


		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons'][$i]//button[contains(.,' Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)
			testObject4.setParentObject(pr2)

			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}



	}


	@Keyword
	def checkAccountMaxDebitLimit(String accId, String value){
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		String accDDL = "//*[@id='s2id_corporateInfiniteScroll']"
		String accDDLChoice = '//*[@class="select2-result-label" and contains(.,"'+accId+'")]'
		String accMaxDebitLimit = '//tr[contains(.,"'+accId+'")]//input[@id="accountMaxDebitLimitText"]'
		String searchButton = "//button[@id='search']"
		String searchDDL = "//div[@class='select2-search']//input"
		String checkbox = '//tr[contains(.,"'+accId+'")]//td//input[@type="checkbox"]'

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()
		TestObject testObject6 = new TestObject()

		def objectaccDDL= testObject.addProperty("xpath", ConditionType.EQUALS, accDDL)
		def objectaccDDLChoice = testObject2.addProperty("xpath", ConditionType.EQUALS, accDDLChoice)
		def objectaccMaxDebitLimit = testObject3.addProperty("xpath", ConditionType.EQUALS, accMaxDebitLimit)
		def objectbuttonSearch = testObject4.addProperty("xpath", ConditionType.EQUALS, searchButton)
		def objectsearchDDL = testObject5.addProperty("xpath", ConditionType.EQUALS, searchDDL)
		def objectCheck = testObject6.addProperty("xpath", ConditionType.EQUALS, checkbox)

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)
		testObject6.setParentObject(pr2)

		WebUI.click(objectaccDDL)
		WebUI.click(objectsearchDDL)
		WebUI.setText(objectsearchDDL, accId)
		WebUI.click(objectaccDDLChoice)
		WebUI.click(objectbuttonSearch)
		WebUI.verifyElementPresent(objectaccMaxDebitLimit, 0)
		def maxLimit= WebUI.getAttribute(objectaccMaxDebitLimit, 'value')
		KeywordUtil.logInfo(maxLimit)
		WebUI.check(objectCheck)
		WebUI.setText(objectaccMaxDebitLimit, value)
		KeywordUtil.logInfo(value)

		return maxLimit



	}


	@Keyword
	def editUserGroupMaxDebitLimit(String accId){
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		String iframe3 = "//iframe[@id='productFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		TestObject pr3 = new TestObject()

		pr3.addProperty("xpath", ConditionType.EQUALS, iframe3)

		String limitTab = "//a[@href='#limit']"
		String checkAllProductTable = "//div[@id='tableProduct']//input[@class='checkAll']"
		String btnConfirmProductTable = "//button[text()=' Confirm']"
		String searchButton = "//button[@id='search']"
		String searchDDL = "//div[@class='select2-search']//input"

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()

		def objectaccDDL= testObject.addProperty("xpath", ConditionType.EQUALS, accDDL)
		def objectaccDDLChoice = testObject2.addProperty("xpath", ConditionType.EQUALS, accDDLChoice)
		def objectaccMaxDebitLimit = testObject3.addProperty("xpath", ConditionType.EQUALS, accMaxDebitLimit)
		def objectbuttonNext = testObject4.addProperty("xpath", ConditionType.EQUALS, searchButton)
		def objectsearchDDL = testObject5.addProperty("xpath", ConditionType.EQUALS, searchDDL)

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)

		WebUI.click(objectaccDDL)
		WebUI.click(objectsearchDDL)
		WebUI.setText(objectsearchDDL, accId)
		WebUI.click(objectaccDDLChoice)
		WebUI.click(objectbuttonNext)
		WebUI.verifyElementPresent(objectaccMaxDebitLimit, 0)
		def maxLimit= WebUI.getAttribute(objectaccMaxDebitLimit, 'value')
		KeywordUtil.logInfo(maxLimit)

		return maxLimit



	}


	@Keyword
	def verifyColumnActionButtonStatus(String lockstatus, String resetstatus, String activestatus){

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		TestObject testObject = new TestObject()

		def flag = 1;

		while(flag == 1){
			def totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){
				testObject.setParentObject(pr2)
				KeywordUtil.logInfo(k.toString())
				def currentRow
				if(lockstatus.equals("LOCK")){
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Unlocked' and not(@disabled)]"

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
				}else{
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Unlocked' and @disabled = 'true']"

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
				}

				if(resetstatus.equals("RESET")){
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Reset' and not(@disabled)]"

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
				}else{
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Reset' and @disabled = 'true']"

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
				}

				if(activestatus.equals("ACTIVE")){
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Inactive']"

					def currentRow2 = "//tr[@class='odd' or @class='even'][$k]//button[@title='Active' and @disabled = 'true']"

					def testObject2 = new TestObject()

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)

					testObject2.addProperty("xpath", ConditionType.EQUALS, currentRow2)

					testObject2.setParentObject(pr2)

					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
					WebUI.verifyElementPresent(testObject2, 2)
				}else if(activestatus.equals("DELETE")){
					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Inactive' and @disabled = 'true']"

					def currentRow2 = "//tr[@class='odd' or @class='even'][$k]//button[@title='Active' and @disabled = 'true']"

					def testObject2 = new TestObject()

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)

					testObject2.addProperty("xpath", ConditionType.EQUALS, currentRow2)

					testObject2.setParentObject(pr2)

					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
					WebUI.verifyElementPresent(testObject2, 2)

				}else{

					currentRow = "//tr[@class='odd' or @class='even'][$k]//button[@title='Active']"

					def currentRow2 = "//tr[@class='odd' or @class='even'][$k]//button[@title='Inactive' and @disabled = 'true']"

					def testObject2 = new TestObject()

					testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)

					testObject2.addProperty("xpath", ConditionType.EQUALS, currentRow2)

					testObject2.setParentObject(pr2)

					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					WebUI.verifyElementPresent(testObject, 2)
					WebUI.verifyElementPresent(testObject2, 2)

				}

				KeywordUtil.logInfo("row: "+ k + " Passed")

			}

			TestObject nextPage = new TestObject()
			nextPage.addProperty("xpath", ConditionType.EQUALS,  "//div[@id='paggingArea']/button[4]")

			try{
				WebUI.verifyElementVisible(nextPage)
			}catch(Exception e){
				flag = 0
				break
			}
			println("next page are present")

			WebUI.delay(1, FailureHandling.STOP_ON_FAILURE)

			WebUI.click(nextPage)
			println("opening next page")

			WebUI.delay(1, FailureHandling.STOP_ON_FAILURE)
		}



	}

	@Keyword
	def verifyListOnTableNotContainsSpecificValue(List<String> data){
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementNotPresent(objectSpecifiList, 5)
	}

	@Keyword
	def DoubleClickOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		def flag = 1


		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.scrollToElement(nextButton, 0)
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.doubleClick(objectSpecifiList)



	}

	@Keyword
	def editCorporateRegistrationSTPLimit(String product, String menuName, String indiv1, String indiv2, String corp1, String corp2){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//div[@class="overFlowTable" and not(@style="display: none;")]//tr[@class="odd" or @class="even"][contains(.,"'+product+'") and contains(.,"'+menuName+'")]'

		String xpathChooseMenu2 = '//div[@class="overFlowTable" and @style="display: none;"]//tr[@class="odd" or @class="even"][contains(.,"'+product+'") and contains(.,"'+menuName+'")]'

		String xpathIndiv1 = xpathChooseMenu + '//td//input[@class="tableLimit" or @class="tableLimit valid"]'

		String xpathIndiv2= xpathChooseMenu + '//td//input[@class="tableLimitDaily" or @class="tableLimitDaily valid"]'

		String xpathCorp1 = xpathChooseMenu + '//td//input[@class="tableLimitCorporate" or @class="tableLimitCorporate valid"]'

		String xpathCorp2 = xpathChooseMenu + '//td//input[@class="tableLimitCorporateDaily" or @class="tableLimitCorporateDaily valid"]'


		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()
		TestObject testAlt1 = new TestObject()
		TestObject testAlt2 = new TestObject()
		TestObject testAlt3 = new TestObject()
		TestObject testAlt4 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)
		testAlt1.setParentObject(pr2)
		testAlt2.setParentObject(pr2)
		testAlt3.setParentObject(pr2)
		testAlt4.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectIndiv1 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathIndiv1)
		def objectIndiv2 = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathIndiv2)
		def objectCorp1= testObject4.addProperty("xpath", ConditionType.EQUALS, xpathCorp1)
		def objectCorp2= testObject5.addProperty("xpath", ConditionType.EQUALS, xpathCorp2)


		WebUI.scrollToElement(objectSpecifiList, 0)
		if(indiv1 != 'null'){
			boolean avail = WebUI.verifyElementVisible(objectIndiv1, FailureHandling.OPTIONAL)

			if(avail == false){
				def alt1 = testAlt1.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu2 + '//td//input[@class="tableLimit"]')
				WebUI.verifyElementVisible(alt1, FailureHandling.OPTIONAL)
				KeywordUtil.logInfo("test")
				WebUI.setText(alt1, indiv1)

			}else{
				WebUI.setText(objectIndiv1, indiv1)
			}

		}

		if(indiv2 != 'null'){
			boolean avail = WebUI.verifyElementVisible(objectIndiv2, FailureHandling.OPTIONAL)
			if(avail== false){
				def alt2 = testAlt2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu2 + '//td//input[@class="tableLimitDaily"]')
				WebUI.setText(alt2, indiv2)
			}else{
				WebUI.setText(objectIndiv2, indiv2)
			}

		}

		if(corp1 != 'null'){
			boolean avail = WebUI.verifyElementVisible(objectCorp1, FailureHandling.OPTIONAL)
			if( avail == false){
				def alt3 = testAlt3.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu2 + '//td//input[@class="tableLimitCorporate"]')
				WebUI.setText(alt3, corp1)
			}else{
				WebUI.setText(objectCorp1, corp1)
			}

		}

		if(corp2 != 'null'){
			boolean avail = WebUI.verifyElementVisible(objectCorp2, FailureHandling.OPTIONAL)
			if(avail == false){
				def alt4 = testAlt4.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu2 + '//td//input[@class="tableLimitCorporateDaily"]')
				WebUI.setText(alt4, corp2)
			}else{
				WebUI.setText(objectCorp2, corp2)
			}

		}


	}

	@Keyword
	def editMinMaxAmountBankTransactionLimit(String productName, String menuName, String hierarchy, String currency, String min, String max, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class and @rowspan and not(@value)]'
		if(menuName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class and @rowspan and text()="'+menuName+'" and not(@style)]'
		}
		String xpathTarget = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMinAmntPerTrxProduct"]'

		String xpathTarget2 = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//input[@class="tableMaxAmntPerTrxProduct"]'

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		String ddlCurrency = '//div[@id="tableLimit"]//table[contains(.,"'+hierarchy+'")]//select[@class="tableCurrencyLimit"]'
		String currencyChoice = ddlCurrency + '//option[@value[not(string())]]'
		if(currency != "null"){
			currencyChoice = ddlCurrency + '//option[contains(.,"'+currency+'")]'
		}

		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		TestObject testObject5 = new TestObject()
		TestObject testObject6 = new TestObject()
		TestObject testObject7 = new TestObject()

		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)
		testObject5.setParentObject(pr2)
		testObject6.setParentObject(pr2)
		testObject7.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)
		def objectSpecifiListTarget = testObject3.addProperty("xpath", ConditionType.EQUALS, xpathTarget)
		def objectSpecifiListTarget2 = testObject5.addProperty("xpath", ConditionType.EQUALS, xpathTarget2)
		def objetCurrencyDDL = testObject6.addProperty("xpath", ConditionType.EQUALS, ddlCurrency)
		def objetCurrencyDDLChoice = testObject7.addProperty("xpath", ConditionType.EQUALS, currencyChoice)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
		WebUI.scrollToElement(objetCurrencyDDL, 0)
		WebUI.click(objetCurrencyDDL)
		WebUI.scrollToElement(objetCurrencyDDLChoice, 0)
		WebUI.click(objetCurrencyDDLChoice)

		WebUI.setText(objectSpecifiListTarget, min)
		WebUI.setText(objectSpecifiListTarget2, max)

		def objectDialogEnter

		for(int i = 0; i < 5; i++){
			String xpathEnterButton = "//div[$i]//button[contains(.,'Enter')]"
			objectDialogEnter = testObject4.addProperty("xpath", ConditionType.EQUALS, xpathEnterButton)


			try{
				if(WebUI.click(objectDialogEnter)){
					break
				}

			}catch(Exception e){
				KeywordUtil.logInfo(xpathEnterButton)
				KeywordUtil.logInfo('attempt to save edit ' + i)
			}


		}





	}

	@Keyword
	def chooseMenuonBankTransactionLimit(String productName, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group]'


		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}

		TestObject testObject2 = new TestObject()


		testObject2.setParentObject(pr2)

		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail



	}

	@Keyword
	def openPopUponBankTransactionLimit(String productName, String menuName, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""

		String xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group]'

		String xpath = '//tr[@data-group and @style= "display: table-row;"][1]//td[@class and @rowspan and not(@value)]'
		if(menuName != "null"){
			xpath = '//tr[@data-group and @style= "display: table-row;"]//td[@class and @rowspan and text()="'+menuName+'" and not(@style)]'
		}

		if(!notInclude.equals("")){
			xpathChooseMenu = '//td[contains(.,"'+productName+'") and @data-group and not(contains(.,"'+notInclude+'"))]'
		}


		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()


		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpathChooseMenu)


		//click on menu
		WebUI.click(objectSpecifiList2)
		//click to access menu detail
		WebUI.doubleClick(objectSpecifiList)
	}

	@Keyword
	def clickActivateIconOnSpecificRow_AuthenticationDevice(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@title='Activate' or @data-original-title='Activate']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeActivateIconOnSpecificRow_AuthenticationDevice(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@data-original-title ='Deactivate']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def editAccountOnSpecificRow_AccountMaintenance(List<String> data, String debitvalue, String creditvalue, String inquiryvalue){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}

		xpath = xpath + "]"

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectDebitValue = testObject.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[ not(@type ='hidden') and @class='tableDebitFlag' or @class='tableDebitFlag valid']")

		TestObject testObject2 = new TestObject()
		testObject2.setParentObject(pr2)
		def objectCreditValue = testObject2.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[ not(@type ='hidden') and @class='tableCreditFlag' or @class='tableCreditFlag valid']")

		TestObject testObject3 = new TestObject()
		testObject3.setParentObject(pr2)
		def objectInquiryValue = testObject3.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[ not(@type ='hidden') and @class='tableInquiryFlag' or @class='tableInquiryFlag valid']")
		if(!debitvalue.equals("null")){
			WebUI.setText(objectDebitValue, debitvalue)
		}

		if(!creditvalue.equals("null")){
			WebUI.setText(objectCreditValue, creditvalue)
		}

		if(!inquiryvalue.equals("null")){
			WebUI.setText(objectInquiryValue, inquiryvalue)
		}




	}

	@Keyword
	def clickEditMenuIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@class='btn_EditMenu']"
		println xpath

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr2)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def verifyColumnContainsSpecificValue(String input, int colIndex){

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		TestObject testObject = new TestObject()

		//		def flag = 1;
		//
		//		while(flag == 1){
		def totalRowPerPage = getTotalRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			testObject.setParentObject(pr2)
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$colIndex]"

			testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
			KeywordUtil.logInfo("get text of xpath: "+ currentRow)
			def textResult = WebUI.getText(testObject)
			textResult.equalsIgnoreCase(input)

			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

		WebUI.switchToDefaultContent()

		//			TestObject nextPage = new TestObject()
		//			nextPage.addProperty("xpath", ConditionType.EQUALS,  "//div[@id='paggingArea']/button[4]")
		//
		//			try{
		//				WebUI.verifyElementVisible(nextPage)
		//			}catch(Exception e){
		//				flag = 0
		//				break
		//			}
		//			println("next page are present")
		//
		//			WebUI.delay(1, FailureHandling.STOP_ON_FAILURE)
		//
		//			WebUI.click(nextPage)
		//			println("opening next page")
		//
		//			WebUI.delay(1, FailureHandling.STOP_ON_FAILURE)
		//		}
	}


	@Keyword
	def clickDeleteIconOnSpecificRow_AuthenticationDevice(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@data-original-title ='Delete']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickEditIconOnSpecificRow_AuthenticationDevice(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@data-original-title ='Edit']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def editChargeDefaultPackage(String productName, String chargetype, String currency, String chargemethod, String value, String billInstruct, String notInclude = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["

		xpath = xpath + 'contains(.,"'+productName+'") and contains(.,"'+chargetype+'")'

		if(!notInclude.equals("")){
			xpath = xpath + 'and not(contains(.,"'+notInclude+'"))'
		}

		String currencyddl =  xpath + "]//td[3]//div[@class='select2-container']"
		String methodddl = xpath + "]//td[4]//div[@class='select2-container']"
		String valueddl = xpath + "]//td[5]//div[@class='droplistKLN']//div[@class='select2-container']"
		String billddl = xpath + "]//td[6]//div[@class='select2-container']"
		KeywordUtil.logInfo(xpath)
		println xpath
		TestObject testObject = new TestObject()
		TestObject testObject2 = new TestObject()
		TestObject testObject3 = new TestObject()
		TestObject testObject4 = new TestObject()
		testObject.setParentObject(pr2)
		testObject2.setParentObject(pr2)
		testObject3.setParentObject(pr2)
		testObject4.setParentObject(pr2)

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, currencyddl)
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, methodddl)
		def objectSpecifiList3 = testObject3.addProperty("xpath", ConditionType.EQUALS, valueddl)
		def objectSpecifiList4 = testObject4.addProperty("xpath", ConditionType.EQUALS, billddl)



		WebUI.scrollToElement(objectSpecifiList, 10)

		if(!currency.equals("") && !currency.equals("null")){
			WebUI.click(objectSpecifiList)

			String ddlsearch = "//div[@id='select2-drop']//input[@class='select2-input' or @class='select2-input select2-focused']"

			TestObject searchddlobject = new TestObject()
			searchddlobject.setParentObject(pr2)
			def searchddl = searchddlobject.addProperty("xpath", ConditionType.EQUALS, ddlsearch)

			WebUI.setText(searchddl, currency)
			KeywordUtil.logInfo(currency)

			String ddlcheck = '//ul[@class="select2-results"]//span[@class="select2-match" and contains(.,"'+currency+'")]'

			TestObject choiceddlobject = new TestObject()
			choiceddlobject.setParentObject(pr2)
			def choiceddl = choiceddlobject.addProperty("xpath", ConditionType.EQUALS, ddlcheck)

			WebUI.verifyElementPresent(choiceddl, 0)
			WebUI.click(choiceddl)

		}else if(currency.equals("")){
			String deletevalddl = xpath + "]//td[3]//div[@class='select2-container']//abbr[@class='select2-search-choice-close']"

			TestObject deletevalddlobject = new TestObject()
			deletevalddlobject.setParentObject(pr2)
			def deleteddl = deletevalddlobject.addProperty("xpath", ConditionType.EQUALS, deletevalddl)

			WebUI.click(deleteddl)
		}

		if(!chargemethod.equals("") && !chargemethod.equals("null")){
			WebUI.click(objectSpecifiList2)

			String ddlsearch = "//div[@id='select2-drop']//input[@class='select2-input' or @class='select2-input select2-focused']"

			TestObject searchddlobject = new TestObject()
			searchddlobject.setParentObject(pr2)
			def searchddl = searchddlobject.addProperty("xpath", ConditionType.EQUALS, ddlsearch)

			WebUI.setText(searchddl, chargemethod)
			KeywordUtil.logInfo(chargemethod)

			String ddlcheck = '//ul[@class="select2-results"]//span[@class="select2-match" and contains(.,"'+chargemethod+'")]'

			TestObject choiceddlobject = new TestObject()
			choiceddlobject.setParentObject(pr2)
			def choiceddl = choiceddlobject.addProperty("xpath", ConditionType.EQUALS, ddlcheck)

			WebUI.verifyElementPresent(choiceddl, 0)
			WebUI.click(choiceddl)
			KeywordUtil.logInfo(chargemethod+" chosen")

		}else if(chargemethod.equals("")){
			String deletevalddl = xpath + "]//td[4]//div[@class='select2-container']//abbr[@class='select2-search-choice-close']"

			TestObject deletevalddlobject = new TestObject()
			deletevalddlobject.setParentObject(pr2)
			def deleteddl = deletevalddlobject.addProperty("xpath", ConditionType.EQUALS, deletevalddl)

			WebUI.click(deleteddl)
		}

		if(chargemethod.equals("Charges KLN") || chargemethod.equals("Tiering/Slab")){
			KeywordUtil.logInfo(value)
			WebUI.delay(3)
			if(!value.equals("") && !value.equals("null")){
				WebUI.verifyElementPresent(objectSpecifiList3, 0)
				WebUI.click(objectSpecifiList3)

				String ddlsearch = "//div[@id='select2-drop']//input[@class='select2-input' or @class='select2-input select2-focused']"

				TestObject searchddlobject = new TestObject()
				searchddlobject.setParentObject(pr2)
				def searchddl = searchddlobject.addProperty("xpath", ConditionType.EQUALS, ddlsearch)

				WebUI.setText(searchddl, value)
				KeywordUtil.logInfo(value)

				String ddlcheck = '//ul[@class="select2-results"]//span[@class="select2-match" and contains(.,"'+value+'")]'

				TestObject choiceddlobject = new TestObject()
				choiceddlobject.setParentObject(pr2)
				def choiceddl = choiceddlobject.addProperty("xpath", ConditionType.EQUALS, ddlcheck)

				WebUI.verifyElementPresent(choiceddl, 0)
				WebUI.click(choiceddl)
			}else if(value.equals("")){
				String deletevalddl = xpath + "]//td[5]//div[@class='select2-container']//abbr[@class='select2-search-choice-close']"

				TestObject deletevalddlobject = new TestObject()
				deletevalddlobject.setParentObject(pr2)
				def deleteddl = deletevalddlobject.addProperty("xpath", ConditionType.EQUALS, deletevalddl)

				WebUI.click(deleteddl)
			}


		}else{
			if(!value.equals("null")){
				String valueInput = xpath+"]//input[@id='tableFixedAmount']"

				TestObject valueInputobject = new TestObject()
				valueInputobject.setParentObject(pr2)
				def inputValue = valueInputobject.addProperty("xpath", ConditionType.EQUALS, valueInput)

				WebUI.verifyElementPresent(inputValue, 0)
				WebUI.setText(inputValue, value)
				KeywordUtil.logInfo(value)
			}

		}

		if(!billInstruct.equals("") && !billInstruct.equals("null")){
			WebUI.click(objectSpecifiList4)

			String ddlsearch = "//div[@id='select2-drop']//input[@class='select2-input' or @class='select2-input select2-focused']"

			TestObject searchddlobject = new TestObject()
			searchddlobject.setParentObject(pr2)
			def searchddl = searchddlobject.addProperty("xpath", ConditionType.EQUALS, ddlsearch)

			WebUI.setText(searchddl, billInstruct)

			String ddlcheck = '//ul[@class="select2-results"]//span[@class="select2-match" and contains(.,"'+billInstruct+'")]'

			TestObject choiceddlobject = new TestObject()
			choiceddlobject.setParentObject(pr2)
			def choiceddl = choiceddlobject.addProperty("xpath", ConditionType.EQUALS, ddlcheck)

			WebUI.verifyElementPresent(choiceddl, 0)
			WebUI.click(choiceddl)
			KeywordUtil.logInfo(billInstruct)

		}else if(billInstruct.equals("")){
			String deletevalddl = xpath + "]//td[6]//div[@class='select2-container']//abbr[@class='select2-search-choice-close']"

			TestObject deletevalddlobject = new TestObject()
			deletevalddlobject.setParentObject(pr2)
			def deleteddl = deletevalddlobject.addProperty("xpath", ConditionType.EQUALS, deletevalddl)

			WebUI.click(deleteddl)
		}

	}

	@Keyword
	def verifyColumnHeaderJobFrame(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders = null){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		TestObject to = new TestObject()

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		String iframe3 = "//iframe[@id='jobFrame']"

		TestObject pr3 = new TestObject()
		pr3.addProperty("xpath", ConditionType.EQUALS, iframe3)

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)
		pr3.setParentObject(pr2)

		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_XPATH.replace('{dinamicValue}', it))
			to.setParentObject(pr3)

			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def setInputParameterBatch(String Data, String HourMinute){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//input[@id='inputParameter']"
		def dateCurrent = new Date()
		def dateToday = dateCurrent.format("yyyy-MM-dd $HourMinute:00:00")

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		if(Data.equals('Today')){
			Data = dateToday
		}else if(Data.equals('Default')){
			Data = ''
		}else{
			def convertData = Integer.parseInt(Data)
			def difference = dateCurrent + convertData
			Data = difference.format("yyyy-MM-dd $HourMinute:00")
		}
		WebUI.setText(objectSpecifiList, Data)

	}

	@Keyword
	def setInputParameterBatchWeekly(String Data, String HourMinute){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//input[@id='inputParameter']"
		LocalDateTime dateCurrent = LocalDateTime.now()

		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd $HourMinute:00", Locale.ENGLISH)
		DateTimeFormatter myFormatObj2 = DateTimeFormatter.ofPattern("EEEE")
		String currentDayName = dateCurrent.format(myFormatObj2)
		int currentDayIndex = 0
		int newDayIndex = 0
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		if(Data.equals('Today')){
			Data = dateCurrent.format(myFormatObj)
		}else if(Data.equals('Default')){
			Data = ''
		}else{
			LocalDateTime dateTime = LocalDateTime.now()

			if(currentDayName.equalsIgnoreCase('monday')){
				currentDayIndex = 1
			}else if(currentDayName.equalsIgnoreCase('tuesday')){
				currentDayIndex = 2
			}else if(currentDayName.equalsIgnoreCase('wednesday')){
				currentDayIndex = 3
			}else if(currentDayName.equalsIgnoreCase('thursday')){
				currentDayIndex = 4
			}else if(currentDayName.equalsIgnoreCase('friday')){
				currentDayIndex = 5
			}else if(currentDayName.equalsIgnoreCase('saturday')){
				currentDayIndex = 6
			}else if(currentDayName.equalsIgnoreCase('sunday')){
				currentDayIndex = 7
			}

			if(Data.equalsIgnoreCase('monday')){
				newDayIndex = 1
			}else if(Data.equalsIgnoreCase('tuesday')){
				newDayIndex = 2
			}else if(Data.equalsIgnoreCase('wednesday')){
				newDayIndex = 3
			}else if(Data.equalsIgnoreCase('thursday')){
				newDayIndex = 4
			}else if(Data.equalsIgnoreCase('friday')){
				newDayIndex = 5
			}else if(Data.equalsIgnoreCase('saturday')){
				newDayIndex = 6
			}else if(Data.equalsIgnoreCase('sunday')){
				newDayIndex = 7
			}

			if(currentDayIndex < newDayIndex){
				dateTime = dateTime.plusDays(newDayIndex - currentDayIndex)
				Data = dateTime.format(myFormatObj)
			}else if(currentDayIndex == newDayIndex){
				dateTime = dateTime.plusDays(newDayIndex - currentDayIndex)
				dateTime = dateTime.plusDays(7)
				Data = dateTime.format(myFormatObj)
			}else{
				dateTime = dateTime.minusDays(currentDayIndex - newDayIndex)
				dateTime = dateTime.plusDays(7)
				Data = dateTime.format(myFormatObj)
			}


		}
		println Data
		WebUI.setText(objectSpecifiList, Data)

	}

	@Keyword
	def setInputParameterBatchMonthly(String Data, String HourMinute){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//input[@id='inputParameter']"
		LocalDateTime dateCurrent = LocalDateTime.now()
		LocalDateTime dateTarget = LocalDateTime.now()
		DateTimeFormatter myFormatObj2 = DateTimeFormatter.ofPattern("yyyy-MM-dd $HourMinute:00", Locale.ENGLISH)
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-$Data $HourMinute:00", Locale.ENGLISH)
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		if(Data.equals('Today')){
			Data = dateCurrent.format(myFormatObj)
		}else if(Data.equals('Default')){
			Data = ''
		}else{

			String target = dateTarget.format(myFormatObj)

			String current = dateCurrent.format(myFormatObj2)

			if( current > target){
				dateTarget = dateTarget.plusMonths(1)
				target = dateTarget.format(myFormatObj)
				Data = target
			}else{
				Data = current
			}
		}
		println Data
		WebUI.setText(objectSpecifiList, Data)

	}

	@Keyword
	def DoubleClickOnSpecificRowExchangeRateACU(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		String iframe3 = "//iframe[@id='exchangeRateFrame']"
		TestObject pr3 = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr3.addProperty("xpath", ConditionType.EQUALS, iframe3)
		pr2.setParentObject(pr)
		pr3.setParentObject(pr2)
		def flag = 1


		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr3)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr3)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.scrollToElement(nextButton, 0)
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.doubleClick(objectSpecifiList)



	}

	@Keyword
	def DoubleClickOnSpecificRowExchangeRateDBU(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"
		String iframe3 = "//iframe[@id='exchangeRateDBUFrame']"
		TestObject pr3 = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr3.addProperty("xpath", ConditionType.EQUALS, iframe3)
		pr2.setParentObject(pr)
		pr3.setParentObject(pr2)
		def flag = 1


		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr3)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"

		TestObject nextButton = new TestObject()
		nextButton.setParentObject(pr3)
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)


		for(int i = 0; i < 5; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.scrollToElement(nextButton, 0)
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		WebUI.doubleClick(objectSpecifiList)



	}

	@Keyword
	def getRowContentValues(String value){

		String iframe1 = "//*[@name='login']"
		String iframe2 = "//*[@name='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String xpathRow = "//tr[@class='odd' or @class='even'][$value]"

		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().frame('login')
		driver.switchTo().frame('mainFrame')
		WebElement temp = driver.findElement(By.xpath(xpathRow+"//td"))
		WebUI.comment(xpathRow+"//td")

		List list = temp.findElements(By.xpath(xpathRow+"//td"))
		WebUI.switchToDefaultContent()
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		List<String> rowContentValues = new ArrayList<String>();
		for(int k = 0; k < list.size(); k++){
			int col = k+1
			String currentXpath = xpathRow +"//td[$col]"
			WebUI.comment(currentXpath)
			def objectSpecificList = testObject.addProperty("xpath", ConditionType.EQUALS, currentXpath)

			boolean present = WebUI.verifyElementPresent(objectSpecificList, 0, FailureHandling.OPTIONAL)
			String currColValue = null;
			if(present.equals(true)){
				currColValue = WebUI.getText(objectSpecificList)
				rowContentValues.add(k, currColValue)
				WebUI.comment("column index: $k, value: $currColValue")
			}
		}

		return rowContentValues

	}

	@Keyword
	def getSpecificColumnContentValues(List<String> value, String columnIndex){

		List<String> rowContentValues = value;

		int targetIndex = Integer.valueOf(columnIndex)

		println targetIndex

		targetIndex = targetIndex-1

		String columnValue = rowContentValues.get(targetIndex)

		return columnValue

	}


}

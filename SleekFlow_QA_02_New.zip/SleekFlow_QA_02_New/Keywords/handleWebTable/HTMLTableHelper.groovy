package handleWebTable

import java.text.SimpleDateFormat
import java.util.List

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class HTMLTableHelper {

	//**@role='columnheader' is must be different in every web application. hence, it should be changed to another attribute or selector
	//variable xpath that represent column header
	static final String COLUMN_HEADER_XPATH = "//*[@role='columnheader' and contains(.,'{dinamicValue}')]"
	//variable xpath that represent every row on the table
	static final String TABLE_ROW_XPATH = '//*[@role="rowgroup"]'
	//variable xpath that represent the next button on the table
	TestObject to = new TestObject()
	def BUTTON_NEXT_ON_TABLE = to.addProperty("xpath", ConditionType.EQUALS, "//button[contains(.,'Next')]")
	String ROW_IN_SPECIFIC_COLUMN_XPATH = '//*[@class="rt-tr-group"][{indexOfRow}]//*[@role="gridcell"][{indexOfColumn}]'//"(//tr/td[{indexOfColumn}])[{indexOfRow}]"
	//variable xpath that represent column header for table in a popup
	//	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'Nomor Rekening')]"
	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'{dinamicValue}')]"
	//variable xpath that represent every row for table in a popup
	static final String TABLE_ROW_POPUP_XPATH = "//tr[@role='row' or @class='odd' or @class='even']"

	@Keyword
	def verifyColumnHeader(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		TestObject to = new TestObject()

		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_XPATH.replace('{dinamicValue}', it))
			//to.setParentObject(iFrame path) -> add this line if necessary

			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def getTotalRowPerPage(){
		WebDriver driver = DriverFactory.getWebDriver()

		try {
			WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
			List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
			KeywordUtil.logInfo("total number of list per page: "+list.size())
			return list.size()

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of list per page: 0")
			return 0
		}
	}

	@Keyword
	def verifyListOnTableContainsSpecificValue(List<String> data){
		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}

	@Keyword
	def getTotalListOnTableAllPages(){
		int totalAllList = getTotalRowPerPage()
		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				totalAllList += getTotalRowPerPage()
			}

		} catch (Exception e) {
			e.printStackTrace()
		}
		KeywordUtil.logInfo("total number of list on the table: "+totalAllList)
		return totalAllList

	}

	@Keyword
	def verifyAscendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyAscendingByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []
		TestObject testObject = new TestObject()
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
					currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
					currentRow = currentRow.replace("{indexOfRow}", k.toString() )
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText = WebUI.getText(rowInSpecificColumn)
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
				currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
				currentRow = currentRow.replace("{indexOfRow}", k.toString() )
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText = WebUI.getText(rowInSpecificColumn)
				listOfRowValue.add(getText)
				sort_listOfRowValue.add(getText)

			}
		}

		println "before sort...: "+listOfRowValue
		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
		}

		if(listOfRowValue == sort_listOfRowValue.sort()){
			KeywordUtil.markPassed("List is sorting in ascending order")
		}else{
			KeywordUtil.markFailed("List is not sorting in ascending order")
		}
		println "after sort: "+listOfRowValue.sort()
	}

	@Keyword
	def verifyDescendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyDescendingByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []
		TestObject testObject = new TestObject()
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
					currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
					currentRow = currentRow.replace("{indexOfRow}", k.toString() )
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText = WebUI.getText(rowInSpecificColumn)
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
				currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
				currentRow = currentRow.replace("{indexOfRow}", k.toString() )
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText = WebUI.getText(rowInSpecificColumn)
				listOfRowValue.add(getText)
				sort_listOfRowValue.add(getText)

			}
		}

		println "before sort...: "+listOfRowValue
		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
		}
		sort_listOfRowValue.sort()
		if(listOfRowValue == sort_listOfRowValue.reverse()){
			KeywordUtil.markPassed("List is sorting in descending order")
		}else{
			KeywordUtil.markFailed("List is not sorting in descending order")
		}
		listOfRowValue.sort()
		println "after sort reverse: "+listOfRowValue.reverse()
	}

	@Keyword
	def verifySortedRandomlyByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifySortedRandomlyByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sortAsc_listOfRowValue= []
		List sortDesc_listOfRowValue= []
		TestObject testObject = new TestObject()
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
					currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
					currentRow = currentRow.replace("{indexOfRow}", k.toString() )
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText = WebUI.getText(rowInSpecificColumn)
					listOfRowValue.add(getText)
					sortAsc_listOfRowValue.add(getText)
					sortDesc_listOfRowValue.add(getText)
				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = ROW_IN_SPECIFIC_COLUMN_XPATH
				currentRow = currentRow.replace("{indexOfColumn}", indexOfColumn )
				currentRow = currentRow.replace("{indexOfRow}", k.toString() )
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText = WebUI.getText(rowInSpecificColumn)
				listOfRowValue.add(getText)
				sortAsc_listOfRowValue.add(getText)
				sortDesc_listOfRowValue.add(getText)
			}
		}

		"convert list of string to  list of date"
		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)

			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			for (int i=0; i < sortAsc_listOfRowValue.size(); i++) {
				sortAsc_listOfRowValue[i] =  dateFormat.parse(sortAsc_listOfRowValue[i])
			}
			for (int n=0; n < sortDesc_listOfRowValue.size(); n++) {
				sortDesc_listOfRowValue[n] =  dateFormat.parse(sortDesc_listOfRowValue[n])
			}
		}
		sortDesc_listOfRowValue.sort()
		if(listOfRowValue == sortAsc_listOfRowValue.sort()){ //verify asc
			KeywordUtil.markFailed("List is sorted in ascending order")
		}else if(listOfRowValue == sortDesc_listOfRowValue.reverse()){// verify desc
			KeywordUtil.markFailed("List is sorted in descending order")
		}else{//verify random
			KeywordUtil.markPassed("List is not sorted in descending or ascending order. The data is randomly listed")
		}
		println "listOfRowValue: "+listOfRowValue
		println "sortAsc_listOfRowValue: "+listOfRowValue.sort()
		println "sortDesc_listOfRowValue: "+listOfRowValue.reverse()
	}

	@Keyword
	def verifyDateIsMatchWithSearchDate(String input_dateFrom, String input_dateTo, List<Integer> columnIndexes, String formatDate){
		// input_dateFrom/input_dateTo/formatDate can be for example: yyyy-MM-dd or yyyy-MM-dd hh:mm:ss.sss depends on the web table date format
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper_Kaltim_BO.verifyDateIsMatchWithSearchDate'('2018-05-01', '2049-05-01', [2, 3], 'yyyy-MM-dd')
		//***


		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().defaultContent();
		TestObject testObject = new TestObject()
		def datefrom
		def dateTo
		int totalRowPerPage

		List listOfDate= []
		def getText_dateFrom
		def getText_dateTo

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.delay(1)
				totalRowPerPage = getTotalRowPerPage()
				for(int i=1; i<= totalRowPerPage; i++){
					if(columnIndexes.size() > 1){
						//WebUI.delay(1)
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						//WebUI.delay(1)
						getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
						listOfDate.add(getText_dateFrom)
						listOfDate.add(getText_dateTo)
					}else{
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						listOfDate.add(getText_dateFrom)

					}

				}
				println "list perpage: "+ listOfDate
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				WebUI.delay(1)
			}

		} catch (Exception e) {
			WebUI.delay(1)
			totalRowPerPage = getTotalRowPerPage()
			for(int i=1; i<= totalRowPerPage; i++){
				if(columnIndexes.size() > 1){
					//WebUI.delay(1)
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					//WebUI.delay(1)
					getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
					listOfDate.add(getText_dateFrom)
					listOfDate.add(getText_dateTo)
				}else{
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					listOfDate.add(getText_dateFrom)

				}

			}
			println "list perpage: "+ listOfDate
		}


		driver.switchTo().defaultContent();

		println "before remove: "+ listOfDate

		'remove the empty value in the list'
		for(int x=0; x< listOfDate.size(); x++){
			if(listOfDate[x] == ''){
				listOfDate.remove(x)
				x = x-1
			}
		}
		println "after remove: "+listOfDate
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)//("yyyy-mm-dd")
		'convert list of string listOfDate to list of dates '
		for (int k=0; k < listOfDate.size(); k++) {
			listOfDate[k] =  dateFormat.parse(listOfDate[k])

			if(listOfDate[k] > dateFormat.parse(input_dateFrom) && listOfDate[k] < dateFormat.parse(input_dateTo)){
				KeywordUtil.markPassed("date is match")
			}else{
				KeywordUtil.markFailed("date is not match for date: "+ listOfDate[k])
			}
		}
		println listOfDate

	}

	@Keyword
	def checkOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		////div[@class='tr clearfix vs-repeat-repeated-element ng-scope']
		String xpath = "//div[@class='tr clearfix vs-repeat-repeated-element ng-scope' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@type='checkbox']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.check(objectSpecifiList)
		WebUI.verifyElementChecked(objectSpecifiList, 0)

	}

	@Keyword
	def unCheckOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//div[@role='gridcell']/*[@type='checkbox']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.uncheck(objectSpecifiList)
		WebUI.verifyElementNotChecked(objectSpecifiList, 0)

	}

	@Keyword
	def checkOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.check(checkbox_header)
		WebUI.verifyElementChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementChecked(testObject, 0)
		}

	}
	@Keyword
	def unCheckOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.uncheck(checkbox_header)
		WebUI.verifyElementNotChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementNotChecked(testObject, 0)
		}

	}

	@Keyword
	def clickEditIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[2]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickEyeIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[1]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeleteIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[3]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeleteIconOnSpecificRow_downloadReportMenu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@text='Delete']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	@Keyword
	def clickDownloadIconOnSpecificRow_downloadReportMenu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@text='Download']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Lock']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Unlock']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Reset']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Activate']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Inactivate']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Resend']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Release']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def verifyColumnHeaderPopUp(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		TestObject to = new TestObject()
		TestObject pr = new TestObject()
		TestObject pr2 = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_POPUP_XPATH.replace('{dinamicValue}', it))
			to.setParentObject(pr2)
			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def verifyListOnPopUpTableContainsSpecificValue(List<String> data){

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		TestObject pr = new TestObject()
		TestObject pr2 = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}

	@Keyword
	def checkOnSpecificRowPopUp(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		TestObject pr = new TestObject()
		TestObject pr2 = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.check(objectSpecifiList)
		WebUI.verifyElementChecked(objectSpecifiList, 0)

	}

}

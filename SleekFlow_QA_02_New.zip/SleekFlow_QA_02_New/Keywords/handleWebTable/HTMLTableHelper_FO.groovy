package handleWebTable

import java.awt.Robot
import java.awt.Toolkit
import java.awt.datatransfer.Clipboard
import java.awt.datatransfer.StringSelection
import java.awt.event.KeyEvent
import java.math.RoundingMode
import java.text.Normalizer
import java.text.NumberFormat;
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors

import org.apache.commons.lang.RandomStringUtils
import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.Keys
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.SelectorMethod
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import keys.SendKeys
import keys.scrollElementAdjusted as ScrollElement
import keys.SetTextHandler
import keys.ClickUsingJS

public class HTMLTableHelper_FO {

	TestObject to = new TestObject()
	def BUTTON_NEXT_ON_TABLE = to.addProperty("xpath", ConditionType.EQUALS, "//div[@id='t-SearchPagePagination-next']")

	TestObject pr = new TestObject()

	TestObject pr2 = new TestObject()


	String ROW_IN_SPECIFIC_COLUMN_XPATH = '//*[@class="rt-tr-group"][{indexOfRow}]//*[@role="gridcell"][{indexOfColumn}]'//"(//tr/td[{indexOfColumn}])[{indexOfRow}]"
	//variable xpath that represent column header for table in a popup
	//	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'Nomor Rekening')]"
	static final String COLUMN_HEADER_POPUP_XPATH = "//*[@class='sorting_disabled' and contains(.,'{dinamicValue}')]"
	//variable xpath that represent every row for table in a popup
	static final String TABLE_ROW_POPUP_XPATH = "//tr[@role='row' or @class='odd' or @class='even']"

	//**@role='columnheader' is must be different in every web application. hence, it should be changed to another attribute or selector
	//variable xpath that represent column header
	static final String COLUMN_HEADER_XPATH = "//div[contains(@class,'th sorting') or contains(@class, 'th sorting th-createdby') or contains(@class, 'th flex-auto ng-scope') and contains(.,'{dinamicValue}')]"
	static final String COLUMN_HEADER_XPATH2 = "//tr//th[text()='{dinamicValue}' or .//span['{dinamicValue}']]"

	//variable xpath that represent every row on the table
	static final String TABLE_ROW_XPATH = "//tr[@data-row-key]"
	//variable xpath that represent the next button on the table

	@Keyword
	def verifyColumnHeader(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders = null){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")



		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_XPATH2.replace('{dinamicValue}', it))

			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def getTotalRowPerPage(){
		WebDriver driver = DriverFactory.getWebDriver()

		try {

			WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
			List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of list per page: "+list.size())
			WebUI.switchToDefaultContent()
			return list.size()

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of list per page: 0")
			return 0
		}
	}

	@Keyword
	def getTotalRowPerPageString(){
		WebDriver driver = DriverFactory.getWebDriver()

		try {

			WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
			List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of list per page: "+list.size())
			WebUI.switchToDefaultContent()
			int size =  list.size()
			String s = String.valueOf(size)
			return s

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of list per page: 0")
			String s = '0'
			return s
		}
	}





	@Keyword
	def verifyListOnTableContainsSpecificValue(List<String> data, FailureHandling handler = FailureHandling.STOP_ON_FAILURE){

		boolean present = false

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String xpath

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpath = "//div[contains(@id,'t-Workflow') and @class='']//tr["
		}else if(checkWorkflowPage.equals(false)){
			xpath = "//tr["
		}

		String temp = ""
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 2; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.scrollToElement(objectSpecifiList, 0, FailureHandling.STOP_ON_FAILURE)
				WebUI.verifyElementPresent(objectSpecifiList, 0)
				present = true
				break
			}else if(i==14){
				if(handler == FailureHandling.STOP_ON_FAILURE){
					KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				}
				else {
					KeywordUtil.logInfo("specified row with xpath $xpath not found")
				}
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}
		return present
	}

	@Keyword
	def verifyListOnTableContainingSpecificValue(List<String> data){
		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String xpath

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpath = "//div[contains(@id,'t-Workflow') and @class='']//tr["
		}else if(checkWorkflowPage.equals(false)){
			xpath = "//tr["
		}

		String temp = ""
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.verifyElementVisible(objectSpecifiList)
				break
			}else if(i==14){
				KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}
		}
	}

	@Keyword
	def clickListOnTableContainsSpecificValue(List<String> data){

		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)
	}

	@Keyword
	def verifyListOnTableContainsSpecificValueOutputBoolean(List<String> data){

		String temp = ""
		String xpath = "//td[contains(@class ,"")]//div"
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		Boolean Present
		//Present  = WebUI.verifyElementPresent(, 0)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		Present  = WebUI.verifyElementPresent(objectSpecifiList,0)

		return Present
	}

	@Keyword
	def verifyListOnResultTableContainsSpecificValue(List<String> data){

		String temp = ""
		String xpath = "//div[@class='']//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.verifyElementVisible(objectSpecifiList)
				break
			}else if(i==14){
				KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}
	}

	@Keyword
	def verifyListOnCurrentTableContainsSpecificValue(List<String> data){

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String xpath

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpath = "//div[contains(@id,'t-Workflow') and @class='']//*[@id='t-WorkflowSectionTag-current']//tr["
		}else if(checkWorkflowPage.equals(false)){
			xpath = "//*[@id='t-WorkflowSectionTag-current']//tr["
		}
		String temp = ""

		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.verifyElementVisible(objectSpecifiList)
				break
			}else if(i==14){
				KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}
	}

	@Keyword
	def verifyListOnNewTableContainsSpecificValue(List<String> data){

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String xpath

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpath = "//div[contains(@id,'t-Workflow') and @class='']//*[@id='t-WorkflowSectionTag-new']//tr["
		}else if(checkWorkflowPage.equals(false)){
			xpath = "//*[@id='t-WorkflowSectionTag-new']//tr["
		}
		String temp = ""

		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.verifyElementVisible(objectSpecifiList)
				break
			}else if(i==14){
				KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}
	}

	//belum bisa dipakai
	@Keyword
	def getTotalListOnTableAllPages(){
		int totalAllList = getTotalRowPerPage()
		//		String iframe1 = "//iframe[@id='login']"
		//		String iframe2 = "//iframe[@id='mainFrame']"
		//
		//		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		//		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)
		to.setParentObject(pr2)
		try {

			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				totalAllList += getTotalRowPerPage()
			}

		} catch (Exception e) {
			e.printStackTrace()
		}
		KeywordUtil.logInfo("total number of list on the table: "+totalAllList)
		return totalAllList

	}
	//belum bisa dipakai
	@Keyword
	def verifyAscendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate=''){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyAscendingByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []

		TestObject testObject = new TestObject()
		TestObject currentPage = new TestObject()
		currentPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[@class='ant-select-selection-item']")
		String currPage = WebUI.getAttribute(currentPage, "title")
		WebUI.comment("currpage = $currPage")
		TestObject lastPage = new TestObject()
		lastPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		String lastPageValue =WebUI.getText(lastPage).replace("of", "").trim()
		WebUI.comment("lastPageValue = $lastPageValue")
		def rowInSpecificColumn

		try {
			while (currPage < lastPageValue) {
				totalRowPerPage = getTotalRowPerPage()
				currPage = WebUI.getAttribute(currentPage, "title")
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = "//tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div//a | //tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div[not(./a)]"

					KeywordUtil.logInfo(k.toString())

					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFKD);
					KeywordUtil.logInfo("get text result: "+ getText)
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)

			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = "//tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div//a | //tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div[not(./a)]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFKD);
				KeywordUtil.logInfo("get text result: "+ getText)
				listOfRowValue.add(getText)
				sort_listOfRowValue.add(getText)

			}
		}

		println "before sort...: "+listOfRowValue
		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
		}
		List<String> sorted_ListValue = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder())).collect(Collectors.toList());

		if(listOfRowValue == sorted_ListValue){
			KeywordUtil.markPassed("List is sorting in ascending order")
		}else{
			KeywordUtil.markFailed("List is not sorting in ascending order")
		}
		println "after sort: "+sort_listOfRowValue
	}
	//belum bisa dipakai
	@Keyword
	def verifyDescendingByColumnIndex(String indexOfColumn, String typeOfText, String formatDate=''){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifyDescendingByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sort_listOfRowValue= []

		TestObject testObject = new TestObject()
		TestObject currentPage = new TestObject()
		currentPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[@class='ant-select-selection-item']")
		String currPage = WebUI.getAttribute(currentPage, "title")
		WebUI.comment("currpage = $currPage")
		TestObject lastPage = new TestObject()
		lastPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		String lastPageValue =WebUI.getText(lastPage).replace("of", "").trim()
		WebUI.comment("lastPageValue = $lastPageValue")

		def rowInSpecificColumn

		try {
			while (currPage < lastPageValue) {
				totalRowPerPage = getTotalRowPerPage()
				currPage = WebUI.getAttribute(currentPage, "title")
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = "//tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div//a | //tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div[not(./a)]"
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFD);
					KeywordUtil.logInfo("get text result: "+ getText)
					listOfRowValue.add(getText)
					sort_listOfRowValue.add(getText)

				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = "//tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div//a | //tr[@record or @data-row-key][$k]//td[$indexOfColumn]//div[not(./a)]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText =  Normalizer.normalize(WebUI.getText(rowInSpecificColumn), Normalizer.Form.NFD);
				KeywordUtil.logInfo("get text result: "+ getText)
				listOfRowValue.add(getText)
				sort_listOfRowValue.add(getText)

			}
		}

		//WebUI.verifyElementNotClickable(BUTTON_NEXT_ON_TABLE)

		List<String> sorted_ListValue = new ArrayList()
		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			'convert list of string listOfRowValue to list of dates '
			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			'convert list of string sort_listOfRowValue to list of dates '
			for (int i=0; i < sort_listOfRowValue.size(); i++) {
				sort_listOfRowValue[i] =  dateFormat.parse(sort_listOfRowValue[i])
			}
			sorted_ListValue = sort_listOfRowValue
			Collections.sort(sorted_ListValue, Collections.reverseOrder())

		}else {
			sorted_ListValue = sort_listOfRowValue.stream().sorted(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.reverseOrder())).collect(Collectors.toList());
		}

		println "before sort...: "+listOfRowValue
		if(listOfRowValue == sorted_ListValue){
			KeywordUtil.markPassed("List is sorting in descending order")
		}else{
			KeywordUtil.markFailed("List is not sorting in descending order")
		}
		//		listOfRowValue.sort()
		println "after sort reverse: "+sorted_ListValue
	}
	//belum bisa dipakai
	@Keyword
	def verifySortedRandomlyByColumnIndex(String indexOfColumn, String typeOfText, String formatDate){
		//typeOfText can be "date" if it refers to a date, otherwise it will be anything, example: "not date", "string", etc.
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.verifySortedRandomlyByColumnIndex'('3', 'not date')
		//***

		int totalRowPerPage
		List listOfRowValue= []
		List sortAsc_listOfRowValue= []
		List sortDesc_listOfRowValue= []
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def rowInSpecificColumn

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				totalRowPerPage = getTotalRowPerPage()
				for(int k = 1; k <= totalRowPerPage; k++){
					def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
					KeywordUtil.logInfo(k.toString())


					rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
					KeywordUtil.logInfo("get text of xpath: "+ currentRow)
					def getText = WebUI.getText(rowInSpecificColumn)
					listOfRowValue.add(getText)
					sortAsc_listOfRowValue.add(getText)
					sortDesc_listOfRowValue.add(getText)
				}

				WebUI.click(BUTTON_NEXT_ON_TABLE)
				WebUI.delay(1)
			}
		} catch (Exception e) {
			totalRowPerPage = getTotalRowPerPage()
			for(int k = 1; k <= totalRowPerPage; k++){

				def currentRow = "//tr[@class='odd' or @class='even'][$k]//td[$indexOfColumn]"
				KeywordUtil.logInfo(k.toString())


				rowInSpecificColumn = testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
				KeywordUtil.logInfo("catch get text of xpath: "+ currentRow)
				def getText = WebUI.getText(rowInSpecificColumn)
				listOfRowValue.add(getText)
				sortAsc_listOfRowValue.add(getText)
				sortDesc_listOfRowValue.add(getText)
			}
		}

		"convert list of string to  list of date"
		if(typeOfText.toLowerCase() == "date"){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)

			for (int k=0; k < listOfRowValue.size(); k++) {
				listOfRowValue[k] =  dateFormat.parse(listOfRowValue[k])
			}
			for (int i=0; i < sortAsc_listOfRowValue.size(); i++) {
				sortAsc_listOfRowValue[i] =  dateFormat.parse(sortAsc_listOfRowValue[i])
			}
			for (int n=0; n < sortDesc_listOfRowValue.size(); n++) {
				sortDesc_listOfRowValue[n] =  dateFormat.parse(sortDesc_listOfRowValue[n])
			}
		}
		sortDesc_listOfRowValue.sort()
		if(listOfRowValue == sortAsc_listOfRowValue.sort()){ //verify asc
			KeywordUtil.markFailed("List is sorted in ascending order")
		}else if(listOfRowValue == sortDesc_listOfRowValue.reverse()){// verify desc
			KeywordUtil.markFailed("List is sorted in descending order")
		}else{//verify random
			KeywordUtil.markPassed("List is not sorted in descending or ascending order. The data is randomly listed")
		}
		println "listOfRowValue: "+listOfRowValue
		println "sortAsc_listOfRowValue: "+listOfRowValue.sort()
		println "sortDesc_listOfRowValue: "+listOfRowValue.reverse()
	}
	//belum bisa dipakai
	@Keyword
	def verifyDateIsMatchWithSearchDate(String input_dateFrom, String input_dateTo, List<Integer> columnIndexes, String formatDate){
		// input_dateFrom/input_dateTo/formatDate can be for example: yyyy-MM-dd or yyyy-MM-dd hh:mm:ss.sss depends on the web table date format
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper_Kaltim_BO.verifyDateIsMatchWithSearchDate'('2018-05-01', '2049-05-01', [2, 3], 'yyyy-MM-dd')
		//***


		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().defaultContent();
		TestObject testObject = new TestObject()
		def datefrom
		def dateTo
		int totalRowPerPage

		List listOfDate= []
		def getText_dateFrom
		def getText_dateTo

		try {
			while (WebUI.verifyElementClickable(BUTTON_NEXT_ON_TABLE)) {
				WebUI.delay(1)
				totalRowPerPage = getTotalRowPerPage()
				for(int i=1; i<= totalRowPerPage; i++){
					if(columnIndexes.size() > 1){
						//WebUI.delay(1)
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						//WebUI.delay(1)
						getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
						listOfDate.add(getText_dateFrom)
						listOfDate.add(getText_dateTo)
					}else{
						getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
						listOfDate.add(getText_dateFrom)

					}

				}
				println "list perpage: "+ listOfDate
				WebUI.click(BUTTON_NEXT_ON_TABLE )
				WebUI.delay(1)
			}

		} catch (Exception e) {
			WebUI.delay(1)
			totalRowPerPage = getTotalRowPerPage()
			for(int i=1; i<= totalRowPerPage; i++){
				if(columnIndexes.size() > 1){
					//WebUI.delay(1)
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					//WebUI.delay(1)
					getText_dateTo = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(1)+"]")).getText()
					listOfDate.add(getText_dateFrom)
					listOfDate.add(getText_dateTo)
				}else{
					getText_dateFrom = driver.findElement(By.xpath("//*[@class='rt-tr-group']["+i+"]//*[@role='gridcell']["+columnIndexes.get(0)+"]")).getText()
					listOfDate.add(getText_dateFrom)

				}

			}
			println "list perpage: "+ listOfDate
		}


		driver.switchTo().defaultContent();

		println "before remove: "+ listOfDate

		'remove the empty value in the list'
		for(int x=0; x< listOfDate.size(); x++){
			if(listOfDate[x] == ''){
				listOfDate.remove(x)
				x = x-1
			}
		}
		println "after remove: "+listOfDate
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)//("yyyy-mm-dd")
		'convert list of string listOfDate to list of dates '
		for (int k=0; k < listOfDate.size(); k++) {
			listOfDate[k] =  dateFormat.parse(listOfDate[k])

			if(listOfDate[k] > dateFormat.parse(input_dateFrom) && listOfDate[k] < dateFormat.parse(input_dateTo)){
				KeywordUtil.markPassed("date is match")
			}else{
				KeywordUtil.markFailed("date is not match for date: "+ listOfDate[k])
			}
		}
		println listOfDate

	}

	@Keyword
	def checkOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		ScrollElement scrollAdjusted = new ScrollElement()
		ClickUsingJS clickjs = new ClickUsingJS()
		String temp = ""
		String xpathrow = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")]  and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpathrow = xpathrow + temp
		}
		xpathrow = xpathrow + "]//input[@type='checkbox' and not(@disabled='true')]"
		println xpathrow
		KeywordUtil.logInfo(xpathrow)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathrow)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		WebUI.delay(5)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}

		def checked = WebUI.verifyElementNotChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(true)){
			scrollAdjusted.scrollIntoElementWithOffset(objectSpecifiList, 500, 150)
			clickjs.ClickUsingJavaScript(objectSpecifiList, 0)
			//			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
		}

	}

	@Keyword
	def unCheckOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])


		String temp = ""
		String xpathrow = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")]'
			}
			xpathrow = xpathrow + temp
		}
		xpathrow = xpathrow + "]//input[@type='checkbox' and not(@disabled='true')]"
		println xpathrow
		KeywordUtil.logInfo(xpathrow)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathrow)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		WebUI.delay(5)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}


		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(true)){
			WebUI.uncheck(objectSpecifiList)
			WebUI.verifyElementNotChecked(objectSpecifiList, 0)
		}

	}

	@Keyword
	def unCheckAllRowOnSpecificHeader(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])


		String temp = ""
		String xpathrow = "//thead[@class='ant-table-thead']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpathrow = xpathrow + temp
		}
		xpathrow = xpathrow + "]//input[@type='checkbox' and not(@disabled='true')]"
		println xpathrow
		KeywordUtil.logInfo(xpathrow)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathrow)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		WebUI.delay(5)

		WebUI.uncheck(objectSpecifiList)

		def unchecked = WebUI.verifyElementNotChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(unchecked.equals(true)){
			WebUI.uncheck(objectSpecifiList)
			WebUI.verifyElementNotChecked(objectSpecifiList, 0)
		}

	}

	//belum bisa dipakai
	@Keyword
	def checkOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.check(checkbox_header)
		WebUI.verifyElementChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementChecked(testObject, 0)
		}

	}
	@Keyword
	def unCheckOnAllRowPerPageByTHeaderCheckbox(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox'()
		//***
		TestObject testObject = new TestObject()
		def checkbox_header = testObject.addProperty("xpath", ConditionType.EQUALS, "//*[@class='rt-thead -header']//*[@type='checkbox']")
		WebUI.uncheck(checkbox_header)
		WebUI.verifyElementNotChecked(checkbox_header, 0)
		def checkbox_rows
		def totalRowPerPage = getTotalRowPerPage()
		for(int i=1; i <= totalRowPerPage; i++){
			checkbox_rows = testObject.addProperty("xpath", ConditionType.EQUALS, "(//*[@role='gridcell']/*[@type='checkbox'])["+i+"]")
			WebUI.verifyElementNotChecked(testObject, 0)
		}

	}

	@Keyword
	def clickEditIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//*[contains(@id,'t-account-group-edit') or contains(@id,'t-edit') or contains(@href, 'domestic-bank/edit') or @aria-label = 'edit']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDetailIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[contains(@id,'t-detail')]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickEyeIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//*[@class='rt-tr-group' and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[1]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

	}

	@Keyword
	def clickDeleteLabelOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[@aria-label='Delete']"
		println xpath
		TestObject testObject = new TestObject()

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		//		WebUI.scrollToElement(objectSpecifiList, 0)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeleteIconOnSpecificRowPayroll(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		try{
			String iframe1 = "//iframe[@id='login']"
			String iframe2 = "//iframe[@id='mainFrame']"

			pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
			pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

			pr2.setParentObject(pr)

			String temp = ""
			String xpath = "//tr[@class='odd' or @class='even']["
			String value
			for(int i= 0; i< data.size(); i++){
				value = data.get(i)
				if(i != data.size()-1){
					temp = 'contains(.,"'+value+'") and '
				}else{
					temp = 'contains(.,"'+value+'")'
				}
				xpath = xpath + temp
			}
			xpath = xpath + "]//a[@class='btn_Delete']"
			println xpath
			TestObject testObject = new TestObject()
			def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
			WebUI.comment(xpath)
			WebUI.click(objectSpecifiList)

		}catch(Exception e){
			WebUI.comment("File not found, continue executing test case")
		}

	}

	//belum bisa dipakai
	@Keyword
	def clickDeleteIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//a[contains(@href, 'delete')] | " + xpath + "]//button[@id='t-button-delete']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.click(objectSpecifiList)
				break
			}else if(i==14){
				KeywordUtil.markFailedAndStop("specified row with xpath $xpath not found")
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}

		}



	}

	@Keyword
	def clickDownloadIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='t-button-download']"
		println xpath
		TestObject testObject = new TestObject()

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.enhancedClick(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Lock']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickUnLockIconOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Unlocked']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Reset']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Active']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@title='Inactive']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Resend']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}
	//belum bisa dipakai
	@Keyword
	def clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)
		pr2.setParentObject(pr)
		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//button[@id='Release']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def verifyColumnHeaderPopUp(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		TestObject to = new TestObject()

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)


		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_POPUP_XPATH.replace('{dinamicValue}', it))
			to.setParentObject(pr2)
			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def verifyListOnPopUpTableContainsSpecificValue(List<String> data){

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}

	@Keyword
	def checkOnSpecificRowPopUp(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@type='radio' and not(@disabled='true')]"
		println xpath
		TestObject testObject = new TestObject()
		//testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.check(objectSpecifiList)
		WebUI.verifyElementChecked(objectSpecifiList, 0)

	}

	@Keyword
	def uncheckOnSpecificRowPopUp(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='accountFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='odd' or @class='even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//input[@class='tableCheck']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.uncheck(objectSpecifiList)
		WebUI.verifyElementNotChecked(objectSpecifiList, 0)

	}

	@Keyword
	def clickNameHyperLink(List<String> data, String hyperlinkName, FailureHandling handler = FailureHandling.STOP_ON_FAILURE){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']//a[contains(.,"'+hyperlinkName+'")]'
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.click(objectSpecifiList)
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}

	}

	@Keyword
	def clickNameHyperLinkAlternative(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + '][1]//a'
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				WebUI.click(objectSpecifiList)
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}

	}

	@Keyword
	def clickSpanHyperLink(List<String> data, String hyperlinkName){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']//span[contains(.,"'+hyperlinkName+'")]'
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickTdSpecificRow(List<String> data, String hyperlinkName){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']//td[contains(.,"'+hyperlinkName+'")]'
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickNameHyperLinkPopUp(String data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='detailRecordFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//td//a" + "[text()='"+data+"']"
		println xpath
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectHyperlink = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectHyperlink)

	}

	@Keyword
	def accessDetailApprovalMatrix(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***



		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String temp = ""
		String xpath = "//tr[@class='parent odd' or @class='parent even']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]//td[1]//a"
		println xpath
		KeywordUtil.logInfo(xpath)
		TestObject testObject = new TestObject()
		testObject.setParentObject(pr2)
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		//		WebUI.scrollToElement(objectSpecifiList, 5)
		WebUI.click(objectSpecifiList)


	}



	@Keyword
	def verifyListOnTableNotContainsSpecificValue(List<String> data){

		String temp = ""
		String xpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementNotPresent(objectSpecifiList, 5)
	}

	@Keyword
	def DoubleClickOnSpecificRow(List<String> data){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		def flag = 1


		String temp = ""
		String xpath = "//tbody//tr[@data-row-key and "
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		WebUI.verifyElementVisible(objectSpecifiList)
		WebUI.doubleClick(objectSpecifiList)



	}


	@Keyword
	def verifyColumnContainsSpecificValue(String input, int colIndex){


		TestObject testObject = new TestObject()



		def totalRowPerPage = getTotalRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope'][$k]//div[contains(@class,'td') and not(@aria-hidden='true')][$colIndex]"

			testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
			KeywordUtil.logInfo("get text of xpath: "+ currentRow)
			WebUI.scrollToElement(testObject, 0)
			def textResult = WebUI.getText(testObject)
			textResult.equalsIgnoreCase(input)

			KeywordUtil.logInfo("row: "+ k + " Passed")

		}


	}


	@Keyword
	def editonAccountSetupList(List<String> data, String aliasName = "", String maxDebit = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"

		String xpathCheck = xpath + "//input[@type='checkbox' and @class='ant-checkbox-input' and not(@disabled)]"

		String xpath2 = xpath + "//td//input[contains(@id, 't-account_alias')]"

		String xpath3 = xpath + "//td//input[contains(@id, 't-debit_limit')]"
		println xpath
		KeywordUtil.logInfo(xpathCheck)
		KeywordUtil.logInfo(xpath2)
		KeywordUtil.logInfo(xpath3)

		TestObject checkRowInput = new TestObject()
		def checkBoxInput = checkRowInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		TestObject accountAliasInput = new TestObject()
		def inputAlias = accountAliasInput.addProperty("xpath", ConditionType.EQUALS, xpath2)

		TestObject accountMaxDebitInput = new TestObject()
		def inputMaxDebit = accountMaxDebitInput.addProperty("xpath", ConditionType.EQUALS, xpath3)

		//		WebUI.scrollToElement(checkBoxInput, 10)
		WebUI.delay(2)
		WebUI.check(checkBoxInput)
		WebUI.verifyElementChecked(checkBoxInput, 0)

		WebUI.delay(2)

		if(!aliasName.equals("") && !aliasName.equals("null") && !aliasName.equals("ignore alias")){
			WebUI.sendKeys(inputAlias, Keys.chord(Keys.CONTROL, 'a', Keys.BACK_SPACE))
			WebUI.setText(inputAlias, aliasName)
		}else if(aliasName.equals("null")){
			WebUI.clearText(inputAlias)
		}

		WebUI.delay(2)
		if(!maxDebit.equals("") && !maxDebit.equals("null")  && !aliasName.equals("ignore debit")){
			WebUI.sendKeys(inputMaxDebit, Keys.chord(Keys.CONTROL, 'a', Keys.BACK_SPACE))

			WebUI.setText(inputMaxDebit, maxDebit)
		}else if(aliasName.equals("null")){
			WebUI.clearText(inputMaxDebit)
		}
	}

	@Keyword
	def editNotificationSettings(String data, String app = "", String email = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(.,"'+data+'")]'

		String xpathCheck = xpath + "//td[@align='center'][1]//input[@type='checkbox']"

		String xpathCheck2 = xpath + "//td[@align='center'][2]//input[@type='checkbox']"

		String xpath3 = xpath + "//td[@class='ng-binding' and text()='Saved']"
		println xpath
		KeywordUtil.logInfo(xpathCheck)
		KeywordUtil.logInfo(xpathCheck2)
		KeywordUtil.logInfo(xpath3)

		TestObject applicationInput = new TestObject()
		def checkBoxInput1 = applicationInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		TestObject emailInput = new TestObject()
		def checkBoxInput2 = emailInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck2)

		TestObject savedMessage = new TestObject()
		def messageSaved = savedMessage.addProperty("xpath", ConditionType.EQUALS, xpath3)

		WebUI.scrollToElement(checkBoxInput1, 10)
		WebUI.delay(2)


		WebUI.delay(2)

		if(!app.equals("") && !app.equals("null") && app.equals("check application")){
			WebUI.check(checkBoxInput1)
			WebUI.verifyElementChecked(checkBoxInput1, 0)
			WebUI.verifyElementPresent(messageSaved, 0)
		}

		WebUI.delay(2)
		if(!email.equals("") && !email.equals("null")  && email.equals("check email")){
			WebUI.check(checkBoxInput2)
			WebUI.verifyElementChecked(checkBoxInput2, 0)
			WebUI.verifyElementPresent(messageSaved, 0)
		}

	}


	@Keyword
	def clickonBellIconOnNotification(String index, String type, String message){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(@ng-repeat, "'+type+'") and contains(.,"'+message+'")]["'+index+'"]'

		String xpathCheck = xpath + "//i[@class='fa fa-bell-o']"

		String xpathCheckVerify = xpath + "//i[@class='fa fa-bell']"


		println xpath
		KeywordUtil.logInfo(xpathCheck)


		TestObject bellInput = new TestObject()
		def bellCheck = bellInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		TestObject bellInputActive = new TestObject()
		def bellCheckActive = bellInputActive.addProperty("xpath", ConditionType.EQUALS, xpathCheckVerify)


		WebUI.click(bellCheck)

		WebUI.delay(1)

		WebUI.verifyElementPresent(bellCheckActive, 0)

	}
	@Keyword
	def clickonDeleteIconOnNotification(String index, String type, String message){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(@ng-repeat, "'+type+'") and contains(.,"'+message+'")]["'+index+'"]'

		String xpathCheck = xpath + "//i[@class='fa fa-close ']"


		println xpath
		KeywordUtil.logInfo(xpathCheck)


		TestObject deleteInput = new TestObject()
		def deleteCheck = deleteInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		WebUI.click(deleteCheck)


	}
	@Keyword
	def checkonGeneralSetupOption(String option){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(.,"'+option+'")]'

		String xpathCheck = xpath + "//input[@ng-show='isEdit']"


		println xpath
		KeywordUtil.logInfo(xpathCheck)


		TestObject deleteInput = new TestObject()
		def deleteCheck = deleteInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		WebUI.check(deleteCheck)

		WebUI.verifyElementChecked(deleteCheck, 0)

	}

	@Keyword
	def uncheckonGeneralSetupOption(String option){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(.,"'+option+'")]'

		String xpathCheck = xpath + "//input[@ng-show='isEdit']"


		println xpath
		KeywordUtil.logInfo(xpathCheck)


		TestObject deleteInput = new TestObject()
		def deleteCheck = deleteInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		WebUI.uncheck(deleteCheck)

		WebUI.verifyElementNotChecked(deleteCheck, 0)

	}
	@Keyword
	def checkAllonGeneralSetupOption(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***
		WebDriver driver = DriverFactory.getWebDriver()

		String xpathCheck = "//input[@ng-show='isEdit']"

		WebElement temp = driver.findElement(By.xpath(xpathCheck))
		List list = temp.findElements(By.xpath(xpathCheck))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of check: "+list.size())
		WebUI.switchToDefaultContent()


		println xpathCheck

		for(int i = 1; i < list.size()+1; i++){
			TestObject deleteInput = new TestObject()
			def deleteCheck = deleteInput.addProperty("xpath", ConditionType.EQUALS, "//tr["+i+"]//input[@ng-show='isEdit']")
			if(WebUI.verifyElementNotChecked(deleteCheck, 0, , FailureHandling.OPTIONAL)){
				WebUI.check(deleteCheck)

				WebUI.verifyElementChecked(deleteCheck, 0)
				KeywordUtil.logInfo("succesfully check "+i+"")
			}

		}

	}

	@Keyword
	def verifyListOnTableContainsSpecificValueUsersMaintenance(List<String> data){

		String temp = ""
		String xpath = "//tr[@ng-repeat='row in detailUser.proxyUserList']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()

		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
	}

	@Keyword
	def customizeTableMoveItemfromSelectedtoAvailable(List<String> data){

		String moveToAvailable = "//a[@ng-click='moveItem(selected, selectedColumns,availableColumns)']"

		TestObject buttonMove = new TestObject()

		def buttonMoveToAvailable = buttonMove.addProperty("xpath", ConditionType.EQUALS, moveToAvailable)

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)
			String xpath = "//select[@ng-model='selected']//option[@label='"+value+"' and text()='"+value+"']"

			TestObject testObject = new TestObject()

			def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

			//			WebUI.scrollToElement(testObject, 0)
			WebUI.verifyElementVisible(objectSpecifiList)
			WebUI.click(objectSpecifiList)

		}

		WebUI.click(buttonMoveToAvailable)

		for(int c=0; c < data.size(); c++){
			def value = data.get(c)
			TestObject testObjectVerify = new TestObject()

			String xpathAvail = "//select[@ng-model='available']//option[@label='"+value+"' and text()='"+value+"']"


			def objectSpecifiVerify = testObjectVerify.addProperty("xpath", ConditionType.EQUALS, xpathAvail)

			//			WebUI.scrollToElement(testObjectVerify, 0)
			WebUI.verifyElementVisible(objectSpecifiVerify)

			KeywordUtil.logInfo("succesfully move "+value+" to available field")
		}


	}

	@Keyword
	def customizeTableMoveItemfromAvailabletoSelected(List<String> data){

		String moveToSelected = "//a[@ng-click='moveItem(available, availableColumns,selectedColumns)']"

		TestObject buttonMove = new TestObject()

		def buttonMoveToSelected = buttonMove.addProperty("xpath", ConditionType.EQUALS, moveToSelected)

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)
			String xpath = "//select[@ng-model='available']//option[@label='"+value+"' and text()='"+value+"']"

			TestObject testObject = new TestObject()

			def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

			//			WebUI.scrollToElement(testObject, 0)
			WebUI.verifyElementVisible(objectSpecifiList)
			WebUI.click(objectSpecifiList)

		}

		WebUI.click(buttonMoveToSelected)

		for(int c=0; c < data.size(); c++){
			def value = data.get(c)
			String xpathAvail = "//select[@ng-model='selected']//option[@label='"+value+"' and text()='"+value+"']"

			TestObject testObjectVerify = new TestObject()

			def objectSpecifiVerify = testObjectVerify.addProperty("xpath", ConditionType.EQUALS, xpathAvail)

			//			WebUI.scrollToElement(testObjectVerify, 0)
			WebUI.verifyElementVisible(objectSpecifiVerify)

			KeywordUtil.logInfo("succesfully move "+value+" to selected field")
		}


	}

	@Keyword
	def clickonBellImportantIconOnNotification(String index, String type, String message){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(@ng-repeat, "'+type+'") and contains(.,"'+message+'")]["'+index+'"]'

		String xpathCheck = xpath + "//i[@class='fa fa-bell']"

		String xpathCheckVerify = xpath + "//i[@class='fa fa-bell-o']"


		println xpath
		KeywordUtil.logInfo(xpathCheck)


		TestObject bellInput = new TestObject()
		def bellCheck = bellInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		TestObject bellInputActive = new TestObject()
		def bellCheckActive = bellInputActive.addProperty("xpath", ConditionType.EQUALS, xpathCheckVerify)


		WebUI.click(bellCheck)

		WebUI.delay(1)

		WebUI.verifyElementPresent(bellCheckActive, 0)

	}

	@Keyword
	def editNotificationSettingsUncheck(String data, String app = "", String email = ""){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = '//tr[contains(.,"'+data+'")]'

		String xpathCheck = xpath + "//td[@align='center'][1]//input[@type='checkbox']"

		String xpathCheck2 = xpath + "//td[@align='center'][2]//input[@type='checkbox']"

		String xpath3 = xpath + "//td[@class='ng-binding' and text()='Saved']"
		println xpath
		KeywordUtil.logInfo(xpathCheck)
		KeywordUtil.logInfo(xpathCheck2)
		KeywordUtil.logInfo(xpath3)

		TestObject applicationInput = new TestObject()
		def checkBoxInput1 = applicationInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck)

		TestObject emailInput = new TestObject()
		def checkBoxInput2 = emailInput.addProperty("xpath", ConditionType.EQUALS, xpathCheck2)

		TestObject savedMessage = new TestObject()
		def messageSaved = savedMessage.addProperty("xpath", ConditionType.EQUALS, xpath3)

		WebUI.scrollToElement(checkBoxInput1, 10)
		WebUI.delay(2)


		WebUI.delay(2)

		if(!app.equals("") && !app.equals("null") && app.equals("check application")){
			WebUI.uncheck(checkBoxInput1)
			WebUI.verifyElementNotChecked(checkBoxInput1, 0)
			WebUI.verifyElementPresent(messageSaved, 0)
		}

		WebUI.delay(2)
		if(!email.equals("") && !email.equals("null")  && email.equals("check email")){
			WebUI.uncheck(checkBoxInput2)
			WebUI.verifyElementNotChecked(checkBoxInput2, 0)
			WebUI.verifyElementPresent(messageSaved, 0)
		}

	}

	@Keyword
	def removeEmailTag(){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		WebDriver driver = DriverFactory.getWebDriver()


		WebElement temp = driver.findElement(By.xpath('//div[@class="tags"]'))
		List list = temp.findElements(By.xpath('//a[@ng-click="$removeTag()"]'))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total email tag: "+list.size())

		for(int i= 1; i< list.size()+1; i++){
			String xpath = '//li[1]//a[@ng-click="$removeTag()"]'

			TestObject testObject = new TestObject()

			def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

			WebUI.verifyElementVisible(objectSpecifiList)
			WebUI.click(objectSpecifiList)
			KeywordUtil.logInfo("email tag succesfully clicked: "+i)

		}

	}

	@Keyword
	def verifyFormatDate(String index, String formatDate){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//*
		//*
		WebDriver driver = DriverFactory.getWebDriver()
		WebElement temp = driver.findElement(By.xpath('//div[@schema="helpDeskTicket"]'))
		List list = temp.findElements(By.xpath('//div[@class="tr clearfix ng-scope"]'))
		int totalRowPerPage = list.size();

		println("totalRowPerPage:" + totalRowPerPage);

		DateTimeFormatter  dateFormat =  DateTimeFormatter.ofPattern(formatDate)

		for(int i= 1; i< totalRowPerPage+1; i++){
			String xpath = "//div[@class='tr clearfix ng-scope']["+i+"]//div[contains(@class,'td td-')]["+index+"]"
			WebElement el = temp.findElement(By.xpath(xpath))
			def tableData = el.getText()
			println("tableData: " + tableData)

			// TestObject testObject = new TestObject()
			// def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
			// def tableData = WebUI.getText(objectSpecifiList)

			// println("debug: "+ dateFormat.format(new Date()))

			// def tableData = "Apr 19, 2021 21:46:50 (GMT +8)"
			if (tableData.substring(tableData.lastIndexOf("+")).length() <= 3) {
				tableData = tableData.replace("+", "+0");
			}

			def dateParse1 = dateFormat.parse(tableData)
			println("debug: "+ dateFormat.format(dateParse1) + " / " + tableData)


			WebUI.verifyEqual(tableData, dateFormat.format(dateParse1))

			KeywordUtil.logInfo("row "+i+ " format matched")

		}
		WebUI.switchToDefaultContent()

	}



	@Keyword
	def clickNameHyperLinkActivityLogBO(List<String> data, String index){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//div[@class='tr clearfix ng-scope']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']['+index+']//div[@class="btn-link"]//span'
		String xpath2 = "//button[@class='next btn grid-nextpage' and not(@disabled)]"
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, xpath2)

		WebUI.scrollToElement(objectSpecifiList, 10)

		WebUI.click(objectSpecifiList)

	}


	@Keyword
	def verifyColumnHeader2(List<String> columnHeaders,List<TestObject> objectOnColumnHeaders = null){
		KeywordUtil.logInfo("identify web table using headers: $columnHeaders")



		columnHeaders.each{
			to.addProperty("xpath", ConditionType.EQUALS, COLUMN_HEADER_XPATH2.replace('{dinamicValue}', it))

			boolean a = WebUI.verifyElementVisible(to, FailureHandling.CONTINUE_ON_FAILURE)
			if(!a){
				KeywordUtil.markFailed("$it not visible to the page")
				KeywordUtil.logInfo("$it not visible to the page")
			}
		}

		objectOnColumnHeaders.each{
			boolean b = WebUI.verifyElementVisible(it, FailureHandling.CONTINUE_ON_FAILURE)
			if(!b){
				KeywordUtil.logInfo("$it not visible to the page")
			}else{
				KeywordUtil.logInfo("and $it is also visible on the column header")
			}
		}

	}

	@Keyword
	def dragandDropSelenium(int x, int y, String input){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//*
		//*
		WebDriver driver = DriverFactory.getWebDriver()
		WebElement From=driver.findElement(By.xpath("//li[@class='ng-scope angular-ui-tree-node']//div[@ui-tree-handle and .//p[contains(.,'"+input+"')]]"));

		//Using Action class for drag and drop.
		Actions act=new Actions(driver);

		//Dragged and dropped.
		act.dragAndDropBy(From, x, y).build().perform();
	}

	@Keyword
	def clickPrintButton(String fileName){
		Robot robot = new Robot();
		//robot.setAutoDelay(timeoutMilisecond)
		robot.keyPress(KeyEvent.VK_CONTROL)
		robot.keyPress(KeyEvent.VK_P)
		robot.keyRelease(KeyEvent.VK_CONTROL)
		robot.keyRelease(KeyEvent.VK_P)
		robot.setAutoDelay(5000)
		robot.keyPress(KeyEvent.VK_ENTER)
		robot.keyRelease(KeyEvent.VK_ENTER)
		robot.keyPress(KeyEvent.VK_ENTER)
		robot.keyRelease(KeyEvent.VK_ENTER)

		// C:\Users\peny.amalia\Downloads
		robot.setAutoDelay(2000)
		robot.keyPress(KeyEvent.VK_ENTER)
		robot.keyRelease(KeyEvent.VK_ENTER)

		robot.setAutoDelay(2000)
		def randomValue =RandomStringUtils.randomNumeric(3)

		String text = fileName + randomValue;
		StringSelection stringSelection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER)
		robot.keyRelease(KeyEvent.VK_ENTER)

		//WebUI.acceptAlert()
		WebUI.switchToDefaultContent()

		text = text + '.pdf'

		return text
	}

	@Keyword
	def tableUploadListPayroll(List<String> data, String hyperlinkName){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//div[@class='tr clearfix ng-scope']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']//button[@class="text-left ng-binding btn-link" and contains(.,"'+hyperlinkName+'")]'


		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		WebUI.scrollToElement(objectSpecifiList, 10)

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def verifyCutOffTime(String head, String item, String verifyHour){
		String target = "//div[@class='thumb-main full' and .//div[@class='head' and contains(.,'$head')]]//tr[contains(.,'$item')]//td[@class='text-right blue ng-binding' and contains(.,'$verifyHour')]"

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, target)

		WebUI.scrollToElement(objectSpecifiList, 10)

		WebUI.verifyElementPresent(objectSpecifiList, 0)
	}

	@Keyword
	def verifyPendingTaskSummarySelectedTask(){

		String TABLE_ROW_XPATH = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope' and .//input[@type = 'checkbox' and contains(@class,'ng-not-empty')]]"
		WebDriver driver = DriverFactory.getWebDriver()

		WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
		List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of tasks: "+list.size())
		WebUI.switchToDefaultContent()

		String sumCredit = "//tr[@ng-repeat='row in var.groupCurrency.credit.data']//td[3]"

		TestObject currentCreditTest = new TestObject()
		def creditObj = currentCreditTest.addProperty("xpath", ConditionType.EQUALS, sumCredit)

		def currentCredit = WebUI.getText(creditObj)
		WebUI.comment("credit in summary : " + currentCredit)

		String sumDebit = "//tr[@ng-repeat='row in var.groupCurrency.debit.data']//td[3]"

		TestObject currentDebitTest = new TestObject()
		def debitObj = currentDebitTest.addProperty("xpath", ConditionType.EQUALS, sumDebit)

		def currentDebit = WebUI.getText(debitObj)
		WebUI.comment("debit in summary : " + currentDebit)

		if(WebUI.verifyEqual(list.size(), Integer.valueOf(currentCredit)) && WebUI.verifyEqual(list.size(), Integer.valueOf(currentDebit))){
			WebUI.comment("task checked total equals to summary report debit and credit total")

		}
	}

	@Keyword
	def verifyPendingTaskSummaryTransactionAmount(){

		String TABLE_ROW_XPATH = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope' and .//input[@type = 'checkbox' and contains(@class,'ng-not-empty')]]//div[@class='td '][21]"
		WebDriver driver = DriverFactory.getWebDriver()

		WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
		List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of tasks: "+list.size())
		WebUI.switchToDefaultContent()

		def totalTransCalculated = 0
		WebUI.comment("total transaction amount : " + String.valueOf(totalTransCalculated))

		for(int i = 0; i<list.size(); i++){

			WebElement currentElement = list.get(i)

			def transAmount = currentElement.getText()

			totalTransCalculated = totalTransCalculated + Double.valueOf(transAmount)

			WebUI.comment("total transaction amount : " + String.valueOf(totalTransCalculated))

		}

		String sumCredit = "//tr[@ng-repeat='row in var.groupCurrency.credit.data']//td[4]"

		TestObject currentCreditTest = new TestObject()
		def creditObj = currentCreditTest.addProperty("xpath", ConditionType.EQUALS, sumCredit)

		def currentCredit = WebUI.getText(creditObj)
		WebUI.comment("credit in summary : " + currentCredit)

		String sumDebit = "//tr[@ng-repeat='row in var.groupCurrency.debit.data']//td[4]"

		TestObject currentDebitTest = new TestObject()
		def debitObj = currentDebitTest.addProperty("xpath", ConditionType.EQUALS, sumDebit)

		def currentDebit = WebUI.getText(debitObj)
		WebUI.comment("debit in summary : " + currentDebit)

		if(WebUI.verifyEqual(totalTransCalculated, Double.valueOf(currentCredit)) && WebUI.verifyEqual(totalTransCalculated, Double.valueOf(currentDebit))){
			WebUI.comment("task checked Transaction amount equals to summary report debit and credit Transaction amount")

		}

	}

	@Keyword
	def customizeTableSelectMultipleFromAvailable(List<String> data){

		WebDriver driver = DriverFactory.getWebDriver()

		Actions action=new Actions(driver);
		action.keyDown(Keys.CONTROL).build().perform();

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)
			String xpath = "//select[@ng-model='available']//option[@label='"+value+"' and text()='"+value+"']"

			//			WebUI.scrollToElement(testObject, 0)

			driver.findElement(By.xpath(xpath)).click();

		}
		action.keyUp(Keys.CONTROL).build().perform();

	}

	@Keyword
	def customizeTableSelectMultipleFromSelected(List<String> data){

		WebDriver driver = DriverFactory.getWebDriver()


		Actions action=new Actions(driver);
		action.keyDown(Keys.CONTROL).build().perform();

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)
			String xpath = "//select[@ng-model='selected']//option[@label='"+value+"' and text()='"+value+"']"

			//			WebUI.scrollToElement(testObject, 0)

			driver.findElement(By.xpath(xpath)).click();

		}
		action.keyUp(Keys.CONTROL).build().perform();
	}

	@Keyword
	def checkAllowDebitAccountGroup(String product, List<String> data){

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)

			TestObject accountTargeted = new TestObject()

			accountTargeted.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][1]//input[@type="checkbox"]')

			TestObject accountAllowDebit = new TestObject()

			accountAllowDebit.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][3]//input[@type="checkbox"]')

			WebUI.scrollToElement(accountTargeted, 0)

			if(WebUI.verifyElementNotChecked(accountTargeted, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountTargeted)

				WebUI.verifyElementChecked(accountTargeted, 0)
				WebUI.comment("successfully checked account $value")
			}

			if(WebUI.verifyElementNotChecked(accountAllowDebit, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountAllowDebit)

				WebUI.verifyElementChecked(accountAllowDebit, 0)
				WebUI.comment("successfully checked account $value allow debit")
			}else{
				WebUI.comment("account $value allow debit already been checked")
			}

		}

	}

	@Keyword
	def uncheckAllowDebitAccountGroup(String product, List<String> data){

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)

			TestObject accountTargeted = new TestObject()

			accountTargeted.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][1]//input[@type="checkbox"]')

			TestObject accountAllowDebit = new TestObject()

			accountAllowDebit.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][3]//input[@type="checkbox"]')

			WebUI.scrollToElement(accountTargeted, 0)

			if(WebUI.verifyElementNotChecked(accountTargeted, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountTargeted)

				WebUI.verifyElementChecked(accountTargeted, 0)
				WebUI.comment("successfully checked account $value")
			}

			if(WebUI.verifyElementChecked(accountAllowDebit, 0, FailureHandling.OPTIONAL)){
				WebUI.uncheck(accountAllowDebit)

				WebUI.verifyElementNotChecked(accountAllowDebit, 0)
				WebUI.comment("successfully unchecked account $value allow debit")
			}else{
				WebUI.comment("account $value allow debit already been unchecked")
			}

		}

	}

	@Keyword
	def checkAllowCreditAccountGroup(String product, List<String> data){

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)

			TestObject accountTargeted = new TestObject()

			accountTargeted.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][1]//input[@type="checkbox"]')

			TestObject accountAllowDebit = new TestObject()

			accountAllowDebit.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][4]//input[@type="checkbox"]')

			WebUI.scrollToElement(accountTargeted, 0)

			if(WebUI.verifyElementNotChecked(accountTargeted, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountTargeted)

				WebUI.verifyElementChecked(accountTargeted, 0)
				WebUI.comment("successfully checked account $value")
			}

			if(WebUI.verifyElementNotChecked(accountAllowDebit, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountAllowDebit)

				WebUI.verifyElementChecked(accountAllowDebit, 0)
				WebUI.comment("successfully checked account $value allow credit")
			}else{
				WebUI.comment("account $value allow debit already been checked")
			}

		}

	}

	@Keyword
	def uncheckAllowCreditAccountGroup(String product, List<String> data){

		for(int i= 0; i< data.size(); i++){
			def value = data.get(i)

			TestObject accountTargeted = new TestObject()

			accountTargeted.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][1]//input[@type="checkbox"]')

			TestObject accountAllowDebit = new TestObject()

			accountAllowDebit.addProperty("xpath", ConditionType.EQUALS, '//div[@schema="accountGroupAccountProductLite" and contains(., "'+product+'")]//div[@class="tr clearfix ng-scope" and contains(.,"'+value+'")]//div[contains(@class,"td")][4]//input[@type="checkbox"]')

			WebUI.scrollToElement(accountTargeted, 0)

			if(WebUI.verifyElementNotChecked(accountTargeted, 0, FailureHandling.OPTIONAL)){
				WebUI.check(accountTargeted)

				WebUI.verifyElementChecked(accountTargeted, 0)
				WebUI.comment("successfully checked account $value")
			}

			if(WebUI.verifyElementChecked(accountAllowDebit, 0, FailureHandling.OPTIONAL)){
				WebUI.uncheck(accountAllowDebit)

				WebUI.verifyElementNotChecked(accountAllowDebit, 0)
				WebUI.comment("successfully unchecked account $value allow credit")
			}else{
				WebUI.comment("account $value allow debit already been checked")
			}

		}

	}

	@Keyword
	def verifyColumnContentMatchSpecificDateFormat(String format, int colIndex){


		TestObject testObject = new TestObject()
		SimpleDateFormat sdf = new SimpleDateFormat(format)

		sdf.setTimeZone(TimeZone.getTimeZone('Etc/GMT-8'))

		def totalRowPerPage = getTotalRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope'][$k]//div[contains(@class,'td') and not(@aria-hidden='true')][$colIndex]"

			testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
			KeywordUtil.logInfo("get text of xpath: "+ currentRow)
			WebUI.scrollToElement(testObject, 0)
			def textResult = WebUI.getText(testObject)

			def dateFormat = textResult.substring(0, textResult.lastIndexOf('(')).trim()

			def date = sdf.parse(dateFormat.replace(",", ""))

			println((('dateFormat: ' + dateFormat) + ', date: ') + sdf.format(date))

			KeywordUtil.logInfo("row: "+ k + " Passed")

		}


	}

	@Keyword
	def checkLastRowonTable(){
		TestObject lastRow = new TestObject()
		def totalRowPerPage = getTotalRowPerPage()
		def lastRowXpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope'][$totalRowPerPage]//input[@type='checkbox']"

		lastRow.addProperty("xpath", ConditionType.EQUALS, lastRowXpath)
		WebUI.scrollToElement(lastRow, 0)
		if(WebUI.verifyElementNotChecked(lastRow, 0, FailureHandling.OPTIONAL)){
			WebUI.check(lastRow)
		}

	}

	@Keyword
	def uncheckLastRowonTable(){
		TestObject lastRow = new TestObject()
		def totalRowPerPage = getTotalRowPerPage()
		def lastRowXpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope'][$totalRowPerPage]//input[@type='checkbox']"

		lastRow.addProperty("xpath", ConditionType.EQUALS, lastRowXpath)
		WebUI.scrollToElement(lastRow, 0)
		if(WebUI.verifyElementChecked(lastRow, 0, FailureHandling.OPTIONAL)){
			WebUI.uncheck(lastRow)
		}

	}

	@Keyword
	def clickTransactionNoHyperlinkLastRowonTable(){
		TestObject lastRow = new TestObject()
		def totalRowPerPage = getTotalRowPerPage()
		def lastRowXpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope'][$totalRowPerPage]//div[@class='td ' or @class='td'][2]//div[@class='btn-link']"

		lastRow.addProperty("xpath", ConditionType.EQUALS, lastRowXpath)
		WebUI.scrollToElement(lastRow, 0)
		WebUI.click(lastRow)


	}

	@Keyword
	def clickTransactionNoHyperlinkFirstRowonTable(List<String> data){
		TestObject lastRow = new TestObject()
		def firstRowXpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope']["
		def temp
		def value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			firstRowXpath = firstRowXpath + temp
		}

		firstRowXpath = firstRowXpath + "][1]//div[contains(@class,'td td')][2]//div[@class='btn-link']"
		lastRow.addProperty("xpath", ConditionType.EQUALS, firstRowXpath)
		WebUI.scrollToElement(lastRow, 0)
		WebUI.click(lastRow)


	}

	@Keyword
	def verifyCloneResultOnMultipleTransferManualInput(List<String> rowCompared){

		ArrayList<ArrayList<String>> listOfLists = new ArrayList<ArrayList<String>>();
		def value
		for(int i= 0; i< rowCompared.size(); i++){
			ArrayList<String> currentList = new ArrayList<String>()
			value = rowCompared.get(i)
			KeywordUtil.logInfo("current row : $value")
			def firstRowXpath = "//tr[@class='ng-scope'][$value]//td[not(@class='p_r_0')]"

			//count column
			WebDriver driver = DriverFactory.getWebDriver()

			WebElement colSum = driver.findElement(By.xpath(firstRowXpath))
			List list = colSum.findElements(By.xpath(firstRowXpath))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of column: "+list.size())

			for(int it = 1; it<= list.size(); it++){

				def columnXpath = "//tr[@class='ng-scope'][$value]//td[$it]"
				TestObject currentColumn = new TestObject()
				currentColumn.addProperty("xpath", ConditionType.EQUALS, columnXpath)
				WebUI.verifyElementPresent(currentColumn, 0)
				def colValue = WebUI.getText(currentColumn)

				KeywordUtil.logInfo("current row $value, current column $it value : $colValue")
				KeywordUtil.logInfo("adding $colValue to current list")

				currentList.add(colValue)
			}

			listOfLists.add(currentList)

		}

		for(int c = 0; c< rowCompared.size(); c++){
			ArrayList<String> compareCurrentList = listOfLists[c]
			def currentlist = rowCompared.get(c)
			for(int ci = c+1; ci< rowCompared.size(); ci++){

				def currentcomparedList = rowCompared.get(ci)
				if(c == ci){
					continue
				}else{
					ArrayList<String> comparedList = listOfLists[c]

					assert comparedList == compareCurrentList : "row $currentlist not equals to row $currentcomparedList"

					KeywordUtil.logInfo("row $currentlist equals to row $currentcomparedList")
				}

			}
		}


	}

	@Keyword
	def clickNameHyperLinkBasedOnColumnIndex(List<String> data, String colIndex){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + ']//td['+colIndex+']//a'
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)


		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickNameHyperLinkBasedOnRowIndex(List<String> data, String rowIndex){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***


		String temp = ""
		String xpath = "//div[@class='tr clearfix ng-scope' or @class='tr clearfix vs-repeat-repeated-element ng-scope']["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "][$rowIndex]//div[contains(@class, 'td td')]//div[@class='btn-link']//span[@aria-hidden='false']"
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)


		if(WebUI.scrollToElement(objectSpecifiList, 10, FailureHandling.OPTIONAL) == false){
			WebUI.scrollToElement(objectSpecifiList, 10, FailureHandling.OPTIONAL)
		}

		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def selectonSearchFilter(String textValue){

		String xpath = "//span[contains(@class, 'SearchSelectFilter') and text()='$textValue']"

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		WebUI.click(objectSpecifiList)
		//double click corporate label text to close dropdown list
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject corporateLabelObject = new TestObject()
		def corporateLabel = corporateLabelObject.addProperty("xpath", ConditionType.EQUALS, "//input[@id = 't-sidebar-search-menu']")
		WebUI.click(corporateLabelObject)

	}

	@Keyword
	def selectItemonDropdown(String indicatorId, String textValue){

		String xpath = '//li[not(@id)and text()="'+textValue+'"]'
		String xpath2 = '//li[not(@id)]//span[text()="'+textValue+'"]'
		if(!indicatorId.equals("NULL")){
			xpath = '//li[contains(@id, "'+indicatorId+'") and text()="'+textValue+'"]'
			xpath2 = '//li[contains(@id, "'+indicatorId+'")]//span[text()="'+textValue+'"]'
		}

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject testObject2 = new TestObject()
		def objectSpecifiList2 = testObject2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		boolean selectResult = WebUI.click(objectSpecifiList, FailureHandling.OPTIONAL)
		if(selectResult.equals(false)){
			KeywordUtil.logInfo("click failed, attempt another click")
			WebUI.click(objectSpecifiList2, FailureHandling.OPTIONAL)
		}
	}

	@Keyword
	def checkRadioButtonwithInput(String textValue){



		String xpath = "//span[text()='$textValue']/preceding::span[not(contains(@class,'checked'))]/input[@type='radio']"



		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)



		String xpathCheckStatus = "//span[text()='$textValue']/preceding::span[contains(@class,'checked')]/input[@type='radio']"

		TestObject testObjectStatus = new TestObject()
		def objectSpecifiListStatus = testObjectStatus.addProperty("xpath", ConditionType.EQUALS, xpathCheckStatus)

		def status = WebUI.verifyElementChecked(objectSpecifiListStatus, 0, FailureHandling.OPTIONAL)

		if(status.equals(false)){
			WebUI.verifyElementPresent(objectSpecifiList, 0)

			WebUI.check(objectSpecifiList)

			WebUI.verifyElementChecked(objectSpecifiListStatus, 0)
		}




	}



	@Keyword
	def uncheckRadioButtonwithInput(String textValue){



		String xpath = "//span[text()='$textValue']/preceding::span[not(contains(@class,'checked'))]/input[@type='radio']"



		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)



		String xpathCheckStatus = "//span[text()='$textValue']/preceding::span[contains(@class,'checked')]/input[@type='radio']"

		TestObject testObjectStatus = new TestObject()
		def objectSpecifiListStatus = testObjectStatus.addProperty("xpath", ConditionType.EQUALS, xpathCheckStatus)

		def status = WebUI.verifyElementNotChecked(objectSpecifiListStatus, 0, FailureHandling.OPTIONAL)

		if(status.equals(false)){
			WebUI.verifyElementPresent(objectSpecifiList, 0)

			WebUI.uncheck(objectSpecifiList)

			WebUI.verifyElementChecked(objectSpecifiListStatus, 0)
		}



	}


	@Keyword
	def AccountGroupAddandVerify(String account, List<String> products){

		String selectAccountList = '//div[@role="separator" and contains(.,//span[text()="Account List"])]/following-sibling::div[@class="ant-spin-nested-loading"]//div[@class="ant-table-container"][1]//tr[contains(.,"'+account+'")]//input[@type="checkbox" and not(@disabled)]'

		TestObject accountSelected = new TestObject()
		accountSelected.addProperty("xpath", ConditionType.EQUALS, selectAccountList)

		WebUI.verifyElementPresent(accountSelected, 0)

		def checkAccountSelectedStatus = WebUI.verifyElementChecked(accountSelected, 0, FailureHandling.OPTIONAL)
		if(checkAccountSelectedStatus.equals(false)){
			WebUI.check(accountSelected)
			WebUI.verifyElementChecked(accountSelected, 0, FailureHandling.STOP_ON_FAILURE)
			WebUI.comment("account $account available and successfully checked")
		}else{
			WebUI.comment("account $account already been checked")
		}

		String accountSelectedDetailNo = '//div[@role="separator" and contains(.,//span[text()="Account List"])]/following-sibling::div[@class="ant-spin-nested-loading"]//div[@class="ant-table-container"][1]//tr[contains(.,"'+account+'")]//td[contains(.,"'+account+'")]//span'

		TestObject accountSelectedDetail = new TestObject()
		accountSelectedDetail.addProperty("xpath", ConditionType.EQUALS, accountSelectedDetailNo)

		String completeAccount= WebUI.getText(accountSelectedDetail)
		WebUI.comment("account complete data : $completeAccount")

		String selectedRowDebitAllow = '//div[@role="separator" and contains(.,//span[text()="Account List"])]/following-sibling::div[@class="ant-spin-nested-loading"]//div[@class="ant-table-container"][1]//tr[contains(.,"'+completeAccount+'")]//td[3]//input'

		String selectedRowCreditAllow = '//div[@role="separator" and contains(.,//span[text()="Account List"])]/following-sibling::div[@class="ant-spin-nested-loading"]//div[@class="ant-table-container"][1]//tr[contains(.,"'+completeAccount+'")]//td[4]//input'

		String selectedRowInquiryAllow = '//div[@role="separator" and contains(.,//span[text()="Account List"])]/following-sibling::div[@class="ant-spin-nested-loading"]//div[@class="ant-table-container"][1]//tr[contains(.,"'+completeAccount+'")]//td[5]//input'

		TestObject rowSelectedDebit = new TestObject()
		rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

		Boolean debitVal

		def checkDebitSelectedStatus = WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.OPTIONAL)
		if(checkDebitSelectedStatus.equals(true)){
			debitVal = true
			WebUI.comment("account $completeAccount allow debit")
		}else{
			debitVal = false
			WebUI.comment("account $completeAccount not allow debit")
		}

		TestObject rowSelectedCredit = new TestObject()
		rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

		Boolean creditVal

		def checkCreditSelectedStatus = WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.OPTIONAL)
		if(checkCreditSelectedStatus.equals(true)){
			creditVal = true
			WebUI.comment("account $completeAccount allow credit")
		}else{
			creditVal = false
			WebUI.comment("account $completeAccount not allow credit")
		}

		TestObject rowSelectedInquiry = new TestObject()
		rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

		Boolean inquiryVal
		def checkInquirySelectedStatus = WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.OPTIONAL)

		if(checkInquirySelectedStatus.equals(true)){
			inquiryVal = true
			WebUI.comment("account $completeAccount allow inqury")
		}else{
			inquiryVal = false
			WebUI.comment("account $completeAccount not allow inquiry")
		}

		WebDriver driver = DriverFactory.getWebDriver()

		for(int i = 0; i< products.size(); i++){
			String product = products[i]

			String selectProduct = '//div[@role="separator" and contains(.,//span[text()="Product List"])]/following-sibling::div//tr[contains(.,"'+product+'")]//input[@type="checkbox" and not(@disabled)]'
			TestObject productSelected = new TestObject()
			productSelected.addProperty("xpath", ConditionType.EQUALS, selectProduct)

			WebUI.verifyElementPresent(productSelected, 0)
			WebUI.delay(2)

			def checkProductSelectedStatus = WebUI.verifyElementChecked(productSelected, 0, FailureHandling.OPTIONAL)
			if(checkProductSelectedStatus.equals(false)){
				WebUI.check(productSelected)
				WebUI.verifyElementChecked(accountSelected, 0, FailureHandling.STOP_ON_FAILURE)
				WebUI.comment("product $product available and successfully checked")
			}else{
				WebUI.comment("product $product already been checked")
			}

			String addtoList = "//button[@id='t-add-to-list']"
			TestObject buttonAddtoList = new TestObject()
			buttonAddtoList.addProperty("xpath", ConditionType.EQUALS, addtoList)

			WebUI.verifyElementVisible(buttonAddtoList)
			WebUI.scrollToElement(buttonAddtoList,0)
			WebUI.delay(2)
			WebElement element = WebUiCommonHelper.findWebElement(buttonAddtoList, 0)
			JavascriptExecutor executor = ((driver) as JavascriptExecutor)
			executor.executeScript("var evt = document.createEvent('MouseEvents');"+"evt.initMouseEvent('click',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);"+"arguments[0].dispatchEvent(evt);", element)

			//verify at list
			String verifyListRow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'"]//td//span[text()="'+completeAccount+'"]'

			TestObject verifyRow = new TestObject()
			verifyRow.addProperty("xpath", ConditionType.EQUALS, verifyListRow)

			WebUI.verifyElementVisible(verifyRow)
			WebUI.comment("account $completeAccount and $product shown on list")
			String verifyRowDebitAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(., "'+completeAccount+'")]//input[contains(@id, "debit") and @type="checkbox"]'

			String verifyRowCreditAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(., "'+completeAccount+'")]//input[contains(@id, "credit") and @type="checkbox"]'

			String verifyRowInquiryAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(., "'+completeAccount+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

			TestObject verifySelectedDebit = new TestObject()
			verifySelectedDebit.addProperty("xpath", ConditionType.EQUALS, verifyRowDebitAllow)

			def checkDebitVerifyStatus = WebUI.verifyElementChecked(verifySelectedDebit, 0, FailureHandling.OPTIONAL)
			if(checkDebitVerifyStatus.equals(true) && debitVal.equals(true)){
				WebUI.comment("account $completeAccount allow debit already checked")
			}else if(checkDebitVerifyStatus.equals(false) && debitVal.equals(false)){
				WebUI.comment("account $completeAccount allow debit already unchecked")
			}else if(checkDebitVerifyStatus.equals(true) && debitVal.equals(false)){
				WebUI.comment("account $completeAccount allow debit not matched")
				WebUI.verifyElementNotChecked(verifySelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
			}else if(checkDebitVerifyStatus.equals(false) && debitVal.equals(true)){
				WebUI.comment("account $completeAccount allow debit not matched")
				WebUI.verifyElementChecked(verifySelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
			}

			TestObject verifySelectedCredit = new TestObject()
			verifySelectedCredit.addProperty("xpath", ConditionType.EQUALS, verifyRowCreditAllow)

			def checkCreditVerifyStatus = WebUI.verifyElementChecked(verifySelectedCredit, 0, FailureHandling.OPTIONAL)
			if(checkCreditVerifyStatus.equals(true) && creditVal.equals(true)){
				WebUI.comment("account $completeAccount allow credit already checked")
			}else if(checkCreditVerifyStatus.equals(false) && creditVal.equals(false)){
				WebUI.comment("account $completeAccount allow credit already unchecked")
			}else if(checkCreditVerifyStatus.equals(true) && creditVal.equals(false)){
				WebUI.comment("account $completeAccount allow credit not matched")
				WebUI.verifyElementNotChecked(verifySelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
			}else if(checkCreditVerifyStatus.equals(false) && creditVal.equals(true)){
				WebUI.comment("account $completeAccount allow credit not matched")
				WebUI.verifyElementChecked(verifySelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
			}

			TestObject verifySelectedInquiry = new TestObject()
			verifySelectedInquiry.addProperty("xpath", ConditionType.EQUALS, verifyRowInquiryAllow)

			def checkInquiryVerifyStatus = WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.OPTIONAL)
			if(checkInquiryVerifyStatus.equals(true) && inquiryVal.equals(true)){
				WebUI.comment("account $completeAccount allow inquiry already checked")
			}else if(checkInquiryVerifyStatus.equals(false) && inquiryVal.equals(false)){
				WebUI.comment("account $completeAccount allow inquiry already unchecked")
			}else if(checkInquiryVerifyStatus.equals(true) && inquiryVal.equals(false)){
				WebUI.comment("account $completeAccount allow inquiry not matched")
				WebUI.verifyElementNotChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
			}else if(checkInquiryVerifyStatus.equals(false) && inquiryVal.equals(true)){
				WebUI.comment("account $completeAccount allow inquiry not matched")
				WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
			}
			WebUI.scrollToElement(accountSelectedDetail,0)
			WebUI.delay(2)
			def checkProductNotSelectedStatus = WebUI.verifyElementNotChecked(productSelected, 0, FailureHandling.OPTIONAL)
			if(checkProductNotSelectedStatus.equals(false)){
				WebUI.uncheck(productSelected)
				WebUI.delay(1)
			}
		}

		String headerAccList = '//div[@role="separator" and contains(.,//span[text()="Account List"])]'

		TestObject acclistHeader = new TestObject()
		acclistHeader.addProperty("xpath", ConditionType.EQUALS, headerAccList)

		WebUI.scrollToElement(acclistHeader,0)

		def checkAccountNotSelectedStatus = WebUI.verifyElementChecked(accountSelected, 0, FailureHandling.OPTIONAL)
		if(checkAccountNotSelectedStatus.equals(true)){
			WebUI.uncheck(accountSelected)
		}

		HashMap<String, List<String>> resultMap =  new HashMap<String, String>();

		resultMap.put(completeAccount, products)

		return resultMap
	}

	@Keyword
	def AccountGroupEditAccountAllow(String account, List<String> products, String debitAllow, String creditAllow, String inquiryAllow){


		WebUI.comment("account complete data : $account")

		for(int i = 0; i< products.size(); i++){
			String product = products[i]

			String selectedRow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'"]//td//span[contains(.,"'+account+'")]'

			String selectedRowDebitAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(.,"'+account+'")]//input[contains(@id, "debit") and @type="checkbox"]'

			String selectedRowCreditAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(.,"'+account+'")]//input[contains(@id, "credit") and @type="checkbox"]'

			String selectedRowInquiryAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(.,"'+account+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

			TestObject rowSelected = new TestObject()
			rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

			WebUI.verifyElementPresent(rowSelected, 0)

			TestObject rowSelectedDebit = new TestObject()
			rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

			def checkDebitSelectedStatus = WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.OPTIONAL)
			if(checkDebitSelectedStatus.equals(true) && debitAllow.equalsIgnoreCase("no debit")){
				WebUI.uncheck(rowSelectedDebit)
				WebUI.comment("account $account allow debit already unchecked")
			}else if(checkDebitSelectedStatus.equals(false) && debitAllow.equalsIgnoreCase("debit")){
				WebUI.check(rowSelectedDebit)
				WebUI.comment("account $account allow debit already checked")
			}else if(debitAllow.equals('')){
				WebUI.comment("skipped editing $account allow debit")
			}else{
				WebUI.comment("account $account allow debit already match $debitAllow")
			}

			TestObject rowSelectedCredit = new TestObject()
			rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

			def checkCreditSelectedStatus = WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.OPTIONAL)
			if(checkCreditSelectedStatus.equals(true) && creditAllow.equalsIgnoreCase("no credit")){
				WebUI.uncheck(rowSelectedCredit)
				WebUI.comment("account $account allow credit already unchecked")
			}else if(checkCreditSelectedStatus.equals(false) && creditAllow.equalsIgnoreCase("credit")){
				WebUI.check(rowSelectedCredit)
				WebUI.comment("account $account allow credit already checked")
			}else if(creditAllow.equals('')){
				WebUI.comment("skipped editing $account allow credit")
			}else{
				WebUI.comment("account $account allow credit already match $creditAllow")
			}

			TestObject rowSelectedInquiry = new TestObject()
			rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

			def checkInquirySelectedStatus = WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.OPTIONAL)
			if(rowSelectedInquiry.equals(true) && inquiryAllow.equalsIgnoreCase("no inquiry")){
				WebUI.uncheck(rowSelectedInquiry)
				WebUI.comment("account $account allow inquiry already unchecked")
			}else if(rowSelectedInquiry.equals(false) && inquiryAllow.equalsIgnoreCase("inquiry")){
				WebUI.check(rowSelectedInquiry)
				WebUI.comment("account $account allow inquiry already checked")
			}else if(inquiryAllow.equals('')){
				WebUI.comment("skipped editing $account allow inqury")
			}else{
				WebUI.comment("account $account allow inquiry already match $inquiryAllow")
			}
		}

	}

	@Keyword
	def AccountGroupEditAccountAllow(String account, List<String> products,String inquiryAllow){


		WebUI.comment("account complete data : $account")

		for(int i = 0; i< products.size(); i++){
			String product = products[i]

			String selectedRow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'"]//td//span[contains(.,"'+account+'")]'

			String selectedRowInquiryAllow = '//thead[contains(.,//th[text()="'+product+'"])]/following-sibling::tbody/tr[@data-row-key="'+account+'" and contains(.,"'+account+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

			TestObject rowSelected = new TestObject()
			rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

			WebUI.verifyElementPresent(rowSelected, 0)

			TestObject rowSelectedInquiry = new TestObject()
			rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

			def checkInquirySelectedStatus = WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.OPTIONAL)
			if(rowSelectedInquiry.equals(true) && inquiryAllow.equalsIgnoreCase("no inquiry")){
				WebUI.uncheck(rowSelectedInquiry)
				WebUI.comment("account $account allow inquiry already unchecked")
			}else if(rowSelectedInquiry.equals(false) && inquiryAllow.equalsIgnoreCase("inquiry")){
				WebUI.check(rowSelectedInquiry)
				WebUI.comment("account $account allow inquiry already checked")
			}else{
				WebUI.comment("account $account allow inquiry already match $inquiryAllow")
			}
		}

	}

	@Keyword
	def AccountGroupGetAccountProductList(){

		WebDriver driver = DriverFactory.getWebDriver()

		WebElement temp = driver.findElement(By.xpath('//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]'))
		List products = temp.findElements(By.xpath('//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]'))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of products: "+products.size())
		WebUI.switchToDefaultContent()

		HashMap<String, List<HashMap<String, List<String>>>> ProductAccountAllow = new HashMap<String, List<HashMap<String, List<String>>>>();

		for(int p = 1; p<= products.size(); p++){
			//identify products total and add it to productName list

			String currentProductTablePath ='//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]['+p+']//thead//th[2]'

			TestObject currentProduct = new TestObject()
			currentProduct.addProperty("xpath", ConditionType.EQUALS, currentProductTablePath)
			String currentProductName = WebUI.getText(currentProduct)
			currentProductName = currentProductName.trim()

			//identify accounts total and adding account to accountName list

			WebElement tempaccount = driver.findElement(By.xpath('//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]['+p+']//tr[@data-row-key]'))
			List accounts = tempaccount.findElements(By.xpath('//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]['+p+']//tr[@data-row-key]'))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of accounts in products $currentProductName: "+accounts.size())
			WebUI.switchToDefaultContent()

			List<HashMap<String, List<String>>> listAccountAllow = new ArrayList();

			for(int a = 1; a <= accounts.size(); a++){
				String currentAccountTablePath ='//div[@role="separator" and contains(.,//span[text()="Product - Account List"])]/following-sibling::div[@class="ant-table-wrapper"]['+p+']//tr[@data-row-key]['+a+']//td[2]//span'

				TestObject currentAccount = new TestObject()
				currentAccount.addProperty("xpath", ConditionType.EQUALS, currentAccountTablePath)
				String currentAccountName = WebUI.getText(currentAccount)
				String selectedRow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr//td//span[text()="'+currentAccountName+'"]'

				String selectedRowDebitAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "debit") and @type="checkbox"]'

				String selectedRowCreditAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "credit") and @type="checkbox"]'

				String selectedRowInquiryAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

				TestObject rowSelected = new TestObject()
				rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

				HashMap<String, List<String>> AccountAllow = new HashMap<String, List<String>>();

				List<String> currentAllowStatus = new ArrayList();

				WebUI.verifyElementPresent(rowSelected, 0)

				TestObject rowSelectedDebit = new TestObject()
				rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

				TestObject rowSelectedCredit = new TestObject()
				rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

				TestObject rowSelectedInquiry = new TestObject()
				rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

				if(currentProductName.equalsIgnoreCase("inquiry")){

					def checkInquirySelectedStatus = WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.OPTIONAL)
					if(checkInquirySelectedStatus.equals(true)){
						currentAllowStatus.add("inquiry")
						WebUI.comment("account $currentAccountName allow inquiry")
					}else if(checkInquirySelectedStatus.equals(false)){
						currentAllowStatus.add("no inquiry")
						WebUI.comment("account $currentAccountName don't allow inquiry")
					}

					if (WebUI.verifyElementHasAttribute(rowSelectedDebit, "disabled", 0, FailureHandling.OPTIONAL)) {
						KeywordUtil.logInfo("debit checkbox disabled")
					}else{
						KeywordUtil.markFailedAndStop("debit checkbox is not disabled")
					}

					if (WebUI.verifyElementHasAttribute(rowSelectedCredit, "disabled", 0, FailureHandling.OPTIONAL)) {
						KeywordUtil.logInfo("credit checkbox disabled")
					}else{
						KeywordUtil.markFailedAndStop("credit checkbox is not disabled")
					}

				}else{

					def checkDebitSelectedStatus = WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.OPTIONAL)
					if(checkDebitSelectedStatus.equals(true)){
						currentAllowStatus.add("debit")
						WebUI.comment("account $currentAccountName allow debit")
					}else if(checkDebitSelectedStatus.equals(false)){
						currentAllowStatus.add("no debit")
						WebUI.comment("account $currentAccountName don't allow debit")
					}

					def checkCreditSelectedStatus = WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.OPTIONAL)
					if(checkCreditSelectedStatus.equals(true)){
						currentAllowStatus.add("credit")
						WebUI.comment("account $currentAccountName allow credit")
					}else if(checkCreditSelectedStatus.equals(false)){
						currentAllowStatus.add("no credit")
						WebUI.comment("account $currentAccountName don't allow credit")
					}

					if (WebUI.verifyElementHasAttribute(rowSelectedInquiry, "disabled", 0, FailureHandling.OPTIONAL)) {
						KeywordUtil.logInfo("inquiry checkbox disabled")
					}else{
						KeywordUtil.markFailedAndStop("inquiry checkbox is not disabled")
					}

				}

				AccountAllow.put(currentAccountName, currentAllowStatus)
				listAccountAllow.add(AccountAllow)

			}
			ProductAccountAllow.put(currentProductName, listAccountAllow)
			//int all = ProductAccountAllow.size()
			WebUI.comment("$ProductAccountAllow")
		}

		return ProductAccountAllow
	}


	@Keyword
	def AccountGroupVerifyDataAccountProductList(HashMap<String, List<HashMap<String, List<String>>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()

		boolean status = true;

		HashMap<String, List<HashMap<String, List<String>>>> ProductAccountAllow = parsedMap;

		try{
			for(int p = 0; p< ProductAccountAllow.size(); p++){
				//identify products total and add it to productName list

				String currentProductName = ProductAccountAllow.keySet().toArray()[p-1]
				currentProductName = currentProductName.trim()
				WebUI.comment("current productt: $currentProductName")
				int pTotal = ProductAccountAllow.size()
				WebUI.comment("current product size: $pTotal")
				List<HashMap<String, List<String>>> listAccountAllow = ProductAccountAllow.get(currentProductName)
				int aTotal = listAccountAllow.size()
				WebUI.comment("current product size: $aTotal")
				for(int a = 0; a < listAccountAllow.size(); a++){

					HashMap<String, List<String>> currentList = listAccountAllow.get(a)

					String currentAccountName = currentList.keySet().toArray()[0]

					String selectedRow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr//td//span[text()="'+currentAccountName+'"]'

					String selectedRowDebitAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "debit") and @type="checkbox"]'

					String selectedRowCreditAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "credit") and @type="checkbox"]'

					String selectedRowInquiryAllow = '//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

					TestObject rowSelected = new TestObject()
					rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

					List<String> currentAllowStatus = currentList.get(currentAccountName)

					WebUI.verifyElementPresent(rowSelected, 0)

					TestObject rowSelectedDebit = new TestObject()
					rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

					if(currentAllowStatus[0].equals("debit")){
						WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow debit, match with previous page")
					}else if(currentAllowStatus[0].equals("no debit")){
						WebUI.verifyElementNotChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow debit, match with previous page")
					}

					TestObject rowSelectedCredit = new TestObject()
					rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

					if(currentAllowStatus[1].equals("credit")){
						WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow credit, match with previous page")
					}else if(currentAllowStatus[1].equals("no credit")){
						WebUI.verifyElementNotChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow credit, match with previous page")
					}

					TestObject rowSelectedInquiry = new TestObject()
					rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

					if(currentAllowStatus[2].equals("inquiry")){
						WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow inquiry, match with previous page")
					}else if(currentAllowStatus[2].equals("no inquiry")){
						WebUI.verifyElementNotChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow inquiry, match with previous page")
					}
					WebUI.comment("current productt: $currentProductName have account: $currentAccountName data match with previous page")
				}

			}
		}catch(Exception e){
			status = false
		}

		if(status.equals(false)){
			KeywordUtil.markFailed("screen values doesn't match")
		}

	}

	@Keyword
	def AccountGroupVerifyNewValueAccountProductList(HashMap<String, List<HashMap<String, List<String>>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()
		boolean status = true;
		HashMap<String, List<HashMap<String, List<String>>>> ProductAccountAllow = parsedMap;

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, '//div[contains(@id,"t-Workflow") and @class=""]')
		String xpathParent

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpathParent = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-new"]'
		}else if(checkWorkflowPage.equals(false)){
			xpathParent = '//*[@id="t-WorkflowSectionTag-new"]'


		}
		try{
			for(int p = 0; p< ProductAccountAllow.size(); p++){
				//identify products total and add it to productName list

				String currentProductName = ProductAccountAllow.keySet().toArray()[p]
				currentProductName = currentProductName.trim()
				WebUI.comment("current productt: $currentProductName")

				List<HashMap<String, List<String>>> listAccountAllow = ProductAccountAllow.get(currentProductName)
				WebUI.comment("$listAccountAllow")

				for(int a = 0; a < listAccountAllow.size(); a++){

					HashMap<String, List<String>> currentList = listAccountAllow.get(a)

					String currentAccountName = currentList.keySet().toArray()[0]

					String selectedRow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr//td//span[text()="'+currentAccountName+'"]'

					String selectedRowDebitAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "debit") and @type="checkbox"]'

					String selectedRowCreditAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "credit") and @type="checkbox"]'

					String selectedRowInquiryAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

					TestObject rowSelected = new TestObject()
					rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

					List<String> currentAllowStatus = currentList.get(currentAccountName)

					WebUI.verifyElementPresent(rowSelected, 0)

					TestObject rowSelectedDebit = new TestObject()
					rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

					if(currentAllowStatus[0].equals("debit")){
						WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow debit, match with previous page")
					}else if(currentAllowStatus[0].equals("no debit")){
						WebUI.verifyElementNotChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow debit, match with previous page")
					}

					TestObject rowSelectedCredit = new TestObject()
					rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

					if(currentAllowStatus[1].equals("credit")){
						WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow credit, match with previous page")
					}else if(currentAllowStatus[1].equals("no credit")){
						WebUI.verifyElementNotChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow credit, match with previous page")
					}

					TestObject rowSelectedInquiry = new TestObject()
					rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

					if(currentAllowStatus[2].equals("inquiry")){
						WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow inquiry, match with previous page")
					}else if(currentAllowStatus[2].equals("no inquiry")){
						WebUI.verifyElementNotChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow inquiry, match with previous page")
					}
					WebUI.comment("current productt: $currentProductName have account: $currentAccountName data match with previous page")
				}

			}
		}catch(Exception e){
			status = false
		}

		if(status.equals(false)){
			KeywordUtil.markFailed("screen values doesn't match")
		}

	}

	@Keyword
	def AccountGroupVerifyCurrentValueAccountProductList(HashMap<String, List<HashMap<String, List<String>>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()
		boolean status = true;
		HashMap<String, List<HashMap<String, List<String>>>> ProductAccountAllow = parsedMap;

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, '//div[contains(@id,"t-Workflow") and @class=""]')
		String xpathParent

		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			xpathParent = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-current"]'
		}else if(checkWorkflowPage.equals(false)){
			xpathParent = '//*[@id="t-WorkflowSectionTag-current"]'


		}

		try{

			for(int p = 0; p< ProductAccountAllow.size(); p++){
				//identify products total and add it to productName list

				String currentProductName = ProductAccountAllow.keySet().toArray()[p]
				currentProductName = currentProductName.trim()
				WebUI.comment("current productt: $currentProductName")

				List<HashMap<String, List<String>>> listAccountAllow = ProductAccountAllow.get(currentProductName)
				int all = listAccountAllow.size()
				WebUI.comment("$all")


				for(int a = 0; a < all; a++){

					HashMap<String, List<String>> currentList = listAccountAllow.get(a)
					WebUI.comment("$currentList")
					String currentAccountName = currentList.keySet().toArray()[0]

					String selectedRow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr//td//span[text()="'+currentAccountName+'"]'

					String selectedRowDebitAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "debit") and @type="checkbox"]'

					String selectedRowCreditAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "credit") and @type="checkbox"]'

					String selectedRowInquiryAllow = ''+xpathParent+'//thead[.//span[. ="'+currentProductName+'"]]/following-sibling::tbody/tr[contains(., "'+currentAccountName+'")]//input[contains(@id, "inquiry") and @type="checkbox"]'

					TestObject rowSelected = new TestObject()
					rowSelected.addProperty("xpath", ConditionType.EQUALS, selectedRow)

					List<String> currentAllowStatus = currentList.get(currentAccountName)

					WebUI.verifyElementPresent(rowSelected, 0)

					TestObject rowSelectedDebit = new TestObject()
					rowSelectedDebit.addProperty("xpath", ConditionType.EQUALS, selectedRowDebitAllow)

					if(currentAllowStatus[0].equals("debit")){
						WebUI.verifyElementChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow debit, match with previous page")
					}else if(currentAllowStatus[0].equals("no debit")){
						WebUI.verifyElementNotChecked(rowSelectedDebit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow debit, match with previous page")
					}

					TestObject rowSelectedCredit = new TestObject()
					rowSelectedCredit.addProperty("xpath", ConditionType.EQUALS, selectedRowCreditAllow)

					if(currentAllowStatus[1].equals("credit")){
						WebUI.verifyElementChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow credit, match with previous page")
					}else if(currentAllowStatus[1].equals("no credit")){
						WebUI.verifyElementNotChecked(rowSelectedCredit, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow credit, match with previous page")
					}

					TestObject rowSelectedInquiry = new TestObject()
					rowSelectedInquiry.addProperty("xpath", ConditionType.EQUALS, selectedRowInquiryAllow)

					if(currentAllowStatus[2].equals("inquiry")){
						WebUI.verifyElementChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName allow inquiry, match with previous page")
					}else if(currentAllowStatus[2].equals("no inquiry")){
						WebUI.verifyElementNotChecked(rowSelectedInquiry, 0, FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("account $currentAccountName don't allow inquiry, match with previous page")
					}
					WebUI.comment("current productt: $currentProductName have account: $currentAccountName data match with previous page")
				}

			}}catch(Exception e){
			status = false
		}

		if(status.equals(false)){
			KeywordUtil.markFailed("screen values doesn't match")
		}

	}

	@Keyword
	def verifyRowResultonDateRange(String dateColumn, String fromDate, String toDate){
		//getting pages total
		TestObject searchPagesTotal = new TestObject()
		searchPagesTotal.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		def textTotal = WebUI.getText(searchPagesTotal);

		textTotal = textTotal.replace("of", "").trim();

		//converting fromDate and toDate to date format
		//		def fromParts = fromDate.split("-")
		//
		//		def toParts = toDate.replace("-")
		//		fromDate = fromDate.replace(" ", "-")
		def dateFrom = new Date(fromDate)
		//		toDate = toDate.replace(" ", "-")
		def dateTo = new Date(toDate+1)

		int totalPages = Integer.parseInt(textTotal);

		TestObject nextPage = new TestObject()
		nextPage.addProperty("xpath", ConditionType.EQUALS, "//div[@id='t-SearchPagePagination-next']")

		for(int t = 0; t < totalPages;t++){
			WebDriver driver = DriverFactory.getWebDriver()

			Integer rowList;

			try {

				WebElement temp = driver.findElement(By.xpath("//tbody//tr[@data-row-key]"))
				List list = temp.findElements(By.xpath("//tbody//tr[@data-row-key]"))
				KeywordUtil.logInfo("success")
				KeywordUtil.logInfo("total number of list per page: "+list.size())
				WebUI.switchToDefaultContent()
				rowList = list.size()

			} catch (Exception e) {
				KeywordUtil.logInfo("total number of list per page: 0")
				return 0
			}

			SimpleDateFormat sdf= new SimpleDateFormat("dd MMM yyyy")

			for(int i = 1; i <= rowList; i++){
				TestObject currentRowDate = new TestObject()
				currentRowDate.addProperty("xpath", ConditionType.EQUALS, "//tbody//tr[@data-row-key][$i]//td[$dateColumn]")
				int rowcount = i
				String currentDate = WebUI.getText(currentRowDate);
				WebUI.comment("current row $rowcount date : $currentRowDate")
				println("currentDate : "+ currentDate)
				if (currentDate != null) {
					currentDate = currentDate.trim()
					def dateCurrent = sdf.parse(convertMonth(currentDate));
					//				currentDate = currentDate.replace("-", "/")
					// def dateCurrent= new Date(currentDate)

					if (dateCurrent.getTime() <= dateTo.getTime() && dateCurrent.getTime() >= dateFrom.getTime()){
						KeywordUtil.logInfo("current row $rowcount date : $currentDate is on range of $fromDate to $toDate")
					}else{
						KeywordUtil.markFailed("current row $rowcount date : $currentDate is not on range of $fromDate to $toDate")
					}
				}
			}

			if(t != totalPages-1){
				WebUI.verifyElementPresent(nextPage, 0, FailureHandling.OPTIONAL).equals(false)

				WebUI.click(nextPage)
				WebUI.delay(5)
			}

		}

	}

	@Keyword
	def verifyRowResultonDateRangeBO(String dateColumn, String fromDate, String toDate){
		//getting pages total
		TestObject searchPagesTotal = new TestObject()
		searchPagesTotal.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		def textTotal = WebUI.getText(searchPagesTotal);

		textTotal = textTotal.replace("of", "").trim();

		//converting fromDate and toDate to date format
		//		def fromParts = fromDate.split("-")
		//
		//		def toParts = toDate.replace("-")
		//		fromDate = fromDate.replace(" ", "-")
		def dateFrom = new Date(fromDate)
		//		toDate = toDate.replace(" ", "-")
		def dateTo = new Date(toDate+1)

		int totalPages = Integer.parseInt(textTotal);

		TestObject nextPage = new TestObject()
		nextPage.addProperty("xpath", ConditionType.EQUALS, "//div[@id='t-SearchPagePagination-next']")

		for(int t = 0; t < totalPages;t++){
			WebDriver driver = DriverFactory.getWebDriver()

			Integer rowList;

			try {

				WebElement temp = driver.findElement(By.xpath("//tbody//tr[@data-row-key]"))
				List list = temp.findElements(By.xpath("//tbody//tr[@data-row-key]"))
				KeywordUtil.logInfo("success")
				KeywordUtil.logInfo("total number of list per page: "+list.size())
				WebUI.switchToDefaultContent()
				rowList = list.size()

			} catch (Exception e) {
				KeywordUtil.logInfo("total number of list per page: 0")
				return 0
			}

			SimpleDateFormat sdf= new SimpleDateFormat("dd MM yyyy")

			for(int i = 1; i <= rowList; i++){
				TestObject currentRowDate = new TestObject()
				currentRowDate.addProperty("xpath", ConditionType.EQUALS, "//tbody//tr[@data-row-key][$i]//td[$dateColumn]")
				int rowcount = i
				String currentDate = WebUI.getText(currentRowDate);
				WebUI.comment("current row $rowcount date : $currentRowDate")
				println("currentDate : "+ currentDate)
				if (currentDate != null) {
					currentDate = currentDate.replace("-", " ").trim()
					def dateCurrent = sdf.parse(convertMonth(currentDate));
					//				currentDate = currentDate.replace("-", "/")
					// def dateCurrent= new Date(currentDate)

					if (dateCurrent.getTime() <= dateTo.getTime() && dateCurrent.getTime() >= dateFrom.getTime()){
						KeywordUtil.logInfo("current row $rowcount date : $currentDate is on range of $fromDate to $toDate")
					}else{
						KeywordUtil.markFailed("current row $rowcount date : $currentDate is not on range of $fromDate to $toDate")
					}
				}
			}

			if(t != totalPages-1){
				WebUI.verifyElementPresent(nextPage, 0, FailureHandling.OPTIONAL).equals(false)

				WebUI.click(nextPage)
				WebUI.delay(5)
			}

		}

	}


	@Keyword
	def verifyRowResultonDateRangeWeeklyMonthly(String dateColumn, String status){
		//getting pages total
		TestObject searchPagesTotal = new TestObject()
		searchPagesTotal.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		def textTotal = WebUI.getText(searchPagesTotal);

		textTotal = textTotal.replace("of", "").trim();

		//converting fromDate and toDate to date format
		//		def fromParts = fromDate.split("-")
		//
		//		def toParts = toDate.replace("-")
		def dateFrom = new Date()
		def dateTo = new Date()
		if(status.equalsIgnoreCase("last week")){
			dateFrom.setDate(dateFrom.getDate() - (dateFrom.getDay() + 6) % 7)//get this monday date
			dateFrom.setDate(dateFrom.getDate() - 7)//-7 day to find the previous week date
			dateTo.setDate(dateTo.getDate() - (dateTo.getDay()) % 7)//find sunday date of last week
		}else if(status.equalsIgnoreCase("next week")){
			dateFrom.setDate(dateFrom.getDate() - (dateFrom.getDay() + 6) % 7)//get this monday date
			dateFrom.setDate(dateFrom.getDate() + 7)//-7 day to find the next week date
			dateTo.setDate(dateTo.getDate() - (dateTo.getDay()) % 7)//find sunday date of next week
			dateTo.setDate(dateTo.getDate() + 14)//-7 day to find the next week date
		}else if(status.equalsIgnoreCase("last month")){
			dateFrom.setDate(1);
			dateFrom.setMonth(dateFrom.getMonth()-1);
			dateTo.setDate(1); // going to 1st of the month
			dateTo.setHours(-1); // going to last hour before this date even started.
		}else if(status.equalsIgnoreCase("next month")){
			dateFrom.setDate(1);
			dateFrom.setMonth(dateFrom.getMonth()+1);
			dateTo.setMonth(dateFrom.getMonth()+1); // going to last hour before this date even started.
			dateTo.setDate(0);
		}

		String fromDate = dateFrom.format("yyyy-MM-dd")
		String toDate = dateTo.format("yyyy-MM-dd")
		WebUI.comment("from : $fromDate, to: $toDate");
		int totalPages = Integer.parseInt(textTotal);

		TestObject nextPage = new TestObject()
		nextPage.addProperty("xpath", ConditionType.EQUALS, "//div[@id='t-SearchPagePagination-next']")

		for(int t = 0; t < totalPages;t++){
			WebDriver driver = DriverFactory.getWebDriver()

			Integer rowList;

			try {

				WebElement temp = driver.findElement(By.xpath("//tbody//tr[@data-row-key]"))
				List list = temp.findElements(By.xpath("//tbody//tr[@data-row-key]"))
				KeywordUtil.logInfo("success")
				KeywordUtil.logInfo("total number of list per page: "+list.size())
				WebUI.switchToDefaultContent()
				rowList = list.size()

			} catch (Exception e) {
				KeywordUtil.logInfo("total number of list per page: 0")
				return 0
			}
			SimpleDateFormat sdf= new SimpleDateFormat("dd MMM yyyy")

			for(int i = 1; i <= rowList; i++){
				TestObject currentRowDate = new TestObject()
				currentRowDate.addProperty("xpath", ConditionType.EQUALS, "//tbody//tr[@data-row-key][$i]//td[$dateColumn]")
				int rowcount = i
				String currentDate = WebUI.getText(currentRowDate);
				currentDate = currentDate.substring(0,currentDate.lastIndexOf("-")+3).trim()
				WebUI.comment("current row $rowcount date : $currentDate")
				currentDate = currentDate.replace("-", "/")
				//def dateCurrent= new Date(currentDate)
				println(currentDate)
				def dateCurrent = sdf.parse(convertMonth(currentDate))

				if (dateCurrent.getTime() <= dateTo.getTime() && dateCurrent.getTime() >= dateFrom.getTime()){
					KeywordUtil.logInfo("current row $rowcount date : $currentDate is on range of $fromDate to $toDate")
				}else{
					KeywordUtil.markFailed("current row $rowcount date : $currentRowDate is not on range of $fromDate to $toDate")

				}

			}

			if(t != totalPages-1){
				WebUI.verifyElementPresent(nextPage, 0, FailureHandling.OPTIONAL).equals(false)

				WebUI.click(nextPage)
				WebUI.delay(5)
			}

		}

	}


	@Keyword
	def userGroupAddtolist(List<String> featureList, List<String> productList = []){

		//check feature(s) based on featureList content
		for(int f=0; f<featureList.size(); f++){
			String currentFeature = featureList.get(f)
			TestObject featureSelected = new TestObject()
			featureSelected.addProperty("xpath", ConditionType.EQUALS, '//span[text()="'+currentFeature+'"]/preceding-sibling::span//input[@type="checkbox"]')

			WebUI.verifyElementPresent(featureSelected, 0)
			def checkFeatureSelectedStatus = WebUI.verifyElementChecked(featureSelected, 0, FailureHandling.OPTIONAL)
			if(checkFeatureSelectedStatus.equals(true)){
				WebUI.comment("$currentFeature already been checked")
			}else if(checkFeatureSelectedStatus.equals(false)){
				WebUI.check(featureSelected)
				WebUI.comment("finish checking $currentFeature")
			}

		}

		TestObject featureApply = new TestObject()
		featureApply.addProperty("xpath", ConditionType.EQUALS, "//button[@id = 't-apply-product-list']")
		//apply feature checked
		WebUI.verifyElementVisible(featureApply)
		WebUI.click(featureApply)

		//check product(s) based on productList content
		if(productList.size()>0){
			for(int p=0; p<productList.size(); p++){
				String currentProduct = productList.get(p)

				TestObject productSelected = new TestObject()
				productSelected.addProperty("xpath", ConditionType.EQUALS, '//span[text()="'+currentProduct+'"]/preceding-sibling::span//input[@type="checkbox"]')

				WebUI.verifyElementPresent(productSelected, 0)
				def checkProductSelectedStatus = WebUI.verifyElementChecked(productSelected, 0, FailureHandling.OPTIONAL)
				if(checkProductSelectedStatus.equals(true)){
					WebUI.comment("$currentProduct already been checked")
				}else if(checkProductSelectedStatus.equals(false)){
					WebUI.check(productSelected)
					WebUI.comment("finish checking $currentProduct")
				}

			}
		}


		TestObject productApply = new TestObject()
		productApply.addProperty("xpath", ConditionType.EQUALS, "//button[@id = 't-apply-limit-list']")
		//apply product checked
		WebUI.verifyElementVisible(productApply)
		WebUI.click(productApply)

		//		List<String> currencyMatrix = ["Local-Local", "Local-Forex", "Forex-Forex Cross", "Forex-Forex Same"]
		//		//verify limit table generated match with data previously added
		//		for(int cf=0; cf<productList.size(); cf++){
		//			String currentFeature = featureList.get(cf)
		//
		//			for(int cp=0; cp<productList.size(); cp++){
		//				String currentProduct = productList.get(cp)
		//				String currentLimitSelection = currentFeature + " - " + currentProduct
		//				WebUI.comment("checking $currentLimitSelection")
		//				for(int cl = 0; cl <currencyMatrix.size();cl++ ){
		//					String currentMatrix = currencyMatrix[cl];
		//					WebUI.comment("checking $currentLimitSelection, currency matrix $currentMatrix")
		//
		//					TestObject limitSelected = new TestObject()
		//					limitSelected.addProperty("xpath", ConditionType.EQUALS, "//label[text()='$currentLimitSelection']/following-sibling::div[@class='ant-table-wrapper']//tbody//tr[contains(.,'$currentMatrix')]//td[3]")
		//
		//					def presentStatus = WebUI.verifyElementVisible(limitSelected, FailureHandling.OPTIONAL)
		//
		//					if(presentStatus.equals(true)){
		//						WebUI.comment("$currentLimitSelection with currency matrix $currentMatrix present")
		//					}else if(presentStatus.equals(false)){
		//						WebUI.comment("$currentLimitSelection with currency matrix $currentMatrix not present")
		//					}
		//				}
		//
		//
		//			}
		//		}


	}

	@Keyword
	def getUserGrouplist(String page = 'input'){

		WebDriver driver = DriverFactory.getWebDriver()

		try {

			WebElement temp = driver.findElement(By.xpath("//div[@class='ant-table-wrapper']/preceding-sibling::label"))
			List listLimit = temp.findElements(By.xpath("//div[@class='ant-table-wrapper']/preceding-sibling::label"))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of limitlist per page: "+listLimit.size())
			HashMap<String, List<List<String>>> limitListMap = new HashMap<String, List<List<String>>>();
			if(page.equals('input')){
				for(int it = 1; it<= listLimit.size();it++){
					List<List<String>> currentLimitCollection = new ArrayList();
					TestObject limitSelected = new TestObject()
					limitSelected.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(., 'Limit List')]/following-sibling::div//div[contains(@class, 'ant-col-xxl-8')][$it]//label")

					def currentLimitSelected = WebUI.getText(limitSelected)
					KeywordUtil.logInfo(currentLimitSelected)
					currentLimitSelected = currentLimitSelected.trim()

					WebElement tempSelected = driver.findElement(By.xpath("//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr"))
					List listLimitSelectedRow = tempSelected.findElements(By.xpath("//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr"))

					for(int it2 = 1; it2<=listLimitSelectedRow.size(); it2++){
						List<String> currentRow = new ArrayList()
						TestObject currentMatrix = new TestObject()
						currentMatrix.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[1]")

						def selectedMatrix = WebUI.getText(currentMatrix)

						TestObject currentCurrency = new TestObject()
						currentCurrency.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[2]")

						def selectedCurrency = WebUI.getText(currentCurrency)

						TestObject currentLimitVal = new TestObject()
						currentLimitVal.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[3]//input")

						def selectedLimitVal = WebUI.getAttribute(currentLimitVal, "value")

						currentRow.add(selectedLimitVal)
						currentRow.add(selectedCurrency)
						currentRow.add(selectedMatrix)
						KeywordUtil.logInfo(currentLimitSelected + " current row value : $selectedMatrix, $selectedCurrency, $selectedLimitVal" )
						currentLimitCollection.add(currentRow)
					}
					limitListMap.put(currentLimitSelected, currentLimitCollection)
					KeywordUtil.logInfo("successfully added $currentLimitSelected to map" )
				}
			}else if(page.equalsIgnoreCase("review")){
				for(int it = 1; it<= listLimit.size();it++){
					List<List<String>> currentLimitCollection = new ArrayList();
					TestObject limitSelected = new TestObject()
					limitSelected.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(., 'Limit List')]/following-sibling::div//div[contains(@class, 'ant-col-xxl-8')][$it]//label")

					def currentLimitSelected = WebUI.getText(limitSelected)
					KeywordUtil.logInfo(currentLimitSelected)
					currentLimitSelected = currentLimitSelected.trim()

					WebElement tempSelected = driver.findElement(By.xpath("//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr"))
					List listLimitSelectedRow = tempSelected.findElements(By.xpath("//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr"))

					for(int it2 = 1; it2<=listLimitSelectedRow.size(); it2++){
						List<String> currentRow = new ArrayList()
						TestObject currentMatrix = new TestObject()
						currentMatrix.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[1]")

						def selectedMatrix = WebUI.getText(currentMatrix)

						TestObject currentCurrency = new TestObject()
						currentCurrency.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[2]")

						def selectedCurrency = WebUI.getText(currentCurrency)

						TestObject currentLimitVal = new TestObject()
						currentLimitVal.addProperty("xpath", ConditionType.EQUALS, "//div[@role='separator' and contains(.,//span[text()='Limit List'])]/following-sibling::div[@class='ant-row']//div[contains(@class, 'ant-col-xxl-8')][$it]//tbody//tr[$it2]//td[3]")

						def selectedLimitVal = WebUI.getText(currentLimitVal)

						currentRow.add(selectedLimitVal)
						currentRow.add(selectedCurrency)
						currentRow.add(selectedMatrix)
						KeywordUtil.logInfo(currentLimitSelected + " current row value : $selectedMatrix, $selectedCurrency, $selectedLimitVal" )
						currentLimitCollection.add(currentRow)
					}
					limitListMap.put(currentLimitSelected, currentLimitCollection)
					KeywordUtil.logInfo("successfully added $currentLimitSelected to map" )
				}
			}

			return limitListMap

		} catch (Exception e) {
			println e

		}

	}

	@Keyword
	def UserGroupVerifyDetailLimitList(HashMap<String, List<List<String>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)

				if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
				}
			}

		}

	}


	@Keyword
	def UserGroupVerifyDataLimitList(HashMap<String, List<List<String>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//div[contains(@id,"t-Workflow") and @class=""]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//div[contains(@id,"t-Workflow") and @class=""]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//div[contains(@id,"t-Workflow") and @class=""]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-md") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)

				if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal.replace(",", ""))){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
				}
			}

		}

	}

	@Keyword
	def UserGroupEditDataLimitList(String feature, String product, String currencyMatrix ,String limitValue){
		def currentLimitName = feature +" - "+ product

		String selectedRowLimitValue = '//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xxl-8") and contains(.,"'+currentLimitName+'")]//tbody//tr[contains(.,"'+currencyMatrix+'")]//td[3]//input'
		TestObject rowSelectedLimitValue = new TestObject()
		rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

		WebUI.verifyElementPresent(rowSelectedLimitValue, 0)

		WebUI.sendKeys(rowSelectedLimitValue, Keys.chord(Keys.CONTROL, 'a', Keys.BACK_SPACE))

		WebUI.setText(rowSelectedLimitValue, limitValue)

		WebUI.verifyElementAttributeValue(rowSelectedLimitValue, 'value', limitValue, 0)
	}

	@Keyword
	def UserGroupVerifyEditCurrentDataLimitList(HashMap<String, List<List<String>>> parsedMap, String curr = "N"){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)
				if(curr == "N") {
					// selectedLimitVal = selectedLimitVal
					if(WebUI.verifyEqual(currentRow.get(0), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				} else {
					selectedLimitVal = selectedLimitVal.replace(',', '')
					if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				}

			}

		}

	}

	@Keyword
	def UserGroupVerifyEditCurrentDataLimitList2(HashMap<String, List<List<String>>> parsedMap, String curr = "N"){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//*[@id="t-WorkflowSectionTag-current"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)
				if(curr == "N") {
					// selectedLimitVal = selectedLimitVal
					if(WebUI.verifyEqual(currentRow.get(0), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				} else {
					selectedLimitVal = selectedLimitVal.replace(',', '')
					if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				}

			}

		}

	}

	@Keyword
	def UserGroupVerifyEditUpdatedDataLimitList2(HashMap<String, List<List<String>>> parsedMap, String curr = "N"){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)
				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)
				if(curr == "N") {
					// selectedLimitVal = selectedLimitVal
					if(WebUI.verifyEqual(currentRow.get(0), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				} else {
					selectedLimitVal = selectedLimitVal.replace(',', '')
					if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal)){
						WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
					}
				}

				if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
				}
			}

		}

	}

	@Keyword
	def UserGroupVerifyEditUpdatedDataLimitList(HashMap<String, List<List<String>>> parsedMap){

		WebDriver driver = DriverFactory.getWebDriver()

		HashMap<String, List<List<String>>> LimitList = parsedMap;

		for(int p = 0; p< LimitList.size(); p++){
			//identify products total and add it to productName list

			String currentLimitName = LimitList.keySet().toArray()[p-1]
			currentLimitName = currentLimitName.trim()
			WebUI.comment("current limit: $currentLimitName")
			int pTotal = LimitList.size()
			WebUI.comment("current limitList size: $pTotal")
			List<List<String>> listLimitContent= LimitList.get(currentLimitName)
			int aTotal = listLimitContent.size()
			WebUI.comment("current limit table size: $aTotal")
			for(int a = 0; a < listLimitContent.size(); a++){

				List<String> currentRow = listLimitContent.get(a)
				WebUI.comment("$currentRow")

				int currentRowIndex = a+1

				String selectedRowCurrencyMatrix = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[1]'

				String selectedRowCurrency = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[2]'

				String selectedRowLimitValue = '//div[contains(@id,"t-Workflow") and @class=""]//*[@id="t-WorkflowSectionTag-new"]//following-sibling::div[contains(@class,"WorkflowSection-contentBox")]//div[@role="separator" and contains(.,//span[text()="Limit List"])]/following-sibling::div[@class="ant-row"]//div[contains(@class, "ant-col-xl-12") and contains(.,"'+currentLimitName+'")]//tbody//tr['+currentRowIndex+']//td[3]'

				WebUI.comment(" Verifying $currentLimitName $currentRowIndex row")

				TestObject rowSelectedCurrencyMatrix = new TestObject()
				rowSelectedCurrencyMatrix.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrencyMatrix)

				def selectedMatrix = WebUI.getText(rowSelectedCurrencyMatrix)

				if(WebUI.verifyEqual(currentRow.get(2), selectedMatrix)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedMatrix match with data inputted")
				}

				TestObject rowSelectedCurrency = new TestObject()
				rowSelectedCurrency.addProperty("xpath", ConditionType.EQUALS, selectedRowCurrency)

				def selectedCurrency = WebUI.getText(rowSelectedCurrency)

				if(WebUI.verifyEqual(currentRow.get(1), selectedCurrency)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedCurrency match with data inputted")
				}

				TestObject rowSelectedLimitValue = new TestObject()
				rowSelectedLimitValue.addProperty("xpath", ConditionType.EQUALS, selectedRowLimitValue)

				def selectedLimitVal = WebUI.getText(rowSelectedLimitValue)
				selectedLimitVal = selectedLimitVal.replace(',', '')

				if(WebUI.verifyEqual(currentRow.get(0).replace(",", ""), selectedLimitVal)){
					WebUI.comment("$currentLimitName $currentRowIndex row, currency matrix $selectedLimitVal match with data inputted")
				}
			}

		}

	}

	@Keyword
	def verifyRowResultonCurrencyRange(String currencyColumn, String minValue, String maxValue, String currency = ""){
		//getting pages total
		TestObject searchPagesTotal = new TestObject()
		searchPagesTotal.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'SearchPagination-navigator')]//span[contains(.,'of')]")
		def textTotal = WebUI.getText(searchPagesTotal);

		textTotal = textTotal.replace("of", "").trim();

		//converting fromDate and toDate to date format
		//		def fromParts = fromDate.split("-")
		//
		//		def toParts = toDate.replace("-")

		int totalPages = Integer.parseInt(textTotal);

		TestObject nextPage = new TestObject()
		nextPage.addProperty("xpath", ConditionType.EQUALS, "//div[@id='t-SearchPagePagination-next']")

		for(int t = 0; t < totalPages;t++){
			WebDriver driver = DriverFactory.getWebDriver()

			Integer rowList;

			try {

				WebElement temp = driver.findElement(By.xpath("//tbody//tr[@data-row-key]"))
				List list = temp.findElements(By.xpath("//tbody//tr[@data-row-key]"))
				KeywordUtil.logInfo("success")
				KeywordUtil.logInfo("total number of list per page: "+list.size())
				WebUI.switchToDefaultContent()
				rowList = list.size()

			} catch (Exception e) {
				KeywordUtil.logInfo("total number of list per page: 0")
				return 0
			}

			for(int i = 1; i <= rowList; i++){
				TestObject currentRow = new TestObject()
				currentRow.addProperty("xpath", ConditionType.EQUALS, "//tbody//tr[@data-row-key][$i]//td[$currencyColumn]")
				int rowcount = i
				String currentValue = WebUI.getText(currentRow);
				if(currentValue.contains(",") || currentValue.contains(".")){
					currentValue = currentValue.substring(0, currentValue.indexOf("."))
					currentValue = currentValue.replace(",", "").trim()
				}

				if(!currency.equals("")){
					currentValue = currentValue.replace(currency, "").trim()
				}
				WebUI.comment("current row $rowcount date : $currentValue")
				//format rangelimitResult into currency format
				BigDecimal checkValue = new BigDecimal(currentValue);
				checkValue = checkValue.setScale(2, RoundingMode.HALF_UP);
				BigDecimal checkValueMin = new BigDecimal(minValue);
				checkValueMin = checkValueMin.setScale(2, RoundingMode.HALF_UP);
				BigDecimal checkValueMax = new BigDecimal(maxValue);
				checkValueMax = checkValueMax.setScale(2, RoundingMode.HALF_UP);
				//				NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
				//				currentValue = currentValue.replace(currency, "").trim()


				if (checkValue <= checkValueMax && checkValue >= checkValueMin){
					KeywordUtil.logInfo("current row $rowcount date : $currentValue is on range of $minValue to $maxValue")
				}else{
					KeywordUtil.markFailed("current row $rowcount date : $currentValue is not on range of $minValue to $maxValue")
				}

			}

			if(t != totalPages-1){
				WebUI.verifyElementPresent(nextPage, 0, FailureHandling.OPTIONAL).equals(false)

				WebUI.click(nextPage)
				WebUI.delay(5)
			}

		}

	}


	@Keyword
	def getPendingTaskList(){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> limitListMap = new HashMap<String, List<String>>();
		def totalRowPerPage = getTotalRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@data-row-key][$k]//td"

			WebElement colTotal = driver.findElement(By.xpath(currentRow))
			List listOfcurrentColumn = colTotal.findElements(By.xpath(currentRow))
			List<String> valueOfCurrentRow = new ArrayList();
			for(int c = 2; c<= listOfcurrentColumn.size(); c++){
				String currentCol = currentRow + "[$c]"
				testObject.addProperty("xpath", ConditionType.EQUALS, currentCol)
				KeywordUtil.logInfo("get text of xpath: "+ currentCol)
				WebUI.scrollToElement(testObject, 0)
				def textResult = WebUI.getText(testObject)
				valueOfCurrentRow.add(textResult)
				WebUI.comment("row $k, column $c value = $textResult")

			}
			limitListMap.put(k.toString(), valueOfCurrentRow)
			WebUI.comment("$limitListMap")
			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

		return limitListMap

	}



	//belum selesai
	@Keyword
	def getTotalCheckedRowPerPage(){
		WebDriver driver = DriverFactory.getWebDriver()

		try {
			row ="//tbody//tr[@data-row-key and .//input[@checked]]"

			WebElement temp = driver.findElement(By.xpath(row))
			List list = temp.findElements(By.xpath(row))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of checked list per page: "+list.size())
			WebUI.switchToDefaultContent()
			return list.size()

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of checked list per page: 0")
			return 0
		}
	}


	//belum bisa dipake
	@Keyword
	def getCheckedPendingTaskList(){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> limitListMap = new HashMap<String, List<String>>();
		def totalRowPerPage = getTotalCheckedRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@data-row-key and .//input[@checked]][$k]//td"

			WebElement colTotal = driver.findElement(By.xpath(currentRow))
			List listOfcurrentColumn = colTotal.findElements(By.xpath(currentRow))
			List<String> valueOfCurrentRow = new ArrayList();
			for(int c = 2; c<= listOfcurrentColumn.size(); c++){
				String currentCol = currentRow + "[$c]"
				testObject.addProperty("xpath", ConditionType.EQUALS, currentCol)
				KeywordUtil.logInfo("get text of xpath: "+ currentCol)
				WebUI.scrollToElement(testObject, 0)
				def textResult = WebUI.getText(testObject)
				valueOfCurrentRow.add(textResult)
				WebUI.comment("row $k, column $c value = $textResult")

			}
			limitListMap.put(k.toString(), valueOfCurrentRow)
			WebUI.comment("$limitListMap")
			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

		return limitListMap

	}

	@Keyword
	def getCheckedTableList(){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> limitListMap = new HashMap<String, List<String>>();
		def totalRowPerPage = getTotalCheckedRowPerPage()
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@data-row-key and .//input[@checked]][$k]//td"

			WebElement colTotal = driver.findElement(By.xpath(currentRow))
			List listOfcurrentColumn = colTotal.findElements(By.xpath(currentRow))
			List<String> valueOfCurrentRow = new ArrayList();
			for(int c = 2; c<= listOfcurrentColumn.size(); c++){
				String currentCol = currentRow + "[$c]"
				testObject.addProperty("xpath", ConditionType.EQUALS, currentCol)
				KeywordUtil.logInfo("get text of xpath: "+ currentCol)
				WebUI.scrollToElement(testObject, 0)
				def textResult = WebUI.getText(testObject)
				valueOfCurrentRow.add(textResult)
				WebUI.comment("row $k, column $c value = $textResult")

			}
			limitListMap.put(k.toString(), valueOfCurrentRow)
			WebUI.comment("$limitListMap")
			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

		return limitListMap

	}

	@Keyword
	def verifyPendingTask(HashMap<String, List<String>> parsedData){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> verifylimitListMap = parsedData;
		for(int k = 1; k <= verifylimitListMap.size(); k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@data-row-key][$k]//td"

			WebElement colTotal = driver.findElement(By.xpath(currentRow))
			List listOfcurrentColumn = colTotal.findElements(By.xpath(currentRow))
			List<String> valueOfCurrentRow = verifylimitListMap.get(k.toString());
			for(int c = 1; c<=valueOfCurrentRow.size(); c++){
				String currentCol = currentRow + "[$c]"
				testObject.addProperty("xpath", ConditionType.EQUALS, currentCol)
				KeywordUtil.logInfo("get text of xpath: "+ currentCol)
				WebUI.scrollToElement(testObject, 0)
				def textResult = WebUI.getText(testObject)
				WebUI.comment("row $k, column $c value = $textResult")

				String currentValue = valueOfCurrentRow.get(c-1)
				WebUI.verifyEqual(textResult, currentValue)
			}

			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

	}

	@Keyword
	def verifyTableList(HashMap<String, List<String>> parsedData){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> verifylimitListMap = parsedData;
		for(int k = 1; k <= verifylimitListMap.size(); k++){
			KeywordUtil.logInfo(k.toString())
			def currentRow

			currentRow = "//tr[@data-row-key][$k]//td"

			WebElement colTotal = driver.findElement(By.xpath(currentRow))
			List listOfcurrentColumn = colTotal.findElements(By.xpath(currentRow))
			List<String> valueOfCurrentRow = verifylimitListMap.get(k.toString());
			for(int c = 1; c<=valueOfCurrentRow.size(); c++){
				String currentCol = currentRow + "[$c]"
				testObject.addProperty("xpath", ConditionType.EQUALS, currentCol)
				KeywordUtil.logInfo("get text of xpath: "+ currentCol)
				WebUI.scrollToElement(testObject, 0)
				def textResult = WebUI.getText(testObject)
				WebUI.comment("row $k, column $c value = $textResult")

				String currentValue = valueOfCurrentRow.get(c-1)
				WebUI.verifyEqual(textResult, currentValue)
			}

			KeywordUtil.logInfo("row: "+ k + " Passed")

		}

	}

	//belum berhasil
	@Keyword
	def getDataOnColumnSpecificValue(String filenamecolumn, List<String> data){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()

		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String column = "//td[$filenamecolumn]//div"
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")][1]'
			}
			xpath = xpath + temp
		}
		xpath = xpath + column

		String filename = "";



		def objectSpecificList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		//tbody//tr[contains(.,'Success')]//td[2]
		boolean present = WebUI.verifyElementPresent(objectSpecificList, 0, FailureHandling.OPTIONAL)
		if(present.equals(true)){
			filename = WebUI.getText(objectSpecificList, FailureHandling.OPTIONAL)
			KeywordUtil.logInfo(filename)
		}

		return filename

	}

	@Keyword
	def countRowContainingSpecificValue(String value){
		WebDriver driver = DriverFactory.getWebDriver()

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String row_xpath
		String row_xpath2
		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			row_xpath = "//div[contains(@id,'t-Workflow') and @class='']//tr[@data-row-key]"
			row_xpath2 = "//div[contains(@id,'t-Workflow') and @class='']//tr[@data-row-key"
		}else if(checkWorkflowPage.equals(false)){
			row_xpath = "//tr[@data-row-key]"
			row_xpath2 = "//tr[@data-row-key"
		}



		WebElement temp = driver.findElement(By.xpath(row_xpath))
		List list = temp.findElements(By.xpath(row_xpath))
		WebUI.switchToDefaultContent()
		TestObject testObject = new TestObject()
		String xpath
		int count = 0
		for(int k = 1; k <= list.size(); k++){

			xpath = row_xpath2 + " and contains(.,'$value')][$k]"
			def objectSpecificList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

			boolean present = WebUI.verifyElementPresent(objectSpecificList, 0, FailureHandling.OPTIONAL)
			if(present.equals(true)){
				count = count + 1
			}
		}
		KeywordUtil.logInfo("$count")
		String c = String.valueOf(count)
		return c
	}

	@Keyword
	def countRowNotContainingSpecificValue(String value){
		WebDriver driver = DriverFactory.getWebDriver()

		TestObject workflowPage = new TestObject()
		workflowPage.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@id,'t-Workflow') and @class='']")
		String row_xpath
		String row_xpath2
		def checkWorkflowPage = WebUI.verifyElementPresent(workflowPage, 0, FailureHandling.OPTIONAL)
		if(checkWorkflowPage.equals(true)){
			row_xpath = "//div[contains(@id,'t-Workflow') and @class='']//tr[@data-row-key]"
			row_xpath2 = "//div[contains(@id,'t-Workflow') and @class='']//tr[@data-row-key"
		}else if(checkWorkflowPage.equals(false)){
			row_xpath = "//tr[@data-row-key]"
			row_xpath2 = "//tr[@data-row-key"
		}



		WebElement temp = driver.findElement(By.xpath(row_xpath))
		List list = temp.findElements(By.xpath(row_xpath))
		WebUI.switchToDefaultContent()
		TestObject testObject = new TestObject()
		String xpath
		int count = 0
		for(int k = 1; k <= list.size(); k++){

			xpath = row_xpath2 + " and not(contains(.,'$value'))][$k]"
			def objectSpecificList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

			boolean present = WebUI.verifyElementPresent(objectSpecificList, 0, FailureHandling.OPTIONAL)
			if(present.equals(true)){
				count = count + 1
			}
		}
		KeywordUtil.logInfo("$count")
		String c = String.valueOf(count)
		return c
	}

	@Keyword
	def verifyListOnTableContainsSpecificObject(List<String> data, TestObject target){

		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)

		String targetIdentifier = null;

		String targetSelector = target.getSelectorMethod().getName();
		WebUI.comment(targetSelector)
		if(targetSelector.toLowerCase().contains("xpath")){
			targetIdentifier = target.getSelectorCollection()[SelectorMethod.XPATH];
		}else if(targetSelector.toLowerCase().contains("basic")){
			targetIdentifier = target.getSelectorCollection()[SelectorMethod.BASIC];
		}else if(targetSelector.toLowerCase().contains("css")){
			targetIdentifier = target.getSelectorCollection()[SelectorMethod.CSS];

		}


		WebUI.comment(targetIdentifier)
		WebUI.comment(xpath+targetIdentifier)
		TestObject targetObject = new TestObject()
		targetObject.addProperty("xpath", ConditionType.EQUALS, xpath + targetIdentifier)
		WebUI.verifyElementVisible(targetObject)
	}

	@Keyword
	def sumColumnValues(String index, String status = "checked", Boolean currencyFormat = true, int roundingValue = 2){
		WebDriver driver = DriverFactory.getWebDriver()
		TestObject testObject = new TestObject()
		HashMap<String, List<String>> limitListMap = new HashMap<String, List<String>>();

		def totalRowPerPage = getTotalRowPerPage()

		if(status == "checked"){
			totalRowPerPage = getTotalCheckedRowPerPage()
		}

		double sumValue = 0
		for(int k = 1; k <= totalRowPerPage; k++){
			KeywordUtil.logInfo(k.toString())

			String currentRow = "//tr[@data-row-key][$k]//td[$index]"

			if(status == "checked"){
				currentRow = "//tr[@data-row-key and .//input[@checked][$k]//td[$index]"
			}


			testObject.addProperty("xpath", ConditionType.EQUALS, currentRow)
			KeywordUtil.logInfo("get text of xpath: "+ currentRow)
			WebUI.scrollToElement(testObject, 0)
			def textResult = WebUI.getText(testObject)
			String currentInput = textResult.replace(',', '')

			double currentValue = Double.valueOf(currentInput)

			sumValue = sumValue + currentValue




		}
		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)

	}

	@Keyword
	def editContactonCorporateRegistration(String index, String extName, String Name, String PhoneNo, String MobilePhoneNo, String Email){
		String rowPath = "//tr[@record][$index]//td"

		String extNamePath = rowPath+"//div[contains(@id, 't-ext_name' )]"
		String extNameOptionPath = extNamePath + "//li[text()='$extName']"
		String namePath = rowPath+"//input[contains(@id, 't-name')]"
		String phoneNoPath = rowPath+"//input[contains(@id, 't-phone_no')]"
		String mobilePhoneNoPath = rowPath+"//input[contains(@id, 't-mobile_no')]"
		String emailPath = rowPath+"//input[contains(@id, 't-email')]"

		TestObject extNameObject = new TestObject()
		TestObject extNameOptionPathObject = new TestObject()
		TestObject namePathObject = new TestObject()
		TestObject phoneNoPathObject = new TestObject()
		TestObject mobilePhoneNoPathObject = new TestObject()
		TestObject emailPathObject = new TestObject()

		extNameObject.addProperty("xpath", ConditionType.EQUALS, extNamePath)
		extNameOptionPathObject.addProperty("xpath", ConditionType.EQUALS, extNameOptionPath)
		namePathObject.addProperty("xpath", ConditionType.EQUALS, namePath)
		phoneNoPathObject.addProperty("xpath", ConditionType.EQUALS, phoneNoPath)
		mobilePhoneNoPathObject.addProperty("xpath", ConditionType.EQUALS, mobilePhoneNoPath)
		emailPathObject.addProperty("xpath", ConditionType.EQUALS, emailPath)

		SendKeys newKeys = new SendKeys();

		WebUI.verifyElementPresent(extNameObject,0)
		WebUI.click(extNameObject)

		WebUI.verifyElementPresent(extNameOptionPathObject,0)
		WebUI.click(extNameOptionPathObject)

		if(!Name.equals("") && !Name.equals('')){

			WebUI.verifyElementPresent(namePathObject, 0)
			WebUI.click(namePathObject)
			newKeys.handleInput(namePathObject, "Keys.CONTROL, a")
			newKeys.handleInput(namePathObject, "Keys.BACKSPACE")
			WebUI.setText(namePathObject, Name)
		}

		WebUI.verifyElementPresent(phoneNoPathObject, 0)
		WebUI.click(phoneNoPathObject)
		newKeys.handleInput(phoneNoPathObject, "Keys.CONTROL, a")
		newKeys.handleInput(phoneNoPathObject, "Keys.BACKSPACE")
		WebUI.setText(phoneNoPathObject, PhoneNo)

		WebUI.verifyElementPresent(mobilePhoneNoPathObject, 0)
		WebUI.click(mobilePhoneNoPathObject)
		newKeys.handleInput(mobilePhoneNoPathObject, "Keys.CONTROL, a")
		newKeys.handleInput(mobilePhoneNoPathObject, "Keys.BACKSPACE")
		WebUI.setText(mobilePhoneNoPathObject, MobilePhoneNo)

		WebUI.verifyElementPresent(emailPathObject, 0)
		WebUI.click(emailPathObject)
		newKeys.handleInput(emailPathObject, "Keys.CONTROL, a")
		newKeys.handleInput(emailPathObject, "Keys.BACKSPACE")
		WebUI.setText(emailPathObject, Email)
	}

	@Keyword
	def editCorporateAdministrationOnCorporateRegistration(String index, String userID = "", String Name, String Role, String Email, String PhoneNo, String Token = ''){
		String rowPath = "//div[@role='tabpanel' and @aria-hidden='false']//tr[@data-row-key][$index]//td"
		String rowPath2 = "//tr[@data-row-key][$index]//td"

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, rowPath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, rowPath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				rowPath = rowPath2
			}
		}


		String extRolePath = rowPath+"//div[contains(@id,'t-select-role')]"
		String extRoleOptionPath = extRolePath + "//li[text()='$Role']"
		String namePath = rowPath+"//input[contains(@id,'t-user_name')]"
		String userIDPath = rowPath+"//input[contains(@id,'t-user_id')]"
		String emailPath = rowPath+"//input[contains(@id, 't-email')]"
		String phoneNoPath = rowPath+"//input[contains(@id, 't-phone_no')]"
		String extTokenPath = rowPath+"//div[contains(@id,'t-select-authentication')]"
		String extTokenOptionPath = extTokenPath + "//li[text()='$Token']"

		TestObject extRoleObject = new TestObject()
		TestObject extRoleOptionPathObject = new TestObject()
		TestObject extTokenObject = new TestObject()
		TestObject extTokenOptionPathObject = new TestObject()
		TestObject userIDPathObject = new TestObject()
		TestObject namePathObject = new TestObject()
		TestObject phoneNoPathObject = new TestObject()
		TestObject emailPathObject = new TestObject()

		userIDPathObject.addProperty("xpath", ConditionType.EQUALS, userIDPath)
		extRoleObject.addProperty("xpath", ConditionType.EQUALS, extRolePath)
		extRoleOptionPathObject.addProperty("xpath", ConditionType.EQUALS, extRoleOptionPath)
		extTokenObject.addProperty("xpath", ConditionType.EQUALS, extTokenPath)
		extTokenOptionPathObject.addProperty("xpath", ConditionType.EQUALS, extTokenOptionPath)
		namePathObject.addProperty("xpath", ConditionType.EQUALS, namePath)
		phoneNoPathObject.addProperty("xpath", ConditionType.EQUALS, phoneNoPath)
		emailPathObject.addProperty("xpath", ConditionType.EQUALS, emailPath)

		SendKeys newKeys = new SendKeys();
		if(userID != "" || userID != ''){
			WebUI.comment("üserID avail")
			WebUI.verifyElementPresent(userIDPathObject, 0)
			WebUI.click(userIDPathObject)
			newKeys.handleInput(userIDPathObject, "Keys.CONTROL, a")
			newKeys.handleInput(userIDPathObject, "Keys.BACKSPACE")
			WebUI.setText(userIDPathObject, userID)
		}
		WebUI.verifyElementPresent(namePathObject, 0)
		WebUI.click(namePathObject)
		newKeys.handleInput(namePathObject, "Keys.CONTROL, a")
		newKeys.handleInput(namePathObject, "Keys.BACKSPACE")
		WebUI.setText(namePathObject, Name)

		WebUI.verifyElementPresent(extRoleObject,0)
		WebUI.click(extRoleObject)

		WebUI.verifyElementPresent(extRoleOptionPathObject,0)
		WebUI.click(extRoleOptionPathObject)

		WebUI.verifyElementPresent(emailPathObject, 0)
		WebUI.click(emailPathObject)
		newKeys.handleInput(emailPathObject, "Keys.CONTROL, a")
		newKeys.handleInput(emailPathObject, "Keys.BACKSPACE")
		WebUI.setText(emailPathObject, Email)

		WebUI.verifyElementPresent(phoneNoPathObject, 0)
		WebUI.setText(phoneNoPathObject, PhoneNo)

		if(Role.toLowerCase().contains('approver') || !Token.equals('')){
			WebUI.verifyElementPresent(extTokenObject,0)
			WebUI.click(extTokenObject)

			WebUI.verifyElementPresent(extTokenOptionPathObject,0)
			WebUI.click(extTokenOptionPathObject)
		}else{
			WebUI.comment("current role $Role dont have access to token")
		}

	}

	@Keyword
	def editChargeDefaultPackage(List<String> data, String Currency, String Method, String ChargeValue, String billingInstruction){

		String temp = ""
		String xpath = "//div[@id='t-TabForm-panel-charge']//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//input[contains(@id, '_list-currency')]"
		String currencySelectedPath = xpath + "//li[contains(@id, '_list-currency') and text()='$Currency']"
		//list xpath method
		String methodPath = xpath + "//div[contains(@id, '_list-charge_method')]"
		String methodInputPath = xpath + "//input[contains(@id, '_list-charge_method')]"
		String methodSelectedPath = xpath + "//li[contains(@id, '_list-charge_method') and text()='$Method']"
		//list xpath charge value
		String chargeValueSelectedPath = xpath + "//div[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		String chargeValueInputPath = xpath + "//input[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		//list xpath billing
		String billingPath = xpath + "//div[contains(@id, '_list-billing_instruction')]"
		String billingInputPath = xpath + "//input[contains(@id, '_list-billing_instruction')]"
		String billingSelectedPath = xpath + "//li[contains(@id, '_list-billing_instruction')and text()='$billingInstruction']"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object method
		TestObject methodObject = new TestObject()
		TestObject methodInputObject = new TestObject()
		TestObject methodSelectedObject = new TestObject()
		methodObject.addProperty("xpath", ConditionType.EQUALS, methodPath)
		methodInputObject.addProperty("xpath", ConditionType.EQUALS, methodInputPath)
		methodSelectedObject.addProperty("xpath", ConditionType.EQUALS, methodSelectedPath)

		//list object charge value
		TestObject chargeValueSelectedObject = new TestObject()
		chargeValueSelectedObject.addProperty("xpath", ConditionType.EQUALS, chargeValueSelectedPath)
		TestObject chargeValueObject = new TestObject()
		chargeValueObject.addProperty("xpath", ConditionType.EQUALS, chargeValueInputPath)

		//list object billing instruction
		TestObject billingObject = new TestObject()
		TestObject billingInputObject = new TestObject()
		TestObject billingSelectedObject = new TestObject()
		billingObject.addProperty("xpath", ConditionType.EQUALS, billingPath)
		billingInputObject.addProperty("xpath", ConditionType.EQUALS, billingInputPath)
		billingSelectedObject.addProperty("xpath", ConditionType.EQUALS, billingSelectedPath)

		//editing currency
		WebUI.verifyElementPresent(currencyObject,0)
		WebUI.click(currencyObject)

		WebUI.verifyElementPresent(currencyInputObject,0)
		WebUI.setText(currencyInputObject, Currency)

		WebUI.verifyElementPresent(currencySelectedObject,0)
		WebUI.click(currencySelectedObject)

		//editing method
		WebUI.verifyElementPresent(methodObject,0)
		WebUI.click(methodObject)

		WebUI.verifyElementPresent(methodInputObject,0)
		WebUI.setText(methodInputObject, Method)

		WebUI.verifyElementPresent(methodSelectedObject,0)
		WebUI.click(methodSelectedObject)

		//editing charge value
		WebUI.verifyElementPresent(chargeValueObject,0)
		WebUI.scrollToElement(billingObject, 0)
		WebUI.scrollToPosition(0, 0)
		if(Method.equalsIgnoreCase("tiering / slab")){
			WebUI.click(chargeValueSelectedObject)
		}
		WebUI.setText(chargeValueObject, ChargeValue)

		//editing bill instruction
		WebUI.verifyElementPresent(billingObject,0)
		WebUI.click(billingObject)

		WebUI.verifyElementPresent(billingInputObject,0)
		WebUI.setText(billingInputObject, billingInstruction)

		WebUI.verifyElementPresent(billingSelectedObject,0)
		WebUI.click(billingSelectedObject)

	}

	@Keyword
	def editLimitDefaultPackage(String product, String currencyMatrix, String maxNoTrxPerDay ,String Currency, String maxTrxAmountPerDay, String minAmountPerTrx, String maxAmountPerTrx){

		SendKeys newKeys = new SendKeys();
		SetTextHandler newTexHandler = new SetTextHandler()
		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"] and .//td//span[text()="'+currencyMatrix+'"]]'
		String xpath2 = '//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				xpath = xpath2
			}
		}

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"
		println xpath

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.comment(xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(testObject, 100, 0)
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//div//input[contains(@id, 't-limit_list-currency')]"
		String currencySelectedPath = "//li[contains(@id, '_list-currency') and text()='$Currency']"

		//list xpath max no of transaction per day
		String maxOccurencePerDayInputPath = xpath + "//input[contains(@id, '_occurrence_per_day')]"

		//list xpath max amount transaction per day
		String maxAmountPerDayInputPath = xpath + "//input[contains(@id, 'max_amount_per_day')]"

		//list xpath min amount per transaction
		String minAmountPerTrxInputPath = xpath + "//input[contains(@id, 'min_amount_per_trx')]"

		//list xpath max amount per transaction
		String maxAmountPerTrxInputPath = xpath + "//input[contains(@id, 'max_amount_per_trx')]"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object max no of transaction per day
		TestObject maxOccurencePerDayObject = new TestObject()
		maxOccurencePerDayObject.addProperty("xpath", ConditionType.EQUALS, maxOccurencePerDayInputPath)

		//list object max amount transaction per day
		TestObject maxAmountPerDayObject = new TestObject()
		maxAmountPerDayObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerDayInputPath)

		//list object min amount per transaction
		TestObject minAmountPerTrxObject = new TestObject()
		minAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, minAmountPerTrxInputPath)

		//list object max amount per transaction
		TestObject maxAmountPerTrxObject = new TestObject()
		maxAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerTrxInputPath)

		//editing max no of transaction per day
		WebUI.verifyElementPresent(maxOccurencePerDayObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxOccurencePerDayObject, 0, 50)
		WebUI.click(maxOccurencePerDayObject)
		//		newKeys.handleInput(maxAmountPerTrxObject, "Keys.CONTROL, a")
		//		newKeys.handleInput(maxAmountPerTrxObject, "Keys.BACKSPACE")
		newTexHandler.handleInput(maxOccurencePerDayObject, maxNoTrxPerDay)

		//editing currency
		//		WebUI.scrollToPosition(300, 0)

		WebUI.verifyElementPresent(currencyObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(currencyObject, 0, 50)

		WebUI.click(currencyObject)

		WebUI.verifyElementPresent(currencyInputObject,0)
		WebUI.setText(currencyInputObject, Currency)
		WebUI.verifyElementPresent(currencySelectedObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(currencySelectedObject, 0, 50)
		WebUI.click(currencySelectedObject)

		//editing max amount transaction per day
		WebUI.verifyElementPresent(maxAmountPerDayObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerDayObject, 0, 50)
		newKeys.handleInput(maxAmountPerDayObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerDayObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerDayObject, maxTrxAmountPerDay)

		//editing min amount per transaction
		WebUI.verifyElementPresent(minAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(minAmountPerTrxObject)
		newKeys.handleInput(minAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(minAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(minAmountPerTrxObject, minAmountPerTrx)

		//editing max amount per transaction
		WebUI.verifyElementPresent(maxAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerTrxObject)
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerTrxObject, maxAmountPerTrx)


	}


	@Keyword
	def editServiceHourDefaultPackage(String product, String startTime, String endTime, String businessDay){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]]'

		String checkedItem = xpath + '//input[@type = "checkbox" and contains(@id, "t-service_hour_list")]'

		String startTimeInput  = '//*[contains(@id, "t-service_hour_list-service_hour_start-")]'//updated

		String endTimeInput  = '//*[contains(@id, "t-service_hour_list-service_hour_end-")]'//updated

		String businessDayInput  = xpath + '//td//input[contains(@id,"t-checkbox-service_hour_list-business_day_only")]'

		TestObject checkedItemObject = new TestObject()
		checkedItemObject.addProperty("xpath", ConditionType.EQUALS, checkedItem)

		TestObject startTimeInputObject = new TestObject()
		startTimeInputObject.addProperty("xpath", ConditionType.EQUALS, startTimeInput)

		TestObject endTimeInputObject = new TestObject()
		endTimeInputObject.addProperty("xpath", ConditionType.EQUALS, endTimeInput)

		TestObject businessDayInputObject = new TestObject()
		businessDayInputObject.addProperty("xpath", ConditionType.EQUALS, businessDayInput)

		TestObject buttonNowStart = new TestObject()
		buttonNowStart.addProperty("xpath", ConditionType.EQUALS, "(//li[@class = 'ant-picker-now'])[1]")

		TestObject buttonOkStart = new TestObject()
		buttonOkStart.addProperty("xpath", ConditionType.EQUALS, "(//*[@type = 'button' and @class = 'ant-btn ant-btn-primary ant-btn-sm'])[1]")

		TestObject buttonNowEnd = new TestObject()
		buttonNowEnd.addProperty("xpath", ConditionType.EQUALS, "(//li[@class = 'ant-picker-now'])[2]")

		TestObject buttonOkEnd = new TestObject()
		buttonOkEnd.addProperty("xpath", ConditionType.EQUALS, "(//*[@type = 'button' and @class = 'ant-btn ant-btn-primary ant-btn-sm'])[2]")

		WebUI.verifyElementPresent(checkedItemObject, 0)
		def checked = WebUI.verifyElementChecked(checkedItemObject, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(checkedItemObject, 100)
			WebUI.check(checkedItemObject)
			WebUI.verifyElementChecked(checkedItemObject, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}

		//input start time
		WebUI.verifyElementPresent(startTimeInputObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(startTimeInputObject, 0, 50)
		WebUI.click(startTimeInputObject)
		//newKeys.handleInput(startTimeInputObject, "Keys.CONTROL, a")
		//newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		String startTimeHour = startTime.substring(0, startTime.indexOf(":"))
		String startTimeMin = startTime.split(":")[1]
		/*WebUI.setText(startTimeInputObject, startTimeHour)
		 newKeys.handleInput(startTimeInputObject, startTimeMin)
		 newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		 newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		 newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		 newKeys.handleInput(startTimeInputObject, "Keys.ENTER")*/
		String startTimeInputHour = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$startTimeHour' or . = '$startTimeHour')])[1]"
		TestObject startInputHour = new TestObject()
		startInputHour.addProperty("xpath", ConditionType.EQUALS, startTimeInputHour)
		String startTimeInputMinute
		if(Integer.valueOf(startTimeMin) < 24) {
			startTimeInputMinute = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$startTimeMin' or . = '$startTimeMin')])[2]"
			//WebUI.comment("<24")
		}
		else {
			startTimeInputMinute = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$startTimeMin' or . = '$startTimeMin')])[1]"
			//WebUI.comment(">24")
		}
		TestObject startInputMinute = new TestObject()
		startInputMinute.addProperty("xpath", ConditionType.EQUALS, startTimeInputMinute)
		WebUI.enhancedClick(startInputHour, FailureHandling.STOP_ON_FAILURE)
		WebUI.enhancedClick(startInputMinute, FailureHandling.STOP_ON_FAILURE)
		/*println("start time hour clicked")
		 boolean start = WebUI.verifyElementVisible(startInputMinute, FailureHandling.OPTIONAL)
		 if(start.equals(true)) {
		 WebUI.enhancedClick(startInputMinute)
		 }else {
		 WebUI.enhancedClick(startInputHour)
		 }
		 println("start time minute clicked")*/
		WebUI.click(buttonOkStart)


		//input end time
		WebUI.verifyElementPresent(endTimeInputObject,0)
		WebUI.scrollToPosition(0, 0, FailureHandling.STOP_ON_FAILURE)
		scrollAdjusted.scrollIntoElementWithOffset(endTimeInputObject, 0, 50)
		WebUI.click(endTimeInputObject)
		/*WebUI.click(startTimeInputObject)
		 newKeys.handleInput(endTimeInputObject, "Keys.CONTROL, a")
		 newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")*/
		String endTimeHour = endTime.substring(0, endTime.indexOf(":"))
		String endTimeMin = endTime.split(":")[1]
		/*WebUI.setText(endTimeInputObject, endTimeHour)
		 newKeys.handleInput(endTimeInputObject, endTimeMin)
		 newKeys.handleInput(endTimeInputObject, "Keys.ARROW LEFT")
		 newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		 newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")
		 newKeys.handleInput(endTimeInputObject, "Keys.ENTER")*/
		String endTimeInputHour = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$endTimeHour' or . = '$endTimeHour')])[3]"
		TestObject endInputHour = new TestObject()
		endInputHour.addProperty("xpath", ConditionType.EQUALS, endTimeInputHour)
		String endTimeInputMinute
		if(Integer.valueOf(endTimeMin) < 24) {
			endTimeInputMinute = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$endTimeMin' or . = '$endTimeMin')])[4]"
			//WebUI.comment("<24")
		}
		else {
			endTimeInputMinute = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$endTimeMin' or . = '$endTimeMin')])[2]"
			//WebUI.comment(">24")
		}
		//	  	String endTimeInputMinute = "(//div[@class = 'ant-picker-time-panel-cell-inner' and (text() = '$endTimeMin' or . = '$endTimeMin')])[4]"
		TestObject endInputMinute = new TestObject()
		endInputMinute.addProperty("xpath", ConditionType.EQUALS, endTimeInputMinute)
		println(endTimeInputHour)
		WebUI.click(buttonNowEnd)
		WebUI.click(endTimeInputObject)
		WebUI.delay(3)
		WebUI.enhancedClick(endInputHour)
		println("end time hour clicked")
		boolean end = WebUI.verifyElementVisible(startInputMinute, FailureHandling.OPTIONAL)
		//if(end.equals(true)) {
		WebUI.enhancedClick(endInputMinute)
		//}else {
		//	WebUI.enhancedClick(endTimeInputHour)
		//}
		println("end time minute clicked")
		WebUI.click(buttonOkEnd)

		WebUI.verifyElementPresent(businessDayInputObject, 0)
		def checkedBusinessDay = WebUI.verifyElementChecked(businessDayInputObject, 0, FailureHandling.OPTIONAL)
		if(checkedBusinessDay.equals(false) && businessDay.equals("true")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.enhancedClick(businessDayInputObject)
			WebUI.verifyElementChecked(businessDayInputObject, 0)
			WebUI.comment("successfully check business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("false")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.uncheck(businessDayInputObject)
			WebUI.verifyElementNotChecked(businessDayInputObject, 0)
			WebUI.comment("successfully uncheck business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("true")){
			WebUI.comment("checkbox on targeted row have been checked")
		}else if(checkedBusinessDay.equals(false) && businessDay.equals("false")){
			WebUI.comment("checkbox on targeted row have been unchecked")
		}
	}


	@Keyword
	def accountMaintenanceEditAccountAllow(List<String> accountInfo, String debitAllow, String creditAllow, String inquiryAllow){
		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< accountInfo.size(); i++){
			value = accountInfo.get(i)
			if(i != accountInfo.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)

		WebUI.comment("targeted row found")

		TestObject allowDebitTrue = new TestObject()
		allowDebitTrue.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[@id='true-allow_debit']")

		TestObject allowDebitFalse = new TestObject()
		allowDebitFalse.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[@id='false-allow_debit']")

		def allowdebitStatus = WebUI.verifyElementPresent(allowDebitTrue, 0 , FailureHandling.OPTIONAL)

		if(debitAllow.equalsIgnoreCase("allow debit") && allowdebitStatus.equals(false)){
			WebUI.check(allowDebitFalse)
			WebUI.verifyElementPresent(allowDebitTrue, 0)
			WebUI.comment("successfulyy check allow debit")
		}else if(debitAllow.equalsIgnoreCase("not allow debit") && allowdebitStatus.equals(true)){
			WebUI.uncheck(allowDebitTrue)
			WebUI.verifyElementPresent(allowDebitFalse, 0)
			WebUI.comment("successfulyy uncheck allow debit")
		}else if(debitAllow.equalsIgnoreCase("allow debit") && allowdebitStatus.equals(true)){
			WebUI.comment("allow debit already checked")
		}else if(debitAllow.equalsIgnoreCase("not allow debit") && allowdebitStatus.equals(false)){
			WebUI.comment("allow debit already unchecked")
		}else if(debitAllow.equalsIgnoreCase("skip")){
			WebUI.comment("ignore allow debit")
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : allow debit, not allow debit, skip")
		}

		TestObject allowCreditTrue = new TestObject()
		allowCreditTrue.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[contains(@id, '-allow_credit')]")

		def allowCreditStatus = WebUI.verifyElementChecked(allowCreditTrue, 0 , FailureHandling.OPTIONAL)

		if(creditAllow.equalsIgnoreCase("allow credit") && allowCreditStatus.equals(false)){
			WebUI.check(allowCreditTrue)
			WebUI.verifyElementPresent(allowCreditTrue, 0)
			WebUI.comment("successfulyy check allow credit")
		}else if(creditAllow.equalsIgnoreCase("not allow credit") && allowCreditStatus.equals(true)){
			WebUI.uncheck(allowCreditTrue)
			WebUI.verifyElementPresent(allowCreditTrue, 0)
			WebUI.comment("successfulyy uncheck allow credit")
		}else if(creditAllow.equalsIgnoreCase("allow credit") && allowCreditStatus.equals(true)){
			WebUI.comment("allow credit already checked")
		}else if(creditAllow.equalsIgnoreCase("not allow credit") && allowCreditStatus.equals(false)){
			WebUI.comment("allow credit already unchecked")
		}else if(creditAllow.equalsIgnoreCase("skip")){
			WebUI.comment("ignore allow credit")
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : allow credit, not allow credit, skip")
		}

		TestObject allowInquiryTrue = new TestObject()
		allowInquiryTrue.addProperty("xpath", ConditionType.EQUALS, xpath+"//input[contains(@id, '-allow_inquiry')]")


		def allowInquiryStatus = WebUI.verifyElementChecked(allowInquiryTrue, 0 , FailureHandling.OPTIONAL)

		if(inquiryAllow.equalsIgnoreCase("allow inquiry") && allowInquiryStatus.equals(false)){
			WebUI.check(allowInquiryTrue)
			WebUI.verifyElementPresent(allowInquiryTrue, 0)
			WebUI.comment("successfulyy check allow inquiry")
		}else if(inquiryAllow.equalsIgnoreCase("not allow inquiry") && allowInquiryStatus.equals(true)){
			WebUI.uncheck(allowInquiryTrue)
			WebUI.verifyElementPresent(allowInquiryTrue, 0)
			WebUI.comment("successfulyy uncheck allow inquiry")
		}else if(inquiryAllow.equalsIgnoreCase("allow inquiry") && allowInquiryStatus.equals(true)){
			WebUI.comment("allow inquiry already checked")
		}else if(inquiryAllow.equalsIgnoreCase("not allow inquiry") && allowInquiryStatus.equals(false)){
			WebUI.comment("allow inquiry already unchecked")
		}else if(inquiryAllow.equalsIgnoreCase("skip")){
			WebUI.comment("ignore allow inquiry")
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : allow inquiry, not allow inquiry, skip")
		}
	}

	@Keyword
	def clickOnActionIconOnBankUserManager(List<String> rowData, String actionClicked){
		ScrollElement scrollAdjusted = new ScrollElement()
		ClickUsingJS clickJS = new ClickUsingJS()

		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< rowData.size(); i++){
			value = rowData.get(i)
			if(i != rowData.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)

		WebUI.comment("targeted row found")

		String xpathAction = xpath

		if(actionClicked.equals("activate")){
			xpathAction = xpathAction + "//button[contains(@id, 't-activate')]"
		}else if(actionClicked.equals("inactivate")){
			xpathAction = xpathAction + "//button[contains(@id, 't-inactivate')]"
		}else if(actionClicked.equals("reset")){
			xpathAction = xpathAction + "//button[contains(@id, 't-reset')]"
		}else if(actionClicked.equals("unlock")){
			xpathAction = xpathAction + "//button[contains(@id, 't-unlock')]"
		}else if(actionClicked.equals("release")){
			xpathAction = xpathAction + "//button[contains(@id, 't-release')]"
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : activate, inactivate, reset, unlock, release")
		}

		TestObject actionObject = new TestObject()
		actionObject.addProperty("xpath", ConditionType.EQUALS, xpathAction)

		Boolean status = WebUI.verifyElementHasAttribute(actionObject, "disabled", 0  , FailureHandling.OPTIONAL)
		if(status.equals(true)){
			KeywordUtil.markFailed("Action is disabled")
		}else{
			scrollAdjusted.scrollIntoElementWithOffset(actionObject, 1500, 2000)
			WebUI.delay(2)
			clickJS.ClickUsingJavaScript(actionObject, 0)
			//			WebUI.click(actionObject)
		}

	}

	@Keyword
	def verifyPageTableChanges(String destinationPage, int totalRowPerPage){

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, '//span[@id="t-search-table-record"]')
		WebUI.verifyElementVisible(objectSpecifiList)
		String tableRecord = WebUI.getText(objectSpecifiList)


		String totalRecord = tableRecord.substring(tableRecord.indexOf("of")+2, tableRecord.indexOf("records")).trim()
		String recordShownFirst = tableRecord.substring(tableRecord.indexOf("showing")+8, tableRecord.indexOf("to")).trim()
		String recordShownLast = tableRecord.substring(tableRecord.indexOf("to")+2, tableRecord.indexOf("of")).trim()
		Double totalRecordValue = Double.parseDouble(totalRecord)

		Double totalPage =  totalRecordValue / Double.valueOf(totalRowPerPage)

		BigDecimal bd = new BigDecimal(Double.toString(totalPage));
		bd = bd.setScale(0, RoundingMode.UP);
		String bdValue = String.valueOf(bd)
		Integer finalValue = Integer.parseInt(bdValue)
		WebUI.comment("$bd")
		if(destinationPage.equals("last")){
			String expectedRecordShownFirst = String.valueOf(((bd - 1) * totalRowPerPage)+1)
			String expectedRecordShownLast = totalRecord
			WebUI.comment("verify $recordShownFirst equals with $expectedRecordShownFirst ")
			WebUI.verifyEqual(recordShownFirst, expectedRecordShownFirst)
			WebUI.comment("verify $recordShownLast equals with $expectedRecordShownLast ")
			WebUI.verifyEqual(recordShownLast, expectedRecordShownLast)
		}else{
			Integer destinationValue = Integer.parseInt(destinationPage)
			String expectedRecordShownFirst = String.valueOf((totalRowPerPage * (destinationValue-1))+1)
			String expectedRecordShownLast = String.valueOf((totalRowPerPage * (destinationValue)))
			WebUI.comment("verify $recordShownFirst equals with $expectedRecordShownFirst")
			WebUI.verifyEqual(recordShownFirst, expectedRecordShownFirst)
			WebUI.comment("verify $recordShownLast equals with $expectedRecordShownLast")
			WebUI.verifyEqual(recordShownLast, expectedRecordShownLast)
		}
	}

	@Keyword
	def clickOnActionIconOnAuthenticationDevice(List<String> rowData, String actionClicked){

		ScrollElement scrollAdjusted = new ScrollElement()
		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< rowData.size(); i++){
			value = rowData.get(i)
			if(i != rowData.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)

		WebUI.comment("targeted row found")

		String xpathAction = xpath

		if(actionClicked.equals("register")){
			xpathAction = xpathAction + "//button[contains(@id, 't-authentication-device-register')]"
		}else if(actionClicked.equals("unregister")){
			xpathAction = xpathAction + "//button[contains(@id, 't-authentication-device-unregister')]"
		}else if(actionClicked.equals("unlock")){
			xpathAction = xpathAction + "//button[contains(@id, 't-authentication-device-unlock')]"
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : register, unregister, unlock")
		}

		TestObject actionObject = new TestObject()
		actionObject.addProperty("xpath", ConditionType.EQUALS, xpathAction)

		Boolean status = WebUI.verifyElementHasAttribute(actionObject, "disabled", 0  , FailureHandling.OPTIONAL)
		if(status.equals(true)){
			KeywordUtil.markFailed("Action is disabled")
		}else{
			scrollAdjusted.scrollIntoElementWithOffset(actionObject, 500, 150)
			WebUI.click(actionObject)

		}

	}

	@Keyword
	def verifyMenuPackage(List<String> listMenu){
		//with input [Test Data Menu column: 1 row: 1; Test Data Menu column: 1 row: 1;...]
		for(int i = 0; i <listMenu.size(); i++){
			String currentMenu = listMenu.get(i);
			WebUI.comment("current menu being checked : $currentMenu")
			String xpathMenu = "//tr[@record and contains(@data-row-key, '.0')]//td[@class='ant-table-cell' and not(.//label)][2]//span[text()='$currentMenu'] | //tr[@record and not(contains(@data-row-key, '.0'))]//td[@class='ant-table-cell' and not(.//label)]//span[text()='$currentMenu']"
			TestObject menuObject = new TestObject()
			menuObject.addProperty("xpath", ConditionType.EQUALS, xpathMenu)
			WebUI.verifyElementVisible(menuObject)
			WebUI.comment("current menu : $currentMenu found")
		}

	}

	@Keyword
	def getBankLimitTransaction(String product, String menu = "", String currencyMatrix, String column){

		String xpath


		xpath = "//tr["

		List<String> data = [product, menu, currencyMatrix]
		String temp = ""
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(!value.equals("")){
				if(i != data.size()-1){
					temp = './/td[(. = "'+value+'")] and '
				}else{
					temp = './/td[(. = "'+value+'")] '
				}
			}

			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath

		if(column.equalsIgnoreCase("currency")){
			xpath = xpath + "//td[5]"
		}else if(column.equalsIgnoreCase("minimum transaction limit")){
			xpath = xpath + "//td[6]"
		}else if(column.equalsIgnoreCase("maximum transaction limit")){
			xpath = xpath + "//td[7]"
		}
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
		def result = WebUI.getText(objectSpecifiList)
		WebUI.comment("successfully get $column value = $result, for product: $product, menu: $menu, currency matrix: $currencyMatrix")
	}

	@Keyword
	def editBankLimitTransaction(String product, String menu = "", String currencyMatrix, String currency = "", String minLimit ="", String maxLimit=""){

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath
		if(menu.equals("")){
			xpath = '//tr[.//td//span[text() = "'+menu+'"]]/following-sibling::tr[./td/span[text()="'+currencyMatrix+'"]][1]'
		}else{
			xpath = '//tr[.//td//span[text() = "'+menu+'"] and .//td//span[text()="'+menu+'"] and ./td/span[text()="'+currencyMatrix+'"]]'
		}			//tr[.//td//span[text() = "Bill Payment"] and .//td//span[text()="Single Bill Payment"] and ./td/span[text()="Local-Local"]]

		println xpath
		String checkboxRow = xpath +'//input[@type="checkbox"]'

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, checkboxRow)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		WebUI.check(objectSpecifiList)
		SendKeys newKeys = new SendKeys();
		if(!currency.equals("")){
			String currencyDDL = xpath + "//td//input[contains(@id, 't-select-currency')]"
			TestObject currencyDDLObject = new TestObject()
			currencyDDLObject.addProperty("xpath", ConditionType.EQUALS, currencyDDL)

			WebUI.verifyElementPresent(currencyDDLObject, 0)
			WebUI.click(currencyDDLObject)

			String currencyOption = xpath + "//td//li[contains(@id, 't-currency') and text()='$currency']"
			TestObject currencyOptionObject = new TestObject()
			currencyOptionObject.addProperty("xpath", ConditionType.EQUALS, currencyOption)

			String currencyLast = xpath + "//td//div//li[contains(@id, 't-currency')][last()]"
			TestObject currencyLastObject = new TestObject()
			currencyLastObject.addProperty("xpath", ConditionType.EQUALS, currencyLast)

			scrollAdjusted.scrollIntoElementWithOffset(currencyLastObject, 100)

			WebUI.verifyElementPresent(currencyOptionObject, 0)
			WebUI.click(currencyOptionObject)
			WebUI.comment("successfully choose currency $currency")


		}

		if(!minLimit.equals("") && !minLimit.equals("null")){
			String minimumLimit = xpath + "//td//input[contains(@id, 't-minimum')]"
			TestObject minimumLimitObject = new TestObject()
			minimumLimitObject.addProperty("xpath", ConditionType.EQUALS, minimumLimit)

			WebUI.verifyElementPresent(minimumLimitObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(minimumLimitObject, 100)

			newKeys.handleInput(minimumLimitObject, "Keys.CONTROL, a")
			newKeys.handleInput(minimumLimitObject, "Keys.BACKSPACE")

			WebUI.setText(minimumLimitObject, minLimit)
			WebUI.comment("successfully set minimum transaction limit to $minLimit")
		}else if(minLimit.equals("null")){
			String minimumLimit = xpath + "//td//input[contains(@id, 't-minimum')]"
			TestObject minimumLimitObject = new TestObject()
			minimumLimitObject.addProperty("xpath", ConditionType.EQUALS, minimumLimit)

			String minimumLimitError = xpath + "//td//span[contains(@id, 't-error-minimum_trx_limit')]"
			TestObject minimumLimitErrorObject = new TestObject()
			minimumLimitErrorObject.addProperty("xpath", ConditionType.EQUALS, minimumLimitError)

			WebUI.verifyElementPresent(minimumLimitObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(minimumLimitObject, 100)

			newKeys.handleInput(minimumLimitObject, "Keys.CONTROL, a")
			newKeys.handleInput(minimumLimitObject, "Keys.BACKSPACE")

			WebUI.verifyElementText(minimumLimitErrorObject, "This field is required")
			WebUI.comment("successfully set minimum transaction limit to null")

		}

		if(!maxLimit.equals("") && !maxLimit.equals("null")){
			String maximumLimit = xpath + "//td//input[contains(@id, 't-maximum')]"
			TestObject maximumLimitObject = new TestObject()
			maximumLimitObject.addProperty("xpath", ConditionType.EQUALS, maximumLimit)

			WebUI.verifyElementPresent(maximumLimitObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(maximumLimitObject, 100)

			newKeys.handleInput(maximumLimitObject, "Keys.CONTROL, a")
			newKeys.handleInput(maximumLimitObject, "Keys.BACKSPACE")

			WebUI.setText(maximumLimitObject, maxLimit)
			WebUI.comment("successfully set maximum transaction limit to $maxLimit")
		}else if(maxLimit.equals("null")){
			String maximumLimit = xpath + "//td//input[contains(@id, 't-maximum')]"
			TestObject maximumLimitObject = new TestObject()
			maximumLimitObject.addProperty("xpath", ConditionType.EQUALS, maximumLimit)

			String maximumLimitError = xpath + "//td//span[contains(@id, 't-error-maximum_trx_limit')]"
			TestObject maximumLimitErrorObject = new TestObject()
			maximumLimitErrorObject.addProperty("xpath", ConditionType.EQUALS, maximumLimitError)

			WebUI.verifyElementPresent(maximumLimitObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(maximumLimitObject, 100)

			newKeys.handleInput(maximumLimitObject, "Keys.CONTROL, a")
			newKeys.handleInput(maximumLimitObject, "Keys.BACKSPACE")
			WebUI.verifyElementText(maximumLimitErrorObject, "This field is required")
			WebUI.comment("successfully set maximum transaction limit to null")

		}

		WebUI.comment("successfully edit value for product: $product, menu: $menu, currency matrix: $currencyMatrix")
	}

	@Keyword
	def clickOnActionIconOnServicePackage(List<String> rowData, String actionClicked){
		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< rowData.size(); i++){
			value = rowData.get(i)
			if(i != rowData.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)

		WebUI.comment("targeted row found")

		String xpathAction = xpath

		if(actionClicked.equals("edit")){
			xpathAction = xpathAction + "//button[contains(@id, 't-service-package-edit')]"
		}else if(actionClicked.equals("edit menu")){
			xpathAction = xpathAction + "//button[contains(@id, 't-service-package-edit-menu')]"
		}else if(actionClicked.equals("download")){
			xpathAction = xpathAction + "//button[contains(@id, 't-service-package-download')]"
		}else if(actionClicked.equals("delete")){
			xpathAction = xpathAction + "//button[contains(@id, 't-service-package-delete')]"
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : edit, edit menu, download, delete")
		}

		TestObject actionObject = new TestObject()
		actionObject.addProperty("xpath", ConditionType.EQUALS, xpathAction)

		Boolean status = WebUI.verifyElementHasAttribute(actionObject, "disabled", 0  , FailureHandling.OPTIONAL)
		if(status.equals(true)){
			KeywordUtil.markFailed("Action is disabled")
		}else{
			WebUI.click(actionObject)
		}

	}

	@Keyword
	def clickOnActionIconOnCustomPackage(List<String> rowData, String actionClicked){
		String temp = ""
		String xpath = "//tr["
		String value
		for(int i= 0; i< rowData.size(); i++){
			value = rowData.get(i)
			if(i != rowData.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)

		WebUI.comment("targeted row found")

		String xpathAction = xpath

		if(actionClicked.equals("edit")){
			xpathAction = xpathAction + "//*[contains(@id, 't-custom-package-edit')]"
		}else if(actionClicked.equals("delete")){
			xpathAction = xpathAction + "//*[contains(@id, 't-custom-package-delete')]"
		}else{
			KeywordUtil.markFailed("input can not be recognized, valid input : edit, delete")
		}

		TestObject actionObject = new TestObject()
		actionObject.addProperty("xpath", ConditionType.EQUALS, xpathAction)

		Boolean status = WebUI.verifyElementHasAttribute(actionObject, "disabled", 0  , FailureHandling.OPTIONAL)
		if(status.equals(true)){
			KeywordUtil.markFailed("Action is disabled")
		}else{
			WebUI.click(actionObject)
		}

	}


	@Keyword
	def verifyTableHeaderOnDefaultPackageCharge(List<String> headerValue, String section){
		String xpath = "//div[@id='t-TabForm-panel-charge']//div[contains(@class, 'WorkflowSection-container') and .//div[@role='separator' and ./span[text()='$section']]]//table//thead//tr["
		String temp = ""
		String value
		for(int i= 0; i< headerValue.size(); i++){
			value = headerValue.get(i)
			if(i != headerValue.size()-1){
				temp = './/th[(. = "'+value+'")] and '
			}else{
				temp = './/th[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
		WebUI.comment("successfully verify table $section has this column(s): $headerValue")
	}

	@Keyword
	def verifyTableHeaderOnDefaultPackageLimit(List<String> headerValue, String section){
		String xpath = "//div[@id='t-TabForm-panel-limit']//div[contains(@class, 'WorkflowSection-container') and .//div[@role='separator' and ./span[text()='$section']]]//table//thead//tr["
		String temp = ""
		String value
		for(int i= 0; i< headerValue.size(); i++){
			value = headerValue.get(i)
			if(i != headerValue.size()-1){
				temp = './/th[(. = "'+value+'")] and '
			}else{
				temp = './/th[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
		WebUI.comment("successfully verify table $section has this column(s): $headerValue")
	} //by titus


	@Keyword
	def verifyTableHeaderOnDefaultPackageServiceHour(List<String> headerValue, String section){
		String xpath = "//div[@id='t-TabForm-panel-service_hour']//div[contains(@class, 'WorkflowSection-container') and .//div[@role='separator' and ./span[text()='$section']]]//table//thead//tr["
		String temp = ""
		String value
		for(int i= 0; i< headerValue.size(); i++){
			value = headerValue.get(i)
			if(i != headerValue.size()-1){
				temp = './/th[(. = "'+value+'")] and '
			}else{
				temp = './/th[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.verifyElementVisible(objectSpecifiList)
		WebUI.comment("successfully verify table $section has this column(s): $headerValue")
	}

	@Keyword
	def editChargeCustomPackage(List<String> data, String Currency, String Method, String ChargeValue, String billingInstruction){

		SendKeys newKeys = new SendKeys();

		String temp = ""
		String xpath = "//div[@id='t-Workflow-input']//div[@id='t-TabForm-panel-charge']//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//input[contains(@id, '_list-currency')]"
		String currencySelectedPath = xpath + "//li[contains(@id, '_list-currency') and text()='$Currency']"
		//list xpath method
		String methodPath = xpath + "//div[contains(@id, '_list-charge_method')]"
		String methodInputPath = xpath + "//input[contains(@id, '_list-charge_method')]"
		String methodSelectedPath = xpath + "//li[contains(@id, '_list-charge_method') and text()='$Method']"
		//list xpath charge value
		String chargeValueSelectedPath = xpath + "//div[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		String chargeValueInputPath = xpath + "//input[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		//list xpath billing
		String billingPath = xpath + "//div[contains(@id, '_list-billing_instruction')]"
		String billingInputPath = xpath + "//input[contains(@id, '_list-billing_instruction')]"
		String billingSelectedPath = xpath + "//li[contains(@id, '_list-billing_instruction')and text()='$billingInstruction']"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object method
		TestObject methodObject = new TestObject()
		TestObject methodInputObject = new TestObject()
		TestObject methodSelectedObject = new TestObject()
		methodObject.addProperty("xpath", ConditionType.EQUALS, methodPath)
		methodInputObject.addProperty("xpath", ConditionType.EQUALS, methodInputPath)
		methodSelectedObject.addProperty("xpath", ConditionType.EQUALS, methodSelectedPath)

		//list object charge value
		TestObject chargeValueSelectedObject = new TestObject()
		chargeValueSelectedObject.addProperty("xpath", ConditionType.EQUALS, chargeValueSelectedPath)
		TestObject chargeValueObject = new TestObject()
		chargeValueObject.addProperty("xpath", ConditionType.EQUALS, chargeValueInputPath)

		//list object billing instruction
		TestObject billingObject = new TestObject()
		TestObject billingInputObject = new TestObject()
		TestObject billingSelectedObject = new TestObject()
		billingObject.addProperty("xpath", ConditionType.EQUALS, billingPath)
		billingInputObject.addProperty("xpath", ConditionType.EQUALS, billingInputPath)
		billingSelectedObject.addProperty("xpath", ConditionType.EQUALS, billingSelectedPath)

		//editing currency
		WebUI.verifyElementPresent(currencyObject,0)
		WebUI.click(currencyObject)

		WebUI.verifyElementPresent(currencyInputObject,0)
		WebUI.setText(currencyInputObject, Currency)

		WebUI.verifyElementPresent(currencySelectedObject,0)
		WebUI.click(currencySelectedObject)

		//editing method
		WebUI.verifyElementPresent(methodObject,0)
		WebUI.click(methodObject)

		WebUI.verifyElementPresent(methodInputObject,0)
		newKeys.handleInput(methodInputObject, "Keys.CONTROL, a")
		newKeys.handleInput(methodInputObject, "Keys.BACKSPACE")
		WebUI.setText(methodInputObject, Method)

		WebUI.verifyElementPresent(methodSelectedObject,0)
		WebUI.click(methodSelectedObject)

		//editing charge value
		WebUI.verifyElementPresent(chargeValueObject,0)
		WebUI.scrollToElement(billingObject, 0)
		WebUI.scrollToPosition(0, 0)
		if(Method.equalsIgnoreCase("tiering / slab")){
			WebUI.click(chargeValueSelectedObject)
		}
		WebUI.setText(chargeValueObject, ChargeValue)

		//editing bill instruction
		WebUI.verifyElementPresent(billingObject,0)
		WebUI.click(billingObject)

		WebUI.verifyElementPresent(billingInputObject,0)
		WebUI.setText(billingInputObject, billingInstruction)

		WebUI.verifyElementPresent(billingSelectedObject,0)
		WebUI.click(billingSelectedObject)

	}

	@Keyword
	def editLimitCustomPackage(String product, String menu, String currencyMatrix, String maxNoTrxPerDay ,String Currency, String maxTrxAmountPerDay, String minAmountPerTrx, String maxAmountPerTrx){

		SendKeys newKeys = new SendKeys();
		SetTextHandler newTexHandler = new SetTextHandler()

		ScrollElement scrollAdjusted = new ScrollElement()

		//String idTab = //div[@id="t-TabForm-panel-limit"]
		//String idTab = "//div[@id='t-TabForm-panel-limit']"
		//		"//div[contains(@id, 'tab-3')]"

		String xpath =  '//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+menu+'"] and .//td//span[text()="'+currencyMatrix+'"]]'
		//	'//div[@id="t-Workflow-input"]+'idTab'+//tr[//td//span[text()="'+product+'"] and //td//span[text()="'+currencyMatrix+'"]]'
		String xpath2 = '//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+menu+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
		//	'//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'

		if(!menu == '' || !menu == ""){
			xpath = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-limit"]//tr[//td//span[text()="'+product+'"] and .//td//span[text()="'+menu+'"] and .//td//span[text()="'+currencyMatrix+'"]]'
			xpath2 = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-limit"]//tr[//td//span[text()="'+product+'"]]/following-sibling::tr[//td//span[text()="'+menu+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
			//	 '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+menu+'"]][1]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
		}

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				xpath = xpath2
			}
		}

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"
		println xpath

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.comment(xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			//			scrollAdjusted.scrollIntoElementWithOffset(testObject, 550, 50)
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//div//input[contains(@id, 't-limit_list-currency')]"
		String currencySelectedPath = "//li[contains(@id, '_list-currency') and text()='$Currency']"

		//list xpath max no of transaction per days
		String maxOccurencePerDayInputPath = xpath + "//input[contains(@id, '_occurrence_per_day')]"

		//list xpath max amount transaction per day
		String maxAmountPerDayInputPath = xpath + "//input[contains(@id, 'max_amount_per_day')]"

		//list xpath min amount per transaction
		String minAmountPerTrxInputPath = xpath + "//input[contains(@id, 'min_amount_per_trx')]"

		//list xpath max amount per transaction
		String maxAmountPerTrxInputPath = xpath + "//input[contains(@id, 'max_amount_per_trx')]"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object max no of transaction per day
		TestObject maxOccurencePerDayObject = new TestObject()
		maxOccurencePerDayObject.addProperty("xpath", ConditionType.EQUALS, maxOccurencePerDayInputPath)

		//list object max amount transaction per day
		TestObject maxAmountPerDayObject = new TestObject()
		maxAmountPerDayObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerDayInputPath)

		//list object min amount per transaction
		TestObject minAmountPerTrxObject = new TestObject()
		minAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, minAmountPerTrxInputPath)

		//list object max amount per transaction
		TestObject maxAmountPerTrxObject = new TestObject()
		maxAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerTrxInputPath)
		WebUI.enableSmartWait()
		//editing max no of transaction per day
		WebUI.verifyElementPresent(maxOccurencePerDayObject,0)
		//		scrollAdjusted.scrollIntoElementWithOffset(maxOccurencePerDayObject, 500, 50)
		newKeys.handleInput(maxOccurencePerDayObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxOccurencePerDayObject, "Keys.BACKSPACE")
		//		WebUI.switchToDefaultContent()
		//		WebUI.modifyObjectProperty(maxOccurencePerDayObject, 'value', 'equals',maxNoTrxPerDay, false)
		//		WebUI.click(maxOccurencePerDayObject)
		WebUI.comment(maxOccurencePerDayInputPath)
		WebUI.setText(maxOccurencePerDayObject, maxNoTrxPerDay)

		//editing currency
		//		WebUI.scrollToPosition(300, 0)

		WebUI.verifyElementPresent(currencyObject,0)
		WebUI.click(currencyObject)
		WebUI.setText(currencyInputObject, Currency)
		scrollAdjusted.scrollIntoElementWithOffset(currencySelectedObject, 500, 50)
		WebUI.enhancedClick(currencySelectedObject)
		WebUI.comment("successfully choose Currency")


		//		WebUI.verifyElementPresent(currencyInputObject,0)
		//		WebUI.click(currencyInputObject)
		/*
		 WebUI.verifyElementPresent(currencySelectedObject,0)
		 scrollAdjusted.scrollIntoElementWithOffset(currencySelectedObject, 500, 50)
		 WebUI.click(currencySelectedObject)*/

		//editing max amount transaction per day
		WebUI.verifyElementPresent(maxAmountPerDayObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerDayObject, 500, 50)
		newKeys.handleInput(maxAmountPerDayObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerDayObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerDayObject, maxTrxAmountPerDay)

		//editing min amount per transaction
		WebUI.verifyElementPresent(minAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(minAmountPerTrxObject, 500, 50)
		newKeys.handleInput(minAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(minAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(minAmountPerTrxObject, minAmountPerTrx)

		//editing max amount per transaction
		WebUI.verifyElementPresent(maxAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerTrxObject, 500, 50)
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerTrxObject, maxAmountPerTrx)


	}

	@Keyword
	def editServiceHourCustomPackage(String product, String menu, String startTime, String endTime, String businessDay){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]]'
		String xpath2 = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]][1]'

		if(!menu == '' || !menu == ""){
			xpath = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"] and .//td//span[text()="'+menu+'"]]'
			xpath2 = '//div[@id="t-Workflow-input"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+menu+'"]][1]'
		}

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				xpath = xpath2
			}
		}

		String checkedItem = xpath + '//input[@type = "checkbox" and contains(@id, "t-service_hour_list")]'

		String startTimeInput  = xpath + '//td//input[contains(@id,"t-service_hour_list-service_hour_start")]'

		String endTimeInput  = xpath + '//td//input[contains(@id,"t-service_hour_list-service_hour_end")]'

		String businessDayInput  = xpath + '//td//input[contains(@id,"t-checkbox-service_hour_list-business_day_only")]'

		TestObject checkedItemObject = new TestObject()
		checkedItemObject.addProperty("xpath", ConditionType.EQUALS, checkedItem)

		TestObject startTimeInputObject = new TestObject()
		startTimeInputObject.addProperty("xpath", ConditionType.EQUALS, startTimeInput)

		TestObject endTimeInputObject = new TestObject()
		endTimeInputObject.addProperty("xpath", ConditionType.EQUALS, endTimeInput)

		TestObject businessDayInputObject = new TestObject()
		businessDayInputObject.addProperty("xpath", ConditionType.EQUALS, businessDayInput)

		WebUI.verifyElementPresent(checkedItemObject, 0)
		def checked = WebUI.verifyElementChecked(checkedItemObject, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(checkedItemObject, 100)
			WebUI.check(checkedItemObject)
			WebUI.verifyElementChecked(checkedItemObject, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}

		WebUI.verifyElementPresent(startTimeInputObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(startTimeInputObject, 0, 50)
		WebUI.click(startTimeInputObject)
		newKeys.handleInput(startTimeInputObject, "Keys.CONTROL, a")
		newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		String startTimeHour = startTime.substring(0, startTime.indexOf(":")+1)
		String startTimeMin = startTime.split(":")[1]
		WebUI.setText(startTimeInputObject, startTimeHour)
		newKeys.handleInput(startTimeInputObject, startTimeMin)
		newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		newKeys.handleInput(startTimeInputObject, "Keys.ENTER")

		WebUI.verifyElementPresent(endTimeInputObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(endTimeInputObject, 0, 50)
		WebUI.click(endTimeInputObject)
		WebUI.click(startTimeInputObject)
		newKeys.handleInput(endTimeInputObject, "Keys.CONTROL, a")
		newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")
		String endTimeHour = endTime.substring(0, endTime.indexOf(":")+1)
		String endTimeMin = endTime.split(":")[1]
		WebUI.setText(endTimeInputObject, endTimeHour)
		newKeys.handleInput(endTimeInputObject, endTimeMin)
		newKeys.handleInput(endTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(endTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")
		newKeys.handleInput(endTimeInputObject, "Keys.ENTER")

		WebUI.verifyElementPresent(businessDayInputObject, 0)
		def checkedBusinessDay = WebUI.verifyElementChecked(businessDayInputObject, 0, FailureHandling.OPTIONAL)
		if(checkedBusinessDay.equals(false) && businessDay.equals("true")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.check(businessDayInputObject)
			WebUI.verifyElementChecked(businessDayInputObject, 0)
			WebUI.comment("successfully check business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("false")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.uncheck(businessDayInputObject)
			WebUI.verifyElementNotChecked(businessDayInputObject, 0)
			WebUI.comment("successfully uncheck business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("true")){
			WebUI.comment("checkbox on targeted row have been checked")
		}else if(checkedBusinessDay.equals(false) && businessDay.equals("false")){
			WebUI.comment("checkbox on targeted row have been unchecked")
		}
	}

	@Keyword
	def addMenuServicePackage(List<String> menuChoices){
		ScrollElement scrollAdjusted = new ScrollElement()

		for(int i = 0; i <menuChoices.size(); i++){
			String currentMenu = menuChoices[i]
			String chosenMenu = '//tr[@record and .//td//span[text()="'+currentMenu+'"]]//input[@type="checkbox" and contains(@id, "t-menu-check")]'

			TestObject chosenMenuObject = new TestObject()
			chosenMenuObject.addProperty("xpath", ConditionType.EQUALS, chosenMenu)

			WebUI.verifyElementPresent(chosenMenuObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(chosenMenuObject, 1000, 0)
			WebUI.check(chosenMenuObject)
			WebUI.verifyElementChecked(chosenMenuObject, 0)
			WebUI.comment("successfully check menu $currentMenu checkbox on targeted row")

		}

	}


	@Keyword
	def addProductServicePackage(List<String> productChoices){
		ScrollElement scrollAdjusted = new ScrollElement()

		for(int i = 0; i <productChoices.size(); i++){
			String currentProduct = productChoices[i]
			String chosenProduct = '//div[@role="document"]//tr[@record and .//td//span[text()="'+currentProduct+'"]]//input[@type="checkbox" and contains(@id, "t-menu-check")]'

			TestObject chosenProductObject = new TestObject()
			chosenProductObject.addProperty("xpath", ConditionType.EQUALS, chosenProduct)

			WebUI.verifyElementPresent(chosenProductObject, 0)
			scrollAdjusted.scrollIntoElementWithOffset(chosenProductObject, 1000, 0)
			WebUI.check(chosenProductObject)
			WebUI.verifyElementChecked(chosenProductObject, 0)
			WebUI.comment("successfully check menu $currentProduct checkbox on targeted row")

		}

	}

	@Keyword
	def editChargeServicePackage(List<String> data, String Currency, String Method, String ChargeValue, String billingInstruction){

		String temp = ""
		String xpath = "//div[@id='t-Workflow-input_product']//div[@id='t-TabForm-panel-charge']//tr["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = './/td[(. = "'+value+'")] and '
			}else{
				temp = './/td[(. = "'+value+'")] '
			}
			xpath = xpath + temp
		}
		xpath = xpath + "]"

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//input[contains(@id, '_list-currency')]"
		String currencySelectedPath = xpath + "//li[contains(@id, '_list-currency') and text()='$Currency']"
		//list xpath method
		String methodPath = xpath + "//div[contains(@id, '_list-charge_method')]"
		String methodInputPath = xpath + "//input[contains(@id, '_list-charge_method')]"
		String methodSelectedPath = xpath + "//li[contains(@id, '_list-charge_method') and text()='$Method']"
		//list xpath charge value
		String chargeValueSelectedPath = xpath + "//div[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		String chargeValueInputPath = xpath + "//input[contains(@id, '_list-value') or contains(@id, 't-select-t-product_list-business_rule')]"
		//list xpath billing
		String billingPath = xpath + "//div[contains(@id, '_list-billing_instruction')]"
		String billingInputPath = xpath + "//input[contains(@id, '_list-billing_instruction')]"
		String billingSelectedPath = xpath + "//li[contains(@id, '_list-billing_instruction')and text()='$billingInstruction']"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object method
		TestObject methodObject = new TestObject()
		TestObject methodInputObject = new TestObject()
		TestObject methodSelectedObject = new TestObject()
		methodObject.addProperty("xpath", ConditionType.EQUALS, methodPath)
		methodInputObject.addProperty("xpath", ConditionType.EQUALS, methodInputPath)
		methodSelectedObject.addProperty("xpath", ConditionType.EQUALS, methodSelectedPath)

		//list object charge value
		TestObject chargeValueSelectedObject = new TestObject()
		chargeValueSelectedObject.addProperty("xpath", ConditionType.EQUALS, chargeValueSelectedPath)
		TestObject chargeValueObject = new TestObject()
		chargeValueObject.addProperty("xpath", ConditionType.EQUALS, chargeValueInputPath)

		//list object billing instruction
		TestObject billingObject = new TestObject()
		TestObject billingInputObject = new TestObject()
		TestObject billingSelectedObject = new TestObject()
		billingObject.addProperty("xpath", ConditionType.EQUALS, billingPath)
		billingInputObject.addProperty("xpath", ConditionType.EQUALS, billingInputPath)
		billingSelectedObject.addProperty("xpath", ConditionType.EQUALS, billingSelectedPath)

		//editing currency
		WebUI.verifyElementPresent(currencyObject,0)
		WebUI.click(currencyObject)

		WebUI.verifyElementPresent(currencyInputObject,0)
		WebUI.setText(currencyInputObject, Currency)

		WebUI.verifyElementPresent(currencySelectedObject,0)
		WebUI.click(currencySelectedObject)

		//editing method
		WebUI.verifyElementPresent(methodObject,0)
		WebUI.click(methodObject)

		WebUI.verifyElementPresent(methodInputObject,0)
		WebUI.setText(methodInputObject, Method)

		WebUI.verifyElementPresent(methodSelectedObject,0)
		WebUI.click(methodSelectedObject)

		//editing charge value
		WebUI.verifyElementPresent(chargeValueObject,0)
		WebUI.scrollToElement(billingObject, 0)
		WebUI.scrollToPosition(0, 0)
		if(Method.equalsIgnoreCase("tiering / slab")){
			WebUI.click(chargeValueSelectedObject)
		}
		WebUI.setText(chargeValueObject, ChargeValue)

		//editing bill instruction
		WebUI.verifyElementPresent(billingObject,0)
		WebUI.click(billingObject)

		WebUI.verifyElementPresent(billingInputObject,0)
		WebUI.setText(billingInputObject, billingInstruction)

		WebUI.verifyElementPresent(billingSelectedObject,0)
		WebUI.click(billingSelectedObject)

	}

	@Keyword
	def editLimitServicePackage(String product, String menu = "", String currencyMatrix, String maxNoTrxPerDay ,String Currency, String maxTrxAmountPerDay, String minAmountPerTrx, String maxAmountPerTrx){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"] and .//td//span[text()="'+menu+'"] and .//td//span[text()="'+currencyMatrix+'"]]'
		String xpath2 = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+menu+'"]][1]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
		println xpath

		if(!menu == '' || !menu == ""){
			xpath = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"] and .//td//span[text()="'+currencyMatrix+'"]] | //div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
			xpath2 = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+currencyMatrix+'"]][1]'
		}

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				xpath = xpath2
			}
		}

		String xpathCheckBox = xpath + "//input[@type='checkbox' and not(@disabled='true')]"


		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.comment(xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(testObject, 500, 50)
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath currency
		String currencyPath = xpath + "//div[contains(@id, '_list-currency')]"
		String currencyInputPath = xpath + "//div//input[contains(@id, 't-limit_list-currency')]"
		String currencySelectedPath = xpath + "//li[contains(@id, '_list-currency') and text()='$Currency']"

		//list xpath max no of transaction per day
		String maxOccurencePerDayInputPath = xpath + "//input[contains(@id, '_occurrence_per_day')]"

		//list xpath max amount transaction per day
		String maxAmountPerDayInputPath = xpath + "//input[contains(@id, 'max_amount_per_day')]"

		//list xpath min amount per transaction
		String minAmountPerTrxInputPath = xpath + "//input[contains(@id, 'min_amount_per_trx')]"

		//list xpath max amount per transaction
		String maxAmountPerTrxInputPath = xpath + "//input[contains(@id, 'max_amount_per_trx')]"

		//list object currency
		TestObject currencyObject = new TestObject()
		TestObject currencyInputObject = new TestObject()
		TestObject currencySelectedObject = new TestObject()
		currencyObject.addProperty("xpath", ConditionType.EQUALS, currencyPath)
		currencyInputObject.addProperty("xpath", ConditionType.EQUALS, currencyInputPath)
		currencySelectedObject.addProperty("xpath", ConditionType.EQUALS, currencySelectedPath)

		//list object max no of transaction per day
		TestObject maxOccurencePerDayObject = new TestObject()
		maxOccurencePerDayObject.addProperty("xpath", ConditionType.EQUALS, maxOccurencePerDayInputPath)

		//list object max amount transaction per day
		TestObject maxAmountPerDayObject = new TestObject()
		maxAmountPerDayObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerDayInputPath)

		//list object min amount per transaction
		TestObject minAmountPerTrxObject = new TestObject()
		minAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, minAmountPerTrxInputPath)

		//list object max amount per transaction
		TestObject maxAmountPerTrxObject = new TestObject()
		maxAmountPerTrxObject.addProperty("xpath", ConditionType.EQUALS, maxAmountPerTrxInputPath)

		WebUI.enableSmartWait()
		//editing max no of transaction per day
		WebUI.verifyElementPresent(maxOccurencePerDayObject,0)
		//		scrollAdjusted.scrollIntoElementWithOffset(maxOccurencePerDayObject, 500, 50)
		newKeys.handleInput(maxOccurencePerDayObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxOccurencePerDayObject, "Keys.BACKSPACE")
		//		WebUI.switchToDefaultContent()
		//		WebUI.modifyObjectProperty(maxOccurencePerDayObject, 'value', 'equals',maxNoTrxPerDay, false)
		//		WebUI.click(maxOccurencePerDayObject)
		WebUI.comment(maxOccurencePerDayInputPath)
		WebUI.setText(maxOccurencePerDayObject, maxNoTrxPerDay)

		//editing currency
		//		WebUI.scrollToPosition(300, 0)

		WebUI.verifyElementPresent(currencyObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(currencyObject, 500, 50)
		WebUI.click(currencyObject)

		WebUI.verifyElementPresent(currencyInputObject,0)
		WebUI.setText(currencyInputObject, Currency)
		WebUI.verifyElementPresent(currencySelectedObject,0)
		//		scrollAdjusted.scrollIntoElementWithOffset(currencySelectedObject, 500, 50)
		WebUI.click(currencySelectedObject)

		//editing max amount transaction per day
		WebUI.verifyElementPresent(maxAmountPerDayObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerDayObject, 0, 50)
		newKeys.handleInput(maxAmountPerDayObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerDayObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerDayObject, maxTrxAmountPerDay)

		//editing min amount per transaction
		WebUI.verifyElementPresent(minAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(minAmountPerTrxObject)
		newKeys.handleInput(minAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(minAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(minAmountPerTrxObject, minAmountPerTrx)

		//editing max amount per transaction
		WebUI.verifyElementPresent(maxAmountPerTrxObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(maxAmountPerTrxObject)
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.CONTROL, a")
		newKeys.handleInput(maxAmountPerTrxObject, "Keys.BACKSPACE")
		WebUI.setText(maxAmountPerTrxObject, maxAmountPerTrx)


	}

	@Keyword
	def editServiceHourServicePackage(String product, String menu = "", String startTime, String endTime, String businessDay){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"] and .//td//span[text()="'+menu+'"]]'
		String xpath2 = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]]/following-sibling::tr[.//td//span[text()="'+menu+'"]][1]'
		println xpath

		if(!menu == '' || !menu == ""){
			xpath = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]] | //div[@id="t-TabForm-panel-limit"]//tr[.//td//span[text()="'+product+'"]]'
			xpath2 = '//div[@id="t-Workflow-input_product"]//div[@id="t-TabForm-panel-service_hour"]//tr[.//td//span[text()="'+product+'"]][1]'
		}

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		TestObject currentCell2 = new TestObject()
		currentCell2.addProperty("xpath", ConditionType.EQUALS, xpath2)

		if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
			if(WebUI.verifyElementPresent(currentCell2, 0)){
				xpath = xpath2
			}
		}

		String checkedItem = xpath + '//input[@type = "checkbox" and contains(@id, "t-service_hour_list")]'

		String startTimeInput  = xpath + '//td//input[contains(@id,"t-service_hour_list-service_hour_start")]'

		String endTimeInput  = xpath + '//td//input[contains(@id,"t-service_hour_list-service_hour_end")]'

		String businessDayInput  = xpath + '//td//input[contains(@id,"t-checkbox-service_hour_list-business_day_only")]'

		TestObject checkedItemObject = new TestObject()
		checkedItemObject.addProperty("xpath", ConditionType.EQUALS, checkedItem)

		TestObject startTimeInputObject = new TestObject()
		startTimeInputObject.addProperty("xpath", ConditionType.EQUALS, startTimeInput)

		TestObject endTimeInputObject = new TestObject()
		endTimeInputObject.addProperty("xpath", ConditionType.EQUALS, endTimeInput)

		TestObject businessDayInputObject = new TestObject()
		businessDayInputObject.addProperty("xpath", ConditionType.EQUALS, businessDayInput)

		WebUI.verifyElementPresent(checkedItemObject, 0)
		def checked = WebUI.verifyElementChecked(checkedItemObject, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			//scrollAdjusted.scrollIntoElementWithOffset(checkedItemObject, 100)
			WebUI.check(checkedItemObject)
			WebUI.verifyElementChecked(checkedItemObject, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}

		WebUI.verifyElementPresent(startTimeInputObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(startTimeInputObject, 0, 50)
		WebUI.click(startTimeInputObject)
		newKeys.handleInput(startTimeInputObject, "Keys.CONTROL, a")
		newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		String startTimeHour = startTime.substring(0, startTime.indexOf(":")+1)
		String startTimeMin = startTime.split(":")[1]
		WebUI.setText(startTimeInputObject, startTimeHour)
		newKeys.handleInput(startTimeInputObject, startTimeMin)
		newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(startTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(startTimeInputObject, "Keys.BACKSPACE")
		newKeys.handleInput(startTimeInputObject, "Keys.ENTER")

		WebUI.verifyElementPresent(endTimeInputObject,0)
		scrollAdjusted.scrollIntoElementWithOffset(endTimeInputObject, 0, 50)
		WebUI.click(endTimeInputObject)
		WebUI.click(startTimeInputObject)
		newKeys.handleInput(endTimeInputObject, "Keys.CONTROL, a")
		newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")
		String endTimeHour = endTime.substring(0, endTime.indexOf(":")+1)
		String endTimeMin = endTime.split(":")[1]
		WebUI.setText(endTimeInputObject, endTimeHour)
		newKeys.handleInput(endTimeInputObject, endTimeMin)
		newKeys.handleInput(endTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(endTimeInputObject, "Keys.ARROW LEFT")
		newKeys.handleInput(endTimeInputObject, "Keys.BACKSPACE")
		newKeys.handleInput(endTimeInputObject, "Keys.ENTER")

		WebUI.verifyElementPresent(businessDayInputObject, 0)
		def checkedBusinessDay = WebUI.verifyElementChecked(businessDayInputObject, 0, FailureHandling.OPTIONAL)
		if(checkedBusinessDay.equals(false) && businessDay.equals("true")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.check(businessDayInputObject)
			WebUI.verifyElementChecked(businessDayInputObject, 0)
			WebUI.comment("successfully check business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("false")){
			scrollAdjusted.scrollIntoElementWithOffset(businessDayInputObject, 100)
			WebUI.uncheck(businessDayInputObject)
			WebUI.verifyElementNotChecked(businessDayInputObject, 0)
			WebUI.comment("successfully uncheck business day checkbox on targeted row")
		}else if(checkedBusinessDay.equals(true) && businessDay.equals("true")){
			WebUI.comment("checkbox on targeted row have been checked")
		}else if(checkedBusinessDay.equals(false) && businessDay.equals("false")){
			WebUI.comment("checkbox on targeted row have been unchecked")
		}
	}

	@Keyword
	def verifyDetailActionResultScreenPendingTask(String successMSG, String menu, String actionValue, String userID, String rejectReason = ""){
		String successMessage = "//div[@role='alert' and contains(@class, 't-msg-success')]//div[@class='ant-alert-message']"

		String detailActionMenu = "//div[@id='t-Workflow-success']//div[@id='t-data-renderer-menu-value']"

		String detailActionActivity = "//div[@id='t-Workflow-success']//div[@id='t-data-renderer-action-value']"

		String detailActionCreatedBy = "//div[@id='t-Workflow-success']//div[@id='t-data-renderer-createdByUserId-value']"

		String detailActionRejectReason = "//div[@id='t-Workflow-success']//div[@id='t-data-renderer-reason-value']"

		TestObject successMessageObject = new TestObject()
		successMessageObject.addProperty("xpath", ConditionType.EQUALS, successMessage)

		TestObject detailActionMenuObject = new TestObject()
		detailActionMenuObject.addProperty("xpath", ConditionType.EQUALS, detailActionMenu)

		TestObject detailActionActivityObject = new TestObject()
		detailActionActivityObject.addProperty("xpath", ConditionType.EQUALS, detailActionActivity)

		TestObject detailActionCreatedByObject = new TestObject()
		detailActionCreatedByObject.addProperty("xpath", ConditionType.EQUALS, detailActionCreatedBy)

		TestObject detailActionRejectReasonObject = new TestObject()
		detailActionRejectReasonObject.addProperty("xpath", ConditionType.EQUALS, detailActionRejectReason)

		WebUI.verifyElementPresent(successMessageObject, 0)
		WebUI.verifyElementText(successMessageObject, successMSG)
		WebUI.comment("success message displayed having correct value")

		WebUI.verifyElementPresent(detailActionMenuObject, 0)
		WebUI.verifyElementText(detailActionMenuObject, menu)
		WebUI.comment("menu displayed having correct value")

		WebUI.verifyElementPresent(detailActionActivityObject, 0)
		WebUI.verifyElementText(detailActionActivityObject, actionValue)
		WebUI.comment("action displayed having correct value")

		WebUI.verifyElementPresent(detailActionCreatedByObject, 0)
		WebUI.verifyElementText(detailActionCreatedByObject, userID)
		WebUI.comment("created by / user ID displayed having correct value")

		if(!rejectReason.equals("")){
			WebUI.verifyElementPresent(detailActionRejectReasonObject, 0)
			WebUI.verifyElementText(detailActionRejectReasonObject, rejectReason)
			WebUI.comment("reject reason message displayed having correct value")
		}


	}

	@Keyword
	def getChargeDataCustomPackage(){

		WebDriver driver = DriverFactory.getWebDriver()

		ScrollElement scrollAdjusted = new ScrollElement()

		String sectionPaths = "//div[@id='t-TabForm-panel-charge']//div[@role='separator']"
		int sectionsTotal

		List<HashMap<String, List<HashMap<String, List<String>>>>> chargeTableData = new ArrayList<HashMap<String, List<HashMap<String, List<String>>>>>();

		//counting section(s)
		try {

			WebElement temp = driver.findElement(By.xpath(sectionPaths))
			List list = temp.findElements(By.xpath(sectionPaths))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of sections: "+list.size())
			WebUI.switchToDefaultContent()
			sectionsTotal = list.size()
			HashMap<String, List<HashMap<String, List<String>>>> chargeTableSectionData = new HashMap<String, List<HashMap<String, List<String>>>>();

			for(int i = 1; i <= sectionsTotal ;i++){
				String currentSection = "//div[@id='t-TabForm-panel-charge']//div[contains(@class, 'WorkflowSection-container')][$i]//div[@role='separator']"

				String currentSectionName = currentSection + "//span"
				TestObject sectionNameObject = new TestObject()
				sectionNameObject.addProperty("xpath", ConditionType.EQUALS, currentSectionName)
				String sectionName = WebUI.getText(sectionNameObject)
				WebUI.comment(sectionName)

				List<HashMap<String, List<String>>> sectionsData = new ArrayList<HashMap<String, List<String>>>();
				String columnPaths = currentSection+"/following-sibling::div//thead//tr//th//span[1][not(.//span)]"
				int headerColumnsTotal
				//counting current sections header total column(s)
				try {
					WebElement tempCol = driver.findElement(By.xpath(columnPaths))
					List listCol = tempCol.findElements(By.xpath(columnPaths))
					KeywordUtil.logInfo("success")
					KeywordUtil.logInfo("total number of columns: "+listCol.size())
					WebUI.switchToDefaultContent()
					headerColumnsTotal = listCol.size()
				} catch (Exception e) {
					KeywordUtil.logInfo("total number of colums: 0")
					headerColumnsTotal = 0
				}
				//initialize map rowCollection for storing row category (header or data row) and values
				HashMap<String,List<String>> rowCollection = new HashMap<String, List<String>>();
				//initialize list rowHeaderValues to contain header values
				List rowHeaderValues = new ArrayList<String>();
				//get current header values
				for(int h=1; h<= headerColumnsTotal; h++){

					String currentHeader = currentSection + "/following-sibling::div//thead//tr//th[$h]//span[1][not(.//span)]"
					WebUI.comment(currentHeader)
					TestObject currentCell = new TestObject()
					currentCell.addProperty("xpath", ConditionType.EQUALS, currentHeader)

					WebUI.verifyElementPresent(currentCell, 0)

					if(!WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL)){
						scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
						WebUI.switchToDefaultContent()
						String valueGetted = WebUI.getText(currentCell)
						WebUI.comment("successfully get header no $h column value: $valueGetted, type: text")
						rowHeaderValues.add(valueGetted)
					}else {
						scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
						WebUI.switchToDefaultContent()
						String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("successfully get header no $h column value: $currElementClassValue, type: class from object")
						rowHeaderValues.add(currElementClassValue)
					}
				}
				//add header row values
				rowCollection.put("header", rowHeaderValues)
				String rowPaths = currentSection+"/following-sibling::div//tr[@record]"
				int rowsTotal
				//counting current section total rows
				try {
					WebElement tempRow = driver.findElement(By.xpath(columnPaths))
					List listRow = tempRow.findElements(By.xpath(columnPaths))
					KeywordUtil.logInfo("success")
					KeywordUtil.logInfo("total number of rows: "+listRow.size())
					WebUI.switchToDefaultContent()
					rowsTotal = listRow.size()
				} catch (Exception e) {
					KeywordUtil.logInfo("total number of rows: 0")
					rowsTotal = 0
				}

				for(int r = 1; r <= rowsTotal; r++){
					String currentRow = rowPaths + "[$r]//td"
					List rowDataValues = new ArrayList<String>();
					int columnsTotal
					//counting current sections header total column(s)
					try {
						WebElement tempCol = driver.findElement(By.xpath(currentRow))
						List listCol = tempCol.findElements(By.xpath(currentRow))
						KeywordUtil.logInfo("success")
						KeywordUtil.logInfo("total number of columns: "+listCol.size())
						WebUI.switchToDefaultContent()
						columnsTotal = listCol.size()
					} catch (Exception e) {
						KeywordUtil.logInfo("total number of colums: 0")
						columnsTotal = 0
					}
					for(int c=1; c<= columnsTotal; c++){
						boolean checkedRow = false
						String currentCellPath = currentRow + "[$c]//span"

						TestObject currentCell = new TestObject()
						currentCell.addProperty("xpath", ConditionType.EQUALS, currentCellPath)

						String currentCellPath2 = currentRow + "[$c]"

						TestObject currentCell2 = new TestObject()
						currentCell2.addProperty("xpath", ConditionType.EQUALS, currentCellPath2)

						if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
							if(WebUI.verifyElementPresent(currentCell2, 0)){
								currentCell.addProperty("xpath", ConditionType.EQUALS, currentCellPath2)
							}
						}

						if(!WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String valueGetted = WebUI.getText(currentCell)
							WebUI.comment("successfully get datarow no $c column value: $valueGetted, type: text")
							rowDataValues.add(valueGetted)
						}else if(WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL) && checkedRow.equals(false)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
							if(currElementClassValue.equals("ant-checkbox ant-checkbox-checked") && c == 1){
								checkedRow = true
							}
							WebUI.comment("successfully get datarow no $c column value: $currElementClassValue, type: class from object")
							rowDataValues.add(currElementClassValue)
						}else if(WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL) && checkedRow.equals(true)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
							if(currElementClassValue.equals("ant-checkbox ant-checkbox-checked") && c != 1){
								WebUI.comment("successfully get datarow no $c column value: $currElementClassValue, type: class from object")
								rowDataValues.add(currElementClassValue)
							}else{
								String valueGetted = WebUI.getText(currentCell)
								WebUI.comment("successfully get datarow no $c column value: $valueGetted, type: text")
								rowDataValues.add(valueGetted)
							}

						}
					}
					rowCollection.put("datarow$r", rowDataValues)
				}
				sectionsData.add(rowCollection)
				chargeTableSectionData.put(sectionName, sectionsData)
				chargeTableData.add(chargeTableSectionData)
			}

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of sections: 0")
			sectionsTotal = 0
		}
		WebUI.comment("$chargeTableData")
		return chargeTableData

	}

	@Keyword
	def getLimitDataCustomPackage(){

		WebDriver driver = DriverFactory.getWebDriver()

		ScrollElement scrollAdjusted = new ScrollElement()

		String sectionPaths = "//div[@id='t-TabForm-panel-charge']//div[@role='separator']"
		int sectionsTotal

		List<HashMap<String, List<HashMap<String, List<String>>>>> chargeTableData = new ArrayList<HashMap<String, List<HashMap<String, List<String>>>>>();

		//counting section(s)
		try {

			WebElement temp = driver.findElement(By.xpath(sectionPaths))
			List list = temp.findElements(By.xpath(sectionPaths))
			KeywordUtil.logInfo("success")
			KeywordUtil.logInfo("total number of sections: "+list.size())
			WebUI.switchToDefaultContent()
			sectionsTotal = list.size()
			HashMap<String, List<HashMap<String, List<String>>>> chargeTableSectionData = new HashMap<String, List<HashMap<String, List<String>>>>();

			for(int i = 1; i <= sectionsTotal ;i++){
				String currentSection = "//div[@id='t-TabForm-panel-limit']//div[contains(@class, 'WorkflowSection-container')][$i]//div[@role='separator']"

				String currentSectionName = currentSection + "//span"
				TestObject sectionNameObject = new TestObject()
				sectionNameObject.addProperty("xpath", ConditionType.EQUALS, currentSectionName)
				String sectionName = WebUI.getText(sectionNameObject)

				List<HashMap<String, List<String>>> sectionsData = new ArrayList<HashMap<String, List<String>>>();
				String columnPaths = currentSection+"/following-sibling::div//thead//tr//th//span[1][not(.//span)]"
				int headerColumnsTotal
				//counting current sections header total column(s)
				try {
					WebElement tempCol = driver.findElement(By.xpath(columnPaths))
					List listCol = tempCol.findElements(By.xpath(columnPaths))
					KeywordUtil.logInfo("success")
					KeywordUtil.logInfo("total number of columns: "+listCol.size())
					WebUI.switchToDefaultContent()
					headerColumnsTotal = listCol.size()
				} catch (Exception e) {
					KeywordUtil.logInfo("total number of colums: 0")
					headerColumnsTotal = 0
				}
				//initialize map rowCollection for storing row category (header or data row) and values
				HashMap<String,List<String>> rowCollection = new HashMap<String, List<String>>();
				//initialize list rowHeaderValues to contain header values
				List rowHeaderValues = new ArrayList<String>();
				//get current header values
				for(int h=1; h<= headerColumnsTotal; h++){

					String currentHeader = currentSection + "/following-sibling::div//thead//tr//th[$h]//span[1][not(.//span)]"
					WebUI.comment(currentHeader)
					TestObject currentCell = new TestObject()
					currentCell.addProperty("xpath", ConditionType.EQUALS, currentHeader)

					WebUI.verifyElementPresent(currentCell, 0)

					if(!WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL)){
						scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
						WebUI.switchToDefaultContent()
						String valueGetted = WebUI.getText(currentCell)
						WebUI.comment("successfully get header no $h column value: $valueGetted, type: text")
						rowHeaderValues.add(valueGetted)
					}else {
						scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
						WebUI.switchToDefaultContent()
						String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
						WebUI.comment("successfully get header no $h column value: $currElementClassValue, type: class from object")
						rowHeaderValues.add(currElementClassValue)
					}
				}
				//add header row values
				rowCollection.put("header", rowHeaderValues)
				String rowPaths = currentSection+"/following-sibling::div//tr[@record]"
				int rowsTotal
				//counting current section total rows
				try {
					WebElement tempRow = driver.findElement(By.xpath(columnPaths))
					List listRow = tempRow.findElements(By.xpath(columnPaths))
					KeywordUtil.logInfo("success")
					KeywordUtil.logInfo("total number of rows: "+listRow.size())
					WebUI.switchToDefaultContent()
					rowsTotal = listRow.size()
				} catch (Exception e) {
					KeywordUtil.logInfo("total number of rows: 0")
					rowsTotal = 0
				}

				for(int r = 1; r <= rowsTotal; r++){
					String currentRow = rowPaths + "[$r]//td"
					List rowDataValues = new ArrayList<String>();
					int columnsTotal
					//counting current sections header total column(s)
					try {
						WebElement tempCol = driver.findElement(By.xpath(currentRow))
						List listCol = tempCol.findElements(By.xpath(currentRow))
						KeywordUtil.logInfo("success")
						KeywordUtil.logInfo("total number of columns: "+listCol.size())
						WebUI.switchToDefaultContent()
						columnsTotal = listCol.size()
					} catch (Exception e) {
						KeywordUtil.logInfo("total number of colums: 0")
						columnsTotal = 0
					}
					for(int c=1; c<= columnsTotal; c++){
						boolean checkedRow = false
						String currentCellPath = currentRow + "[$c]//span"

						TestObject currentCell = new TestObject()
						currentCell.addProperty("xpath", ConditionType.EQUALS, currentCellPath)

						String currentCellPath2 = currentRow + "[$c]"

						TestObject currentCell2 = new TestObject()
						currentCell2.addProperty("xpath", ConditionType.EQUALS, currentCellPath2)

						if(!WebUI.verifyElementPresent(currentCell, 0, FailureHandling.OPTIONAL)){
							if(WebUI.verifyElementPresent(currentCell2, 0)){
								currentCell.addProperty("xpath", ConditionType.EQUALS, currentCellPath2)
							}
						}

						if(!WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String valueGetted = WebUI.getText(currentCell)
							WebUI.comment("successfully get datarow no $c column value: $valueGetted, type: text")
							rowDataValues.add(valueGetted)
						}else if(WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL) && checkedRow.equals(false)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
							if(currElementClassValue.equals("ant-checkbox ant-checkbox-checked") && c == 1){
								checkedRow = true
							}
							WebUI.comment("successfully get datarow no $c column value: $currElementClassValue, type: class from object")
							rowDataValues.add(currElementClassValue)
						}else if(WebUI.getAttribute(currentCell, "class", FailureHandling.OPTIONAL) && checkedRow.equals(true)){
							scrollAdjusted.scrollIntoElementWithOffset(currentCell, 100)
							WebUI.switchToDefaultContent()
							String currElementClassValue = WebUI.getAttribute(currentCell, "class", FailureHandling.STOP_ON_FAILURE)
							if(currElementClassValue.equals("ant-checkbox ant-checkbox-checked") && c != 1){
								WebUI.comment("successfully get datarow no $c column value: $currElementClassValue, type: class from object")
								rowDataValues.add(currElementClassValue)
							}else{
								String valueGetted = WebUI.getText(currentCell)
								WebUI.comment("successfully get datarow no $c column value: $valueGetted, type: text")
								rowDataValues.add(valueGetted)
							}

						}
					}
					rowCollection.put("datarow$r", rowHeaderValues)
				}
				sectionsData.add(rowCollection)
				chargeTableSectionData.put(sectionName, sectionsData)
				chargeTableData.add(chargeTableSectionData)
			}

		} catch (Exception e) {
			KeywordUtil.logInfo("total number of sections: 0")
			sectionsTotal = 0
		}
		WebUI.comment("$chargeTableData")
		return chargeTableData

	}



	@Keyword
	def verifyBankLimitTransactionExceedingLength(String product, String menu = "", String currencyMatrix, String minLimit ="", String maxLimit=""){

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath
		if(menu.equals("")){
			xpath = '//tr[.//td//span[text() = "'+product+'"]]/following-sibling::tr[./td/span[text()="'+currencyMatrix+'"]][1] '
		}else{
			xpath = '//tr[.//td//span[text() = "'+product+'" and .//td//span[text()="'+menu+'"]]]/following-sibling::tr[./td/span[text()="'+currencyMatrix+'"]][1]'
		}

		println xpath
		String checkboxRow = xpath +'//input[@type="checkbox"]'

		SendKeys newKeys = new SendKeys();

		if(minLimit.equals("yes")){

			String minimumLimitError = xpath + "//td//span[contains(@id, 't-error-minimum_trx_limit')]"
			TestObject minimumLimitErrorObject = new TestObject()
			minimumLimitErrorObject.addProperty("xpath", ConditionType.EQUALS, minimumLimitError)
			scrollAdjusted.scrollIntoElementWithOffset(minimumLimitErrorObject, 100)

			WebUI.verifyElementText(minimumLimitErrorObject, "The entry must contain max 16 digits with 2 decimal numbers")
			WebUI.comment("successfully verify minimum transaction limit having error message: The entry must contain max 16 digits with 2 decimal numbers")
		}

		if(maxLimit.equals("yes")){


			String maximumLimitError = xpath + "//td//span[contains(@id, 't-error-maximum_trx_limit')]"
			TestObject maximumLimitErrorObject = new TestObject()
			maximumLimitErrorObject.addProperty("xpath", ConditionType.EQUALS, maximumLimitError)

			scrollAdjusted.scrollIntoElementWithOffset(maximumLimitErrorObject, 100)

			WebUI.verifyElementText(maximumLimitErrorObject, "The entry must contain max 16 digits with 2 decimal numbers")
			WebUI.comment("successfully verify maximum transaction limit having error message: The entry must contain max 16 digits with 2 decimal numbers")

		}

	}

	def convertMonth(String dt) {
		if (dt.contains("Jan")) {
			dt = dt.replace("Januari", "January");
		} else if (dt.contains("Feb")) {
			dt = dt.replace("Februari", "February");
		} else if (dt.contains("Mar")) {
			dt = dt.replace("Maret", "March");
		} else if (dt.contains("Apr")) {
			dt = dt.replace("April", "April");
		} else if (dt.contains("Mei")) {
			dt = dt.replace("Mei", "May");
		} else if (dt.contains("Jun")) {
			dt = dt.replace("Juni", "June");
		} else if (dt.contains("Jul")) {
			dt = dt.replace("Juli", "July");
		} else if (dt.contains("Agu")) {
			dt = dt.replace("Agustus", "August");
		} else if (dt.contains("Sep")) {
			dt = dt.replace("September", "September");
		} else if (dt.contains("Okt")) {
			dt = dt.replace("Oktober", "October");
		} else if (dt.contains("Nov")) {
			dt = dt.replace("November", "November");
		} else if (dt.contains("Des")) {
			dt = dt.replace("Desember", "December");
		}
		return dt;
	}

	@Keyword
	def editRequestSellerFinancing(String ReferenceOreInvoiceNo, String drawdownPercentage = "", String loanAccountOwner = ""){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//tr[@data-row-key and .//td//*[text()="'+ReferenceOreInvoiceNo+'"]]'


		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpathCheckBox = xpath + "//input[@type='checkbox']"

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.comment(xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(testObject, 500, 50)
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath loan account
		String loanAccountDropdownPath = xpath + "//span[@id='t-select-loanAccount-value']"
		String loanAccountSelectionPath = xpath + "//li[contains(@id, 't-loanAccount-option') and text()='"+loanAccountOwner+"']"

		//list xpath Drawdown Percentage input
		String DrawdownPercentagePath = xpath + "//input[@id='t-drawdownPercentage']"

		//list xpath button online balance
		String onlineBalancePath = xpath + "//button[@id='t-OnlineBalanceModal']"

		//list object currency
		TestObject loanAccountDropdownObject = new TestObject()
		TestObject loanAccountSelectionObject = new TestObject()
		loanAccountDropdownObject.addProperty("xpath", ConditionType.EQUALS, loanAccountDropdownPath)
		loanAccountSelectionObject.addProperty("xpath", ConditionType.EQUALS, loanAccountSelectionPath)

		//list object max no of transaction per day
		TestObject DrawdownPercentageObject = new TestObject()
		DrawdownPercentageObject.addProperty("xpath", ConditionType.EQUALS, DrawdownPercentagePath)

		//list object max amount transaction per day
		TestObject onlineBalancePathObject = new TestObject()
		onlineBalancePathObject.addProperty("xpath", ConditionType.EQUALS, onlineBalancePath)

		if(drawdownPercentage != "" || drawdownPercentage != '') {
			newKeys.handleInput(DrawdownPercentageObject, "Keys.CONTROL, a")
			newKeys.handleInput(DrawdownPercentageObject, "Keys.BACKSPACE")
			scrollAdjusted.scrollIntoElementWithOffset(DrawdownPercentageObject, 500,250)
			WebUI.setText(DrawdownPercentageObject, drawdownPercentage)
		}else if(drawdownPercentage.equals("null")) {
			newKeys.handleInput(DrawdownPercentageObject, "Keys.CONTROL, a")
			newKeys.handleInput(DrawdownPercentageObject, "Keys.BACKSPACE")
		}

		if(loanAccountOwner != "" || loanAccountOwner != '') {
			scrollAdjusted.scrollIntoElementWithOffset(loanAccountDropdownObject, 500,250)
			WebUI.click(loanAccountDropdownObject)

			scrollAdjusted.scrollIntoElementWithOffset(loanAccountSelectionObject, 500,250)
			WebUI.click(loanAccountSelectionObject)
		}

		scrollAdjusted.scrollIntoElementWithOffset(onlineBalancePathObject, 500,250)
		WebUI.click(onlineBalancePathObject)
	}

	@Keyword
	def editRequestSellerFinancingUsingRowNo(String rowNo, String drawdownPercentage = "", String loanAccountOwner = ""){

		SendKeys newKeys = new SendKeys();

		ScrollElement scrollAdjusted = new ScrollElement()

		String xpath = '//div[contains(@class, "SearchTable")]//tr[@data-row-key and contains(@class, "ant-table-row")]['+rowNo+']'

		TestObject currentCell = new TestObject()
		currentCell.addProperty("xpath", ConditionType.EQUALS, xpath)

		String xpathCheckBox = xpath + "//input[@type='checkbox']"

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpathCheckBox)
		WebUI.comment(xpathCheckBox)
		WebUI.verifyElementPresent(objectSpecifiList, 0)
		def checked = WebUI.verifyElementChecked(objectSpecifiList, 0, FailureHandling.OPTIONAL)
		if(checked.equals(false)){
			scrollAdjusted.scrollIntoElementWithOffset(testObject, 500, 50)
			WebUI.check(objectSpecifiList)
			WebUI.verifyElementChecked(objectSpecifiList, 0)
			WebUI.comment("successfully check checkbox on targeted row")
		}else{
			WebUI.comment("checkbox on targeted row have been checked")
		}
		//list xpath loan account
		String loanAccountDropdownPath = xpath + "//span[@id='t-select-loanAccount-value']"
		String loanAccountSelectionPath = xpath + "//li[contains(@id, 't-loanAccount-option') and text()='"+loanAccountOwner+"']"

		//list xpath Drawdown Percentage input
		String DrawdownPercentagePath = xpath + "//input[@id='t-drawdownPercentage']"

		//list xpath button online balance
		String onlineBalancePath = xpath + "//button[@id='t-OnlineBalanceModal']"

		//list object currency
		TestObject loanAccountDropdownObject = new TestObject()
		TestObject loanAccountSelectionObject = new TestObject()
		loanAccountDropdownObject.addProperty("xpath", ConditionType.EQUALS, loanAccountDropdownPath)
		loanAccountSelectionObject.addProperty("xpath", ConditionType.EQUALS, loanAccountSelectionPath)

		//list object max no of transaction per day
		TestObject DrawdownPercentageObject = new TestObject()
		DrawdownPercentageObject.addProperty("xpath", ConditionType.EQUALS, DrawdownPercentagePath)

		//list object max amount transaction per day
		TestObject onlineBalancePathObject = new TestObject()
		onlineBalancePathObject.addProperty("xpath", ConditionType.EQUALS, onlineBalancePath)

		if(drawdownPercentage != "" || drawdownPercentage != '') {
			newKeys.handleInput(DrawdownPercentageObject, "Keys.CONTROL, a")
			newKeys.handleInput(DrawdownPercentageObject, "Keys.BACKSPACE")
			scrollAdjusted.scrollIntoElementWithOffset(DrawdownPercentageObject, 500,250)
			WebUI.setText(DrawdownPercentageObject, drawdownPercentage)
		}else if(drawdownPercentage.equals("null")) {
			newKeys.handleInput(DrawdownPercentageObject, "Keys.CONTROL, a")
			newKeys.handleInput(DrawdownPercentageObject, "Keys.BACKSPACE")
		}
		if(loanAccountOwner != "" || loanAccountOwner != '') {
			scrollAdjusted.scrollIntoElementWithOffset(loanAccountDropdownObject, 500,250)
			WebUI.click(loanAccountDropdownObject)

			scrollAdjusted.scrollIntoElementWithOffset(loanAccountSelectionObject, 500,250)
			WebUI.click(loanAccountSelectionObject)
		}
		scrollAdjusted.scrollIntoElementWithOffset(onlineBalancePathObject, 500,250)
		WebUI.click(onlineBalancePathObject)
	}

	@Keyword
	def clickEditIconOnSpecificRowBasedOnRowNo(String rowNo){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]"
		xpath = xpath + "[$rowNo]" +"//*[contains(@id,'t-account-group-edit') or contains(@id,'t-edit') or contains(@href, 'domestic-bank/edit') or @aria-label = 'edit']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)

	}

	@Keyword
	def clickDeleteIconOnSpecificRowBasedOnRowNo(String rowNo){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		String temp = ""
		String xpath = "//tr[@data-row-key]"
		xpath = xpath + "[$rowNo]" +"//a[contains(@href, 'delete')] | " + xpath + "]//button[@id='t-button-delete']"
		println xpath
		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.click(objectSpecifiList)



	}

	@Keyword
	def clickHyperLinkPendingTask(List<String> data, String hyperlinkName, FailureHandling handler = FailureHandling.STOP_ON_FAILURE){
		//**example:
		//CustomKeywords.'handleWebTable.HTMLTableHelper.checkOnSpecificRow'(['ABCD130', 'RINDA SETYAWATI edit'])
		//***

		ClickUsingJS clickJS = new ClickUsingJS()
		String temp = ""
		String xpath = "//tr[@data-row-key]["
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			if(i != data.size()-1){
				temp = 'contains(.,"'+value+'") and '
			}else{
				temp = 'contains(.,"'+value+'")'
			}
			xpath = xpath + temp
		}
		String finalXpath = xpath + ']//a[contains(.,"'+hyperlinkName+'")]'
		String xpath2 = xpath + ']//span[contains(.,"'+hyperlinkName+'")]'
		finalXpath = finalXpath + " | " + xpath2
		println xpath
		KeywordUtil.logInfo(xpath)

		TestObject testObject = new TestObject()
		def objectSpecifiList = testObject.addProperty("xpath", ConditionType.EQUALS, finalXpath)

		String buttonNextPage = "//*[@id='t-pagination-next' or @id='t-SearchPagePagination-next']"
		TestObject nextButton = new TestObject()
		def objectNextButton = nextButton.addProperty("xpath", ConditionType.EQUALS, buttonNextPage)

		for(int i = 0; i < 15; i++){
			if(WebUI.verifyElementNotPresent(objectSpecifiList, 0, FailureHandling.OPTIONAL).equals(false)){
				clickJS.ClickUsingJavaScript(objectSpecifiList, 0)
				break
			}else{
				WebUI.click(objectNextButton)
				WebUI.delay(5)
			}}

	}

	@Keyword
	def getDataAllRow(int column, int Row) {
		String xpathRow = "//tr[@data-row-key]";
		String xpathRow2 = xpathRow + "[$Row]";

		def data = []
		//List<String> data

		for(int i= 1; i<= column; i++){
			String getDataCol = xpathRow2+"//td[$i]//div"
			TestObject dataCol = new TestObject()
			dataCol.addProperty("xpath", ConditionType.EQUALS, getDataCol)

			def dataTabel = WebUI.getText(dataCol)
			//data.add(dataCol)
			data.push(dataTabel)
		}
		return data;
	}

}
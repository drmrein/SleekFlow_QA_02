package textProcessor

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import com.kms.katalon.core.testdata.TestData as TestData

public class processText {


	@Keyword
	def removeText(String data, TestObject textobject){

		WebUI.waitForElementVisible(textobject, 60)

		String textCurrent = WebUI.getText(textobject)
		KeywordUtil.logInfo(textCurrent)
		int dataLength = data.length()
		if(data.equals("trim current text")){
			textCurrent = textCurrent.trim()
		}else{
			textCurrent = textCurrent.replace(data, "").trim()
		}

		KeywordUtil.logInfo(textCurrent)

		return textCurrent
	}

	@Keyword
	def removeTextAndReturnInteger(String data1, String data2, TestObject textobject){

		String textCurrent = WebUI.getText(textobject)

		int dataLength = data1.length()
		if(data1.equals("trim current text")){
			textCurrent = textCurrent.trim()
		}else{
			textCurrent = textCurrent.substring(textCurrent.indexOf(data1)+dataLength, textCurrent.indexOf(data2)).trim()
			textCurrent = Integer.parseInt(textCurrent)
		}

		KeywordUtil.logInfo(textCurrent)

		return textCurrent
	}

	@Keyword
	def substringTextUsingStringasIndex(String status, String data, TestObject textobject){

		String textCurrent = WebUI.getText(textobject)

		int dataLength = data.length()
		if(status.equalsIgnoreCase("after")){
			textCurrent = textCurrent.substring(textCurrent.lastIndexOf(data)+dataLength).trim()
		}else if(status.equalsIgnoreCase("before")){
			textCurrent = textCurrent.substring(0, textCurrent.lastIndexOf(data)).trim()
		}

		KeywordUtil.logInfo(textCurrent)

		return textCurrent
	}

	@Keyword
	def substringTextBetweenStringIndex(String data, String data2, TestObject textobject){

		String textCurrent = WebUI.getText(textobject)

		int dataLength = data.length()

		textCurrent = textCurrent.substring(textCurrent.indexOf(data)+dataLength, textCurrent.lastIndexOf(data2)).trim()

		KeywordUtil.logInfo(textCurrent)

		return textCurrent
	}

	@Keyword
	def formatPendingTaskSubHeader(String menu, String action){

		String create = GlobalVariable.Create
		String update = GlobalVariable.Update
		String delete = GlobalVariable.Delete
		String actionx

		if(action == create){
			actionx = findTestData('Data Files/FrontEnd/FO_CA_CU/Test Data Global/Test Data LabelGlobal').getValue('A_Label', 20)
		} else if (action == update){
			actionx = findTestData('Data Files/FrontEnd/FO_CA_CU/Test Data Global/Test Data LabelGlobal').getValue('E_Label', 3)
		} else if (action == delete){
			actionx = findTestData('Data Files/FrontEnd/FO_CA_CU/Test Data Global/Test Data LabelGlobal').getValue('D_Label', 6)
		}

		String subHeader = "$actionx" + " " + "$menu"

		KeywordUtil.logInfo(subHeader)

		return subHeader
	}

	@Keyword
	def concatenate(List<String> data){

		String result = ""
		String value
		for(int i= 0; i< data.size(); i++){
			value = data.get(i)
			result = result + value
		}
		KeywordUtil.logInfo(result)
		return result
	}

	@Keyword
	def removeTextFromText(String data, String textCurrent){

		KeywordUtil.logInfo(textCurrent)
		int dataLength = data.length()
		if(data.equals("trim current text")){
			textCurrent = textCurrent.trim()
		}else{
			textCurrent = textCurrent.replace(data, "").trim()
		}

		KeywordUtil.logInfo(textCurrent)

		return textCurrent
	}
}

package keys

import org.apache.commons.lang.RandomStringUtils

import com.kms.katalon.core.annotation.Keyword

public class RandomNumber {
	
	@Keyword
	def generateRandomNumber(int length){

		def randomValue =RandomStringUtils.randomNumeric(length)
		//keys.SetTextHandler.handleInput(objectPath, randomValue)
		return randomValue
	}
}

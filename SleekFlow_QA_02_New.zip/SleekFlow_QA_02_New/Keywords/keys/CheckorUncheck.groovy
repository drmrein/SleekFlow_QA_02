package keys
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

class CheckorUncheck {

	@Keyword
	def unCheckUsingCustomKeyword(TestObject testobject) {
		boolean checked = WebUI.verifyElementChecked(testobject, 0, FailureHandling.OPTIONAL)
		def click = new ClickUsingJS()


		if (checked) {
			def test = true
			while(test == true){
				try{

					WebUI.uncheck(testobject)
					KeywordUtil.logInfo("Success Check using WebUI.check")
					break
				}catch(Exception e){
					KeywordUtil.logInfo("Failed Check using WebUI.check")
				}

				try{
					click.ClickUsingJavaScript(testobject, 0)
					KeywordUtil.logInfo("Success Check using clickJS")
					break
				}catch(Exception e){
					test == false
					KeywordUtil.logInfo("Failed Check using clickJS")
				}
			}
			if(test == false){
				WebUI.verifyEqual("Pass", "False")
			}
		}
		KeywordUtil.logInfo("Already UnChecked")
	}
	@Keyword
	def CheckUsingCustomKeyword(TestObject testobject) {
		boolean checked = WebUI.verifyElementNotChecked(testobject, 0, FailureHandling.OPTIONAL)
		def click = new ClickUsingJS()

		if (checked) {
			def test = true
			while(test == true){
				try{

					WebUI.check(testobject)
					KeywordUtil.logInfo("Success Check using WebUI.check")
					break
				}catch(Exception e){
					KeywordUtil.logInfo("Failed Check using WebUI.check")
				}

				try{
					click.ClickUsingJavaScript(testobject, 0)
					KeywordUtil.logInfo("Success Check using clickJS")
					break
				}catch(Exception e){
					test == false
					KeywordUtil.logInfo("Failed Check using clickJS")
				}
			}
			if(test == false){
				WebUI.verifyEqual("Pass", "False")
			}
		}
		KeywordUtil.logInfo("Already Checked")
	}
}
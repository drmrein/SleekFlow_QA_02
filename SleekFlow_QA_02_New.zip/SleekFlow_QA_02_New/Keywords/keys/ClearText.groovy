package keys
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.Keys

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


class ClearText {
	
	@Keyword
	def clearText(TestObject testObject) {
		try {
			WebUI.clearText(testObject)
			WebUI.verifyElementAttributeValue(testObject, 'value', '', 0)
			println "use clearText"
			
		} catch (Exception e) {
			WebUI.sendKeys(testObject, Keys.chord(Keys.CONTROL, 'a', Keys.BACK_SPACE))
			
			WebUI.verifyElementAttributeValue(testObject, 'value', '', 0)
			println "use sendKeys"
		}
	}

}
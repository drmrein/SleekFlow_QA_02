package keys

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class Calendar {
	@Keyword
	def selectCalendar(TestObject calendarField,String targetDate ){
		//targetDate format example: 01/Jan/2019
		WebUI.delay(2)
		WebUI.click(calendarField)

		def todayMonth = new Date().format( 'MM' )

		def map = ["01": "January", "02": "February", "03": "March","04": "April", "05": "May", "06": "June","07": "July",
			"08": "August", "09": "September","10": "October", "11": "November", "12": "December"]

		TestObject headerYearMonth = new TestObject()

		TestObject headerYear = new TestObject()

		TestObject selectedYear = new TestObject()

		TestObject selectedMonth = new TestObject()

		TestObject selectedDate = new TestObject()

		def currYear = new Date().format( 'yyyy' )

		println(currYear)

		def currMonth = map.get(todayMonth)

		println(currMonth)

		def targetYear = targetDate.split("/")[2].trim()

		println(targetYear)

		def targetMonth = targetDate.split("/")[1].trim()

		println(targetMonth)

		def targetDay = targetDate.split("/")[0].trim()

		println(targetDay)

		def currYearAndMonth = ((currMonth + ' ') + currYear)

		headerYearMonth.addProperty('xpath', ConditionType.EQUALS, ('//span[contains(.,"' + currYearAndMonth) + '")]')

		headerYear.addProperty('xpath', ConditionType.EQUALS, ('//span[contains(.,' + currYear) + ')]')

		selectedYear.addProperty('xpath', ConditionType.EQUALS, ('//td[text()=' + targetYear) + ']' //td[text()="2020"]
				)

		selectedMonth.addProperty('xpath', ConditionType.EQUALS, ('//td[text()="' + targetMonth) + '"]' //td[text()="Oct"]
				)

		selectedDate.addProperty('xpath', ConditionType.EQUALS, ('//td[@data-isdisabled="false"][text()=' + targetDay) + ']' //td[@data-isdisabled="false"][text()="1"]
				)

		WebUI.click(headerYearMonth)

		WebUI.click(headerYear)

		WebUI.click(selectedYear)

		WebUI.click(selectedMonth)

		WebUI.click(selectedDate)

	}
}

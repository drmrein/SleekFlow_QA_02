package keys
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


class Uncheck {

	@Keyword
	def unCheckUsingCustomKeyword(TestObject testobject) {
		boolean checked = WebUI.verifyElementChecked(testobject, 0, FailureHandling.OPTIONAL)
		def click = new ClickUsingJS()
		
		if (checked) {
			click.ClickUsingJavaScript(testobject, 0)
		}
	}
}
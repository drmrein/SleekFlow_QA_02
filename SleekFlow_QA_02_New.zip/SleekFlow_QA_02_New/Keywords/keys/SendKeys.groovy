package keys

import org.openqa.selenium.Keys

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class SendKeys {

	@Keyword
	def handleInput(TestObject objectPath, String inputValue){
		try{
			def tempValue = null
			try {
				String[] splittedValue = inputValue.split(",")
				HashMap<Keys, String> keysCollection = new HashMap<Keys, String>();
				HashMap<String, String> inputCollection = new HashMap<Keys, String>();
				def valueSequence
				for(int i = 0; i< splittedValue.size(); i++){
					String currentValue = splittedValue[i].trim()
					tempValue = currentValue
					if(currentValue.contains("Keys.")){
						Keys currentKey = checkKeys(objectPath, currentValue.replace("Keys.", ""))
						KeywordUtil.logInfo("Success send keys for value $currentKey" )
						keysCollection.put(currentKey, i)
						if(i == 0){
							valueSequence = currentKey
						}else{
							valueSequence = valueSequence + "," + currentKey						
						}
					}else{
						inputCollection.put(currentValue, i)
						if(i == 0){
							valueSequence = currentValue
						}else{
							valueSequence = valueSequence + "," + currentValue
						}
					}
					
				}
				WebUI.sendKeys(objectPath, Keys.chord(valueSequence))
			} catch (Exception e) {
				KeywordUtil.markFailedAndStop("Failed send keys for value " + inputValue)
			}
		}catch(Exception e){
			KeywordUtil.markFailedAndStop("Failed send keys")
		}
	}

	def checkKeys(TestObject objectPath, String inputKeys){
		Keys result
		if(inputKeys.equals("NULL")){
			result = Keys.NULL
		}else if(inputKeys.equals("CONTROL")){
			result = Keys.CONTROL
		}else if(inputKeys.equals("BACKSPACE")){
			result = Keys.BACK_SPACE
		}else if(inputKeys.equals("ARROW DOWN")){
			result = Keys.ARROW_DOWN
		}else if(inputKeys.equals("ALT")){
			result = Keys.ALT
		}else if(inputKeys.equals("ADD")){
			result = Keys.ADD
		}else if(inputKeys.equals("ARROW LEFT")){
			result = Keys.ARROW_LEFT
		}else if(inputKeys.equals("ARROW RIGHT")){
			result = Keys.ARROW_RIGHT
		}else if(inputKeys.equals("ARROW UP")){
			result = Keys.ARROW_UP
		}else if(inputKeys.equals("CANCEL")){
			result = Keys.CANCEL
		}else if(inputKeys.equals("CLEAR")){
			result = Keys.CLEAR
		}else if(inputKeys.equals("COMMAND")){
			result = Keys.COMMAND
		}else if(inputKeys.equals("DELETE")){
			result = Keys.DELETE
		}else if(inputKeys.equals("DECIMAL")){
			result = Keys.DECIMAL
		}else if(inputKeys.equals("DIVIDE")){
			result = Keys.DIVIDE
		}else if(inputKeys.equals("DOWN")){
			result = Keys.DOWN
		}else if(inputKeys.equals("END")){
			result = Keys.END
		}else if(inputKeys.equals("ENTER")){
			result = Keys.ENTER
		}else if(inputKeys.equals("EQUALS")){
			result = Keys.EQUALS
		}else if(inputKeys.equals("ESCAPE")){
			result = Keys.ESCAPE
		}else if(inputKeys.equals("F1")){
			result = Keys.F1
		}else if(inputKeys.equals("F2")){
			result = Keys.F2
		}else if(inputKeys.equals("F3")){
			result = Keys.F3
		}else if(inputKeys.equals("F4")){
			result = Keys.F4
		}else if(inputKeys.equals("F5")){
			result = Keys.F5
		}else if(inputKeys.equals("F6")){
			result = Keys.F6
		}else if(inputKeys.equals("F7")){
			result = Keys.F7
		}else if(inputKeys.equals("F8")){
			result = Keys.F8
		}else if(inputKeys.equals("F9")){
			result = Keys.F9
		}else if(inputKeys.equals("F10")){
			result = Keys.F10
		}else if(inputKeys.equals("F11")){
			result = Keys.F11
		}else if(inputKeys.equals("F12")){
			result = Keys.F12
		}else if(inputKeys.equals("HELP")){
			result = Keys.HELP
		}else if(inputKeys.equals("HOME")){
			result = Keys.HOME
		}else if(inputKeys.equals("INSERT")){
			result = Keys.INSERT
		}else if(inputKeys.equals("LEFT")){
			result = Keys.LEFT
		}else if(inputKeys.equals("LEFT ALT")){
			result = Keys.LEFT_ALT
		}else if(inputKeys.equals("LEFT CONTROL")){
			result = Keys.LEFT_CONTROL
		}else if(inputKeys.equals("LEFT SHIFT")){
			result = Keys.LEFT_SHIFT
		}else if(inputKeys.equals("META")){
			result = Keys.META
		}else if(inputKeys.equals("MULTIPLY")){
			result = Keys.MULTIPLY
		}else if(inputKeys.equals("NUMPAD 1")){
			result = Keys.NUMPAD1
		}else if(inputKeys.equals("NUMPAD 2")){
			result = Keys.NUMPAD2
		}else if(inputKeys.equals("NUMPAD 3")){
			result = Keys.NUMPAD3
		}else if(inputKeys.equals("NUMPAD 4")){
			result = Keys.NUMPAD4
		}else if(inputKeys.equals("NUMPAD 5")){
			result = Keys.NUMPAD5
		}else if(inputKeys.equals("NUMPAD 6")){
			result = Keys.NUMPAD6
		}else if(inputKeys.equals("NUMPAD 7")){
			result = Keys.NUMPAD7
		}else if(inputKeys.equals("NUMPAD 8")){
			result = Keys.NUMPAD8
		}else if(inputKeys.equals("NUMPAD 9")){
			result = Keys.NUMPAD9
		}else if(inputKeys.equals("PAGE UP")){
			result = Keys.PAGE_UP
		}else if(inputKeys.equals("PAGE DOWN")){
			result = Keys.PAGE_DOWN
		}else if(inputKeys.equals("PAUSE")){
			result = Keys.PAUSE
		}else if(inputKeys.equals("RETURN")){
			result = Keys.RETURN
		}else if(inputKeys.equals("RIGHT")){
			result = Keys.RIGHT
		}else if(inputKeys.equals("SEMICOLON")){
			result = Keys.SEMICOLON
		}else if(inputKeys.equals("SEPARATOR")){
			result = Keys.SEPARATOR
		}else if(inputKeys.equals("SHIFT")){
			result = Keys.SHIFT
		}else if(inputKeys.equals("SUBSTRACT")){
			result = Keys.SUBSTRACT
		}else if(inputKeys.equals("TAB")){
			result = Keys.TAB
		}else if(inputKeys.equals("UP")){
			result = Keys.UP
		}else if(inputKeys.equals("ZENKAKU HANKAKU")){
			result = Keys.ZENKAKU_HANKAKU
		}
		return result
	}
}

package keys

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class transactionRate {

	@Keyword
	def verifyEquivalent(){
		String rate = "//div[@class='counter-rate-info']//p[@ng-hide='model.forex.isCrossForex']//strong"

		TestObject testObject = new TestObject()
		def objectrate= testObject.addProperty("xpath", ConditionType.EQUALS, rate)

		String inputAmount = "//input[@name = 'inputForexAmount']"

		TestObject testInput = new TestObject()
		def objectInput = testInput.addProperty("xpath", ConditionType.EQUALS, inputAmount)

		String equivalent = "//input[@data-ng-model = 'model.forex.resultDisplay']"

		TestObject testEquivalent = new TestObject()
		def objectEquivalent = testEquivalent.addProperty("xpath", ConditionType.EQUALS, equivalent)

		WebUI.verifyElementPresent(objectrate, 0)

		def currentRate = WebUI.getText(objectrate)

		currentRate = currentRate.substring(currentRate.indexOf(" ")).trim()

		WebUI.comment(currentRate)

		def currentInput = WebUI.getAttribute(testInput, "value").trim()

		WebUI.comment(currentInput)

		def calculatedEquiv = Double.valueOf(currentInput) * Double.valueOf(currentRate)

		calculatedEquiv = String.valueOf(calculatedEquiv.round(2))

		WebUI.comment(calculatedEquiv)

		def currentEquiv = WebUI.getAttribute(objectEquivalent, "value").trim()

		if(WebUI.verifyEqual(calculatedEquiv, currentEquiv)){
			WebUI.comment("Equivalent value correct")
		}
	}

	@Keyword
	def getLocalSpecialRate(String foreignCurrency, String anotherCurrency, String targetStatus){

		TestObject pr = new TestObject()

		TestObject pr2 = new TestObject()

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String chosenCurrency = "//div[@class='select2-result-label' and contains(.,'$foreignCurrency')]"

		TestObject testObject = new TestObject()
		def objectrate= testObject.addProperty("xpath", ConditionType.EQUALS, chosenCurrency)

		testObject.setParentObject(pr2)

		String inputAmount = "//div[@id='s2id_currency']"

		TestObject testInput = new TestObject()
		def objectInput = testInput.addProperty("xpath", ConditionType.EQUALS, inputAmount)

		testInput.setParentObject(pr2)

		String searchBox = "//div[@id='select2-drop']//input"

		TestObject testEquivalent = new TestObject()
		def objectEquivalent = testEquivalent.addProperty("xpath", ConditionType.EQUALS, searchBox)

		testEquivalent.setParentObject(pr2)

		String searchButton = "//button[@id='btnSearch']"

		TestObject testSearchBtn = new TestObject()
		def searchBtn = testSearchBtn.addProperty("xpath", ConditionType.EQUALS, searchButton)

		testSearchBtn.setParentObject(pr2)

		WebUI.callTestCase(findTestCase('FrontEnd/Step Group (Reusable Group)/accessLocalSpecialRateDB'), [:], FailureHandling.STOP_ON_FAILURE)

		WebUI.click(objectInput)

		WebUI.setText(objectEquivalent, foreignCurrency)

		WebUI.click(objectrate)

		WebUI.click(searchBtn)

		WebUI.delay(3)

		String TABLE_ROW_XPATH = "//tr[@class='even' or @class='odd']"
		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().frame('login')
		driver.switchTo().frame('mainFrame')
		WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
		List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of tasks: "+list.size())
		WebUI.switchToDefaultContent()


		def currentTrans = ''

		Actions action = new Actions(driver)

		for(int i = 1; i<list.size()+1; i++){

			String transrow= "//tr[@class='even' or @class='odd'][$i]//td[1]"

			TestObject transrowObject = new TestObject()
			def currentRow= transrowObject.addProperty("xpath", ConditionType.EQUALS, transrow)

			transrowObject.setParentObject(pr2)

			WebUI.click(currentRow)

			String transAmountCurrency = "//div[.//label[text()='Transaction Amount']]//label[@class='control-value' and @for='currencyId']"

			TestObject transAmountCurrencyObject = new TestObject()
			def amountCurrency= transAmountCurrencyObject.addProperty("xpath", ConditionType.EQUALS, transAmountCurrency)

			transAmountCurrencyObject.setParentObject(pr2)

			def currentCurrency = WebUI.getText(transAmountCurrencyObject)

			WebUI.comment("currency : " + currentCurrency)

			String statusCurrent = "//div[.//label[text()='Status']]//label[@class='control-value' and @for='status']"

			TestObject transStatusObject = new TestObject()
			def transStatus= transStatusObject.addProperty("xpath", ConditionType.EQUALS, statusCurrent)

			transStatusObject.setParentObject(pr2)

			def currentStatus = WebUI.getText(transStatusObject)

			WebUI.comment("status : " + currentStatus)

			if(WebUI.verifyEqual(anotherCurrency, currentCurrency) && WebUI.verifyEqual(currentStatus, targetStatus) ){
				String transID = "//div[.//label[text()='Reference No']]//label[@class='control-value']"

				TestObject transIDObject = new TestObject()
				def transIDCurrent= transIDObject.addProperty("xpath", ConditionType.EQUALS, transID)

				transIDObject.setParentObject(pr2)

				currentTrans = WebUI.getText(transIDObject)

				break
			}else{
				String backButton= "//button[@id='btnBack']"

				TestObject backButtonObject = new TestObject()
				def buttonBack= backButtonObject.addProperty("xpath", ConditionType.EQUALS, backButton)

				backButtonObject.setParentObject(pr2)

				WebUI.click(buttonBack)
			}
		}
		WebUI.comment("reference No : " + currentTrans)
		WebUI.callTestCase(findTestCase('FrontEnd/Step Group (Reusable Group)/logout_BO'), [:], FailureHandling.STOP_ON_FAILURE)
		return currentTrans
	}

	@Keyword
	def getForexCrossSpecialRate(String foreignCurrency, String foreignCurrency2, String targetStatus){

		TestObject pr = new TestObject()

		TestObject pr2 = new TestObject()

		String iframe1 = "//iframe[@id='login']"
		String iframe2 = "//iframe[@id='mainFrame']"

		pr.addProperty("xpath", ConditionType.EQUALS, iframe1)
		pr2.addProperty("xpath", ConditionType.EQUALS, iframe2)

		pr2.setParentObject(pr)

		String chosenCurrency = "//div[@class='select2-result-label' and contains(.,'$foreignCurrency')]"

		TestObject testObject = new TestObject()
		def objectrate= testObject.addProperty("xpath", ConditionType.EQUALS, chosenCurrency)

		testObject.setParentObject(pr2)
		
		String chosenCurrency2 = "//div[@class='select2-result-label' and contains(.,'$foreignCurrency2')]"
		
		TestObject testObject2 = new TestObject()
		def objectrate2= testObject2.addProperty("xpath", ConditionType.EQUALS, chosenCurrency2)
		
		testObject2.setParentObject(pr2)

		String inputAmount = "//div[@id='s2id_foreignCurrencyCode']"

		TestObject testInput = new TestObject()
		def objectInput = testInput.addProperty("xpath", ConditionType.EQUALS, inputAmount)

		testInput.setParentObject(pr2)
		
		String inputAmount2 = "//div[@id='s2id_foreignCurrencyCode2']"
		
		TestObject testInput2 = new TestObject()
		def objectInput2 = testInput2.addProperty("xpath", ConditionType.EQUALS, inputAmount2)
		
		testInput2.setParentObject(pr2)

		String searchBox = "//div[@id='select2-drop']//input"

		TestObject testEquivalent = new TestObject()
		def objectEquivalent = testEquivalent.addProperty("xpath", ConditionType.EQUALS, searchBox)

		testEquivalent.setParentObject(pr2)

		String searchButton = "//button[@id='btnSearchForex']"

		TestObject testSearchBtn = new TestObject()
		def searchBtn = testSearchBtn.addProperty("xpath", ConditionType.EQUALS, searchButton)

		testSearchBtn.setParentObject(pr2)

		WebUI.callTestCase(findTestCase('FrontEnd/Step Group (Reusable Group)/accessForexCroxxSpecialRateDB'), [:], FailureHandling.STOP_ON_FAILURE)

		WebUI.click(objectInput)

		WebUI.setText(objectEquivalent, foreignCurrency)

		WebUI.click(objectrate)
		
		WebUI.click(objectInput2)
		
		WebUI.setText(objectEquivalent, foreignCurrency2)
		
		WebUI.click(objectrate2)

		WebUI.click(searchBtn)

		WebUI.delay(3)

		String TABLE_ROW_XPATH = "//tr[@class='even' or @class='odd']"
		WebDriver driver = DriverFactory.getWebDriver()
		driver.switchTo().frame('login')
		driver.switchTo().frame('mainFrame')
		WebElement temp = driver.findElement(By.xpath(TABLE_ROW_XPATH))
		List list = temp.findElements(By.xpath(TABLE_ROW_XPATH))
		KeywordUtil.logInfo("success")
		KeywordUtil.logInfo("total number of tasks: "+list.size())
		WebUI.switchToDefaultContent()


		def currentTrans = ''

		Actions action = new Actions(driver)

		for(int i = 1; i<list.size()+1; i++){

			String transrow= "//tr[@class='even' or @class='odd'][$i]//td[1]"

			TestObject transrowObject = new TestObject()
			def currentRow= transrowObject.addProperty("xpath", ConditionType.EQUALS, transrow)

			transrowObject.setParentObject(pr2)

			WebUI.click(currentRow)

			String transAmountCurrency = "//div[.//label[text()='Foreign Currency']]//label[@class='control-value' and @for='currency']"

			TestObject transAmountCurrencyObject = new TestObject()
			def amountCurrency= transAmountCurrencyObject.addProperty("xpath", ConditionType.EQUALS, transAmountCurrency)

			transAmountCurrencyObject.setParentObject(pr2)

			def currentCurrency = WebUI.getText(transAmountCurrencyObject)

			WebUI.comment("currency : " + currentCurrency)
			
			String transAmountCurrency2 = "//div[.//label[text()='Transaction Amount']]//label[@class='control-value' and @for='currencyId']"
			
			TestObject transAmountCurrencyObject2 = new TestObject()
			def amountCurrency2= transAmountCurrencyObject2.addProperty("xpath", ConditionType.EQUALS, transAmountCurrency2)
			
			transAmountCurrencyObject2.setParentObject(pr2)
			
			def currentCurrency2 = WebUI.getText(transAmountCurrencyObject2)

			String statusCurrent = "//div[.//label[text()='Status']]//label[@class='control-value' and @for='status']"

			TestObject transStatusObject = new TestObject()
			def transStatus= transStatusObject.addProperty("xpath", ConditionType.EQUALS, statusCurrent)

			transStatusObject.setParentObject(pr2)

			def currentStatus = WebUI.getText(transStatusObject)

			WebUI.comment("status : " + currentStatus)

			if(WebUI.verifyEqual(foreignCurrency, currentCurrency) && WebUI.verifyEqual(foreignCurrency2, currentCurrency2) && WebUI.verifyEqual(currentStatus, targetStatus) ){
				String transID = "//div[.//label[text()='Reference No']]//label[@class='control-value']"

				TestObject transIDObject = new TestObject()
				def transIDCurrent= transIDObject.addProperty("xpath", ConditionType.EQUALS, transID)

				transIDObject.setParentObject(pr2)

				currentTrans = WebUI.getText(transIDObject)

				break
			}else{
				String backButton= "//button[@id='btnBack']"

				TestObject backButtonObject = new TestObject()
				def buttonBack= backButtonObject.addProperty("xpath", ConditionType.EQUALS, backButton)

				backButtonObject.setParentObject(pr2)

				WebUI.click(buttonBack)
			}
		}
		WebUI.comment("reference No : " + currentTrans)
		WebUI.callTestCase(findTestCase('FrontEnd/Step Group (Reusable Group)/logout_BO'), [:], FailureHandling.STOP_ON_FAILURE)
		return currentTrans
	}
}

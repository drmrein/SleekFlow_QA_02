package keys

import org.apache.commons.lang.RandomStringUtils

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.util.KeywordUtil

public class randomString {

	@Keyword
	def generateRandomString(String staticChar, String positionOfStaticChar, int length ){
		String randomValue = ''
		positionOfStaticChar = positionOfStaticChar.toLowerCase()


		if(positionOfStaticChar == "first"){
			randomValue =  staticChar+RandomStringUtils.randomAlphanumeric(length)
		}else if(positionOfStaticChar == "middle"){
			length = length/2
			KeywordUtil.logInfo(length.toString(length))
			randomValue =  RandomStringUtils.randomAlphanumeric(length)+staticChar+RandomStringUtils.randomAlphanumeric(length)
			KeywordUtil.logInfo(randomValue)
		}else if(positionOfStaticChar == "last"){
			randomValue =  RandomStringUtils.randomAlphanumeric(length)+staticChar
		}else{
			KeywordUtil.markFailed("the position of static character is not valid")
		}

		KeywordUtil.logInfo(randomValue)

		return randomValue
	}
	
	@Keyword
	def generateRandomStringUpperCase(String staticChar, String positionOfStaticChar, int length ){
		String randomValue = ''
		positionOfStaticChar = positionOfStaticChar.toLowerCase()


		if(positionOfStaticChar == "first"){
			randomValue =  staticChar+RandomStringUtils.randomAlphanumeric(length)
		}else if(positionOfStaticChar == "middle"){
			length = length/2
			KeywordUtil.logInfo(length.toString(length))
			randomValue =  RandomStringUtils.randomAlphanumeric(length)+staticChar+RandomStringUtils.randomAlphanumeric(length)
			KeywordUtil.logInfo(randomValue)
		}else if(positionOfStaticChar == "last"){
			randomValue =  RandomStringUtils.randomAlphanumeric(length)+staticChar
		}else{
			KeywordUtil.markFailed("the position of static character is not valid")
		}

		randomValue = randomValue.toUpperCase()
		KeywordUtil.logInfo(randomValue)

		return randomValue
	}


	@Keyword
	def generateRandomNum(String staticChar, String positionOfStaticChar, int length ){
		String randomValue = ''
		positionOfStaticChar = positionOfStaticChar.toLowerCase()


		if(positionOfStaticChar == "first"){
			randomValue =  staticChar+RandomStringUtils.randomNumeric(length)
		}else if(positionOfStaticChar == "middle"){
			length = length/2
			KeywordUtil.logInfo(length.toString(length))
			randomValue =  RandomStringUtils.randomNumeric(length)+staticChar+RandomStringUtils.randomNumeric(length)
			KeywordUtil.logInfo(randomValue)
		}else if(positionOfStaticChar == "last"){
			randomValue =  RandomStringUtils.randomNumeric(length)+staticChar
		}else{
			KeywordUtil.markFailed("the position of static character is not valid")
		}

		KeywordUtil.logInfo(randomValue)

		return randomValue
	}
}

package keys


import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import keys.basicOperation as BasicOperation

public class SetTextHandler {

	SendKeys newKeys = new SendKeys();

	@Keyword
	def handleInput(TestObject objectPath, String inputValue, FailureHandling handler = FailureHandling.STOP_ON_FAILURE){
		try{
			//			WebUI.clearText(objectPath)
			newKeys.handleInput(objectPath, "Keys.CONTROL, a")
			newKeys.handleInput(objectPath, "Keys.BACKSPACE")

			WebUI.verifyElementAttributeValue(objectPath, 'value', '', 0)
			WebUI.setText(objectPath, inputValue, handler)
			println("using set text")
		}catch(Exception e){
			//			WebUI.clearText(objectPath)
			newKeys.handleInput(objectPath, "Keys.CONTROL, a")
			newKeys.handleInput(objectPath, "Keys.BACKSPACE")

			WebUI.verifyElementAttributeValue(objectPath, 'value', '', 0)
			WebUI.sendKeys(objectPath, inputValue, handler)
			println("using send keys")
		}
	}

	@Keyword
	def pickerTime(String time) {
		// Precondition: picker time already displayed
		// Format Time: HH:MM

		String timeHour = time.substring(0, time.indexOf(":"))
		String timeMin = time.split(":")[1]

		String timeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+timeHour+"']"
		String timeMinuteChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][2]//li//div[text()='"+timeMin+"']"

		TestObject timeChosenHour = new TestObject()
		timeChosenHour.addProperty("xpath", ConditionType.EQUALS, timeHourChoice)

		TestObject timeChosenMinute = new TestObject()
		timeChosenMinute.addProperty("xpath", ConditionType.EQUALS, timeMinuteChoice)

		ClickUsingJS clickjs = new ClickUsingJS()
		BasicOperation mathOperation = new BasicOperation()

		clickjs.ClickUsingJavaScript(timeChosenHour, 0)
		clickjs.ClickUsingJavaScript(timeChosenMinute, 0)

		String pathOkButton = "//button/span[text() = 'Ok']"
		TestObject okButton = new TestObject()
		okButton.addProperty("xpath", ConditionType.EQUALS, pathOkButton)

		WebUI.click(okButton)
		//		TestObject timeChosenHour = new TestObject()
		//		timeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
		//
		//		TestObject startTimeInputObject = new TestObject()
		//		startTimeInputObject.addProperty("xpath", ConditionType.EQUALS, startTimeInput)
		//
		//
		//

		//
		//		if(currentStartHour == startTimeHour) {
		//			clickjs.ClickUsingJavaScript(timeChosenHour, 0)
		//		}else {
		//
		//			Boolean clickStatus = WebUI.verifyElementClickable(timeChosenHour)
		//
		//			if(clickStatus == true) {
		//				clickjs.ClickUsingJavaScript(timeChosenHour, 0)
		//			}else {
		//				if(currentStartHour < startTimeHour) {
		//					while(currentStartHour != startTimeHour) {
		//						String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
		//						startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
		//						timeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
		//						clickjs.ClickUsingJavaScript(timeChosenHour, 0)
		//						currentStartHour = WebUI.getText(currentHourStartTime)
		//					}
		//				}else {
		//					TestObject nowButton = new TestObject()
		//					nowButton.addProperty("xpath", ConditionType.EQUALS, "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//a[@class='ant-picker-now-btn']")
		//
		//					WebUI.click(nowButton)
		//					WebUI.click(startTimeInputObject)
		//
		//					while(currentStartHour != startTimeHour) {
		//						String gap = mathOperation.sumResultInString([currentStartHour, 1], false, 0, "hh")
		//						startTimeHourChoice = "//div[contains(@class, 'ant-picker-dropdown') and not(contains(@class, 'hidden'))]//ul[@class='ant-picker-time-panel-column'][1]//li//div[text()='"+gap+"']"
		//						timeChosenHour.addProperty("xpath", ConditionType.EQUALS, startTimeHourChoice)
		//						clickjs.ClickUsingJavaScript(timeChosenHour, 0)
		//						currentStartHour = WebUI.getText(currentHourStartTime)
		//					}
		//				}
		//			}
		//		}
		//
		//
	}
}
package keys

import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class scrollElementAdjusted {

	@Keyword
	def scrollIntoElementWithOffset(TestObject targetedElement, int YOffset = 50, int XOffset = 50){
		WebDriver driver = DriverFactory.getWebDriver()
		JavascriptExecutor je = (JavascriptExecutor) driver;
		WebElement targetElement = WebUiCommonHelper.findWebElement(targetedElement, 30)

		int pageH = WebUI.getPageHeight()
		int pageW = WebUI.getPageWidth()

		int elemH = targetElement.getLocation().getY()
		int elemW = targetElement.getLocation().getX()

		//		WebUI.scrollToPosition(elemH, elemW)
		if(YOffset != 0){
			int offsetH = elemH - YOffset
			je.executeScript("window.scrollTo({top: $offsetH,behavior: 'smooth'});");
		}
		if(XOffset != 0){
			int offsetW = elemW + XOffset
			je.executeScript("window.scrollTo({right: $offsetW,behavior: 'smooth'});");

		}

	}
}

package keys

import java.math.RoundingMode
import java.text.NumberFormat;
import java.text.SimpleDateFormat

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

public class basicOperation {

	@Keyword
	String sumResultInString(List<String> addInput, Boolean currencyFormat = true, int roundingValue = 2, String formatDate = ""){

		double sumValue = 0

		addInput.each{

			String currentInput = it.replace(',', '')

			double currentValue = Double.valueOf(currentInput)

			sumValue = sumValue + currentValue
		}
		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}else if(formatDate != ""){
			SimpleDateFormat dateFormat = new SimpleDateFormat(formatDate)
			Date finalValueDate = dateFormat.parse(finalValue)
			finalValue = dateFormat.format(finalValueDate)
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)
	}

	@Keyword
	String substractResultInString(List<String> addInput, Boolean currencyFormat = true, int roundingValue = 2){

		addInput[0] = addInput[0].replace(',', '')

		double sumValue = Double.valueOf(addInput[0])

		for(int i = 1; i < addInput.size(); i++){
			String currentInput = addInput[i].replace(',', '')

			double currentValue = Double.valueOf(currentInput)

			sumValue = sumValue - currentValue
		}
		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		WebUI.comment(String.valueOf(format.format(bd)).replace('$', ''))
		return String.valueOf(format.format(bd).replace('$', ''))
	}

	@Keyword
	String multipleResultInString(List<String> addInput, Boolean currencyFormat = true, int roundingValue = 2){

		addInput[0] = addInput[0].replace(',', '')

		double sumValue = Double.valueOf(addInput[0])

		for(int i = 1; i < addInput.size(); i++){
			String currentInput = addInput[i].replace(',', '')

			double currentValue = Double.valueOf(currentInput)

			sumValue = sumValue * currentValue
		}
		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)
	}

	@Keyword
	String divideResultInString(List<String> addInput, Boolean currencyFormat = true, int roundingValue = 2){

		addInput[0] = addInput[0].replace(',', '')

		double sumValue = Double.valueOf(addInput[0])

		for(int i = 1; i < addInput.size(); i++){
			String currentInput = addInput[i].replace(',', '')

			double currentValue = Double.valueOf(currentInput)

			sumValue = sumValue / currentValue
		}
		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)
	}

	@Keyword
	String getPercentageResultInString(String Amount ,String percentage, Boolean currencyFormat = true, int roundingValue = 2){

		Amount = Amount.replace(',', '')

		double currentValue = Double.valueOf(Amount)

		double percentageDivider = Double.valueOf(percentage)

		percentageDivider = percentageDivider / 100

		double sumValue = currentValue * percentageDivider

		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)
	}

	@Keyword
	String compareWithMinMaxResultInString(String Amount, String min, String max, Boolean currencyFormat = true, int roundingValue = 2){

		Amount = Amount.replace(',', '')

		min = min.replace(',', '')

		max = max.replace(',', '')

		double currentValue = Double.valueOf(Amount)

		double sumValue = currentValue

		double currentMin = Double.valueOf(min)

		double currentMax = Double.valueOf(max)

		if(currentValue < currentMin){
			sumValue = currentMin
		}

		if(currentValue > currentMax){
			sumValue = currentMax
		}

		BigDecimal bd = new BigDecimal(Double.toString(sumValue));
		bd = bd.setScale(roundingValue, RoundingMode.HALF_UP);
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US)
		String finalValue = String.valueOf(bd)
		if(currencyFormat == true){
			finalValue = String.valueOf(format.format(bd)).replace('$', '')
		}

		WebUI.comment(finalValue)
		return String.valueOf(finalValue)
	}

	@Keyword
	def verifyLessThanOrEquals(String record, String totalRecord){
		boolean lessequals = false
		println Double.valueOf(totalRecord)
		println Double.valueOf(record)

		if(Double.valueOf(totalRecord) <= Double.valueOf(record)){
			lessequals = true
		}

		WebUI.verifyEqual(lessequals, true)
	}

	@Keyword
	def verifyLessThanOrEquals(String record, int totalRecord){
		boolean lessequals = false
		println Double.valueOf(totalRecord)
		println Double.valueOf(record)

		if(Double.valueOf(totalRecord) <= Double.valueOf(record)){

			lessequals = true
		}

		WebUI.verifyEqual(lessequals, true)
	}
}

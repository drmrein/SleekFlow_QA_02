
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String

import java.lang.Boolean

import java.util.List

import java.lang.Integer

import java.io.File

import java.util.Date

import com.kms.katalon.core.model.FailureHandling

import java.sql.Timestamp

import java.util.HashMap



def static "keys.ClickUsingJS.ClickUsingJavaScript"(
    	TestObject to	
     , 	int timeout	) {
    (new keys.ClickUsingJS()).ClickUsingJavaScript(
        	to
         , 	timeout)
}


def static "get.handleTestObject.getValueOfActiveSelector"(
    	TestObject currentObject	) {
    (new get.handleTestObject()).getValueOfActiveSelector(
        	currentObject)
}


def static "webDatabase.ForexLimit.reset"(
    	String id	) {
    (new webDatabase.ForexLimit()).reset(
        	id)
}


def static "webDatabase.ForexLimit.update"(
    	String id	
     , 	String nominal	) {
    (new webDatabase.ForexLimit()).update(
        	id
         , 	nominal)
}


def static "approvalMatrix.setApprovalMatrix1A0R.runsetApprovalMatrix1A0R"() {
    (new approvalMatrix.setApprovalMatrix1A0R()).runsetApprovalMatrix1A0R()
}


def static "webDatabase.eInvoice.getDueDate"(
    	String eInvoiceNo	) {
    (new webDatabase.eInvoice()).getDueDate(
        	eInvoiceNo)
}


def static "replaceDate.handleEinvoice.updateFile"(
    	String dirPath	) {
    (new replaceDate.handleEinvoice()).updateFile(
        	dirPath)
}


def static "get.ScreenCapture.getEntirePage"(
    	String filename	
     , 	Boolean generatedValue	) {
    (new get.ScreenCapture()).getEntirePage(
        	filename
         , 	generatedValue)
}


def static "get.ScreenCapture.getEntirePage"(
    	String filename	) {
    (new get.ScreenCapture()).getEntirePage(
        	filename)
}


def static "keys.DragAndDropHelper.dragAndDrop"(
    	TestObject sourceObject	
     , 	TestObject destinationObject	) {
    (new keys.DragAndDropHelper()).dragAndDrop(
        	sourceObject
         , 	destinationObject)
}


def static "keys.RandomNumber.generateRandomNumber"(
    	int length	) {
    (new keys.RandomNumber()).generateRandomNumber(
        	length)
}


def static "handleWebTable.HTMLTableHelper.verifyColumnHeader"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper()).verifyColumnHeader(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper.getTotalRowPerPage"() {
    (new handleWebTable.HTMLTableHelper()).getTotalRowPerPage()
}


def static "handleWebTable.HTMLTableHelper.verifyListOnTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).verifyListOnTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper.getTotalListOnTableAllPages"() {
    (new handleWebTable.HTMLTableHelper()).getTotalListOnTableAllPages()
}


def static "handleWebTable.HTMLTableHelper.verifyAscendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper()).verifyAscendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper.verifyDescendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper()).verifyDescendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper.verifySortedRandomlyByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper()).verifySortedRandomlyByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper.verifyDateIsMatchWithSearchDate"(
    	String input_dateFrom	
     , 	String input_dateTo	
     , 	List columnIndexes	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper()).verifyDateIsMatchWithSearchDate(
        	input_dateFrom
         , 	input_dateTo
         , 	columnIndexes
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper.checkOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).checkOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper.unCheckOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).unCheckOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper.checkOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper()).checkOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper.unCheckOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper()).unCheckOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper.clickEditIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickEditIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickEyeIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickEyeIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickDeleteIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickDeleteIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickDeleteIconOnSpecificRow_downloadReportMenu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickDeleteIconOnSpecificRow_downloadReportMenu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickDownloadIconOnSpecificRow_downloadReportMenu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickDownloadIconOnSpecificRow_downloadReportMenu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickLockIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickResetIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickResendIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper.verifyColumnHeaderPopUp"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper()).verifyColumnHeaderPopUp(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper.verifyListOnPopUpTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).verifyListOnPopUpTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper.checkOnSpecificRowPopUp"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper()).checkOnSpecificRowPopUp(
        	data)
}


def static "keys.Uncheck.unCheckUsingCustomKeyword"(
    	TestObject testobject	) {
    (new keys.Uncheck()).unCheckUsingCustomKeyword(
        	testobject)
}


def static "webDatabase.BankUserManager.reset"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).reset(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.stillLoggedIn"(
    	String userId	) {
    (new webDatabase.BankUserManager()).stillLoggedIn(
        	userId)
}


def static "webDatabase.BankUserManager.release"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).release(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.inactive"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).inactive(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.activate"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).activate(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.lock"(
    	String userId	) {
    (new webDatabase.BankUserManager()).lock(
        	userId)
}


def static "webDatabase.BankUserManager.unlock"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).unlock(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.delete"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).delete(
        	updatedBy
         , 	userId)
}


def static "webDatabase.BankUserManager.rollback"(
    	String updatedBy	
     , 	String userId	) {
    (new webDatabase.BankUserManager()).rollback(
        	updatedBy
         , 	userId)
}


def static "keys.randomString.generateRandomString"(
    	String staticChar	
     , 	String positionOfStaticChar	
     , 	int length	) {
    (new keys.randomString()).generateRandomString(
        	staticChar
         , 	positionOfStaticChar
         , 	length)
}


def static "keys.randomString.generateRandomStringUpperCase"(
    	String staticChar	
     , 	String positionOfStaticChar	
     , 	int length	) {
    (new keys.randomString()).generateRandomStringUpperCase(
        	staticChar
         , 	positionOfStaticChar
         , 	length)
}


def static "keys.randomString.generateRandomNum"(
    	String staticChar	
     , 	String positionOfStaticChar	
     , 	int length	) {
    (new keys.randomString()).generateRandomNum(
        	staticChar
         , 	positionOfStaticChar
         , 	length)
}


def static "approvalMatrix.SetApprovalMatrix.setApprovalMatrixSingleSequence"(
    	String rangelimitapproval	
     , 	String NoofApproval	
     , 	String NoofUser	
     , 	String ApprovalLevel	
     , 	String UserGroupOption	
     , 	List TargetUserGroup	
     , 	List TargetUser	) {
    (new approvalMatrix.SetApprovalMatrix()).setApprovalMatrixSingleSequence(
        	rangelimitapproval
         , 	NoofApproval
         , 	NoofUser
         , 	ApprovalLevel
         , 	UserGroupOption
         , 	TargetUserGroup
         , 	TargetUser)
}


def static "approvalMatrix.SetApprovalMatrix.setApprovalMatrix1A0R"() {
    (new approvalMatrix.SetApprovalMatrix()).setApprovalMatrix1A0R()
}


def static "approvalMatrix.SetApprovalMatrix.setApprovalMatrix2A0R"() {
    (new approvalMatrix.SetApprovalMatrix()).setApprovalMatrix2A0R()
}


def static "approvalMatrix.SetApprovalMatrix.setApprovalMatrixSingleSequence"(
    	String rangelimitapproval	
     , 	String NoofApproval	
     , 	String NoofUser	
     , 	String ApprovalLevel	
     , 	String UserGroupOption	
     , 	List TargetUserGroup	) {
    (new approvalMatrix.SetApprovalMatrix()).setApprovalMatrixSingleSequence(
        	rangelimitapproval
         , 	NoofApproval
         , 	NoofUser
         , 	ApprovalLevel
         , 	UserGroupOption
         , 	TargetUserGroup)
}


def static "approvalMatrix.SetApprovalMatrix.setApprovalMatrixSingleSequence"(
    	String rangelimitapproval	
     , 	String NoofApproval	
     , 	String NoofUser	
     , 	String ApprovalLevel	
     , 	String UserGroupOption	) {
    (new approvalMatrix.SetApprovalMatrix()).setApprovalMatrixSingleSequence(
        	rangelimitapproval
         , 	NoofApproval
         , 	NoofUser
         , 	ApprovalLevel
         , 	UserGroupOption)
}


def static "replaceDate.ReplaceDate.replaceDateStanding"(
    	String date	
     , 	String dirPath	) {
    (new replaceDate.ReplaceDate()).replaceDateStanding(
        	date
         , 	dirPath)
}


def static "replaceDate.ReplaceDate.replaceDateforSeparate"(
    	String date	
     , 	String dirPath	) {
    (new replaceDate.ReplaceDate()).replaceDateforSeparate(
        	date
         , 	dirPath)
}


def static "replaceDate.ReplaceDate.replaceDateWithParameter"(
    	String date	
     , 	String dirPath	
     , 	int colIndex	
     , 	int rowIndex	) {
    (new replaceDate.ReplaceDate()).replaceDateWithParameter(
        	date
         , 	dirPath
         , 	colIndex
         , 	rowIndex)
}


def static "replaceDate.ReplaceDate.replaceDateforRecurring"(
    	String dirPath	) {
    (new replaceDate.ReplaceDate()).replaceDateforRecurring(
        	dirPath)
}


def static "replaceDate.ReplaceDate.replaceDateSeparatedStandingImmediate"(
    	String date	
     , 	String dirPath	) {
    (new replaceDate.ReplaceDate()).replaceDateSeparatedStandingImmediate(
        	date
         , 	dirPath)
}


def static "keys.ClearText.clearText"(
    	TestObject testObject	) {
    (new keys.ClearText()).clearText(
        	testObject)
}


def static "webCalendar.webCalendar.customizedNextDate"(
    	String target	) {
    (new webCalendar.webCalendar()).customizedNextDate(
        	target)
}


def static "webCalendar.webCalendar.customizedPrevDate"(
    	String target	) {
    (new webCalendar.webCalendar()).customizedPrevDate(
        	target)
}


def static "webCalendar.webCalendar.customizedTodayDate"() {
    (new webCalendar.webCalendar()).customizedTodayDate()
}


def static "webCalendar.webCalendar.customizedExactDate"(
    	String targetDate	) {
    (new webCalendar.webCalendar()).customizedExactDate(
        	targetDate)
}


def static "webCalendar.webCalendar.verifyNextDateDisabled"(
    	String target	) {
    (new webCalendar.webCalendar()).verifyNextDateDisabled(
        	target)
}


def static "webCalendar.webCalendar.verifyPrevDateDisabled"(
    	String target	) {
    (new webCalendar.webCalendar()).verifyPrevDateDisabled(
        	target)
}


def static "webCalendar.webCalendar.customizedPrevDateFormat"(
    	String target	
     , 	String format	) {
    (new webCalendar.webCalendar()).customizedPrevDateFormat(
        	target
         , 	format)
}


def static "webCalendar.webCalendar.customizedNextDateFormat"(
    	String target	
     , 	String format	) {
    (new webCalendar.webCalendar()).customizedNextDateFormat(
        	target
         , 	format)
}


def static "webCalendar.webCalendar.customizedTodayDateFormat"(
    	String format	) {
    (new webCalendar.webCalendar()).customizedTodayDateFormat(
        	format)
}


def static "webCalendar.webCalendar.customizedTodayDateDisplay"() {
    (new webCalendar.webCalendar()).customizedTodayDateDisplay()
}


def static "webCalendar.webCalendar.getPreviousMonth"(
    	Integer month	) {
    (new webCalendar.webCalendar()).getPreviousMonth(
        	month)
}


def static "webCalendar.webCalendar.changeDateFormat"(
    	String inputDate	
     , 	String originalformat	
     , 	String newformat	
     , 	String removeText	) {
    (new webCalendar.webCalendar()).changeDateFormat(
        	inputDate
         , 	originalformat
         , 	newformat
         , 	removeText)
}


def static "webCalendar.webCalendar.customizedPrevDateFormat"(
    	String target	) {
    (new webCalendar.webCalendar()).customizedPrevDateFormat(
        	target)
}


def static "webCalendar.webCalendar.customizedNextDateFormat"(
    	String target	) {
    (new webCalendar.webCalendar()).customizedNextDateFormat(
        	target)
}


def static "webCalendar.webCalendar.customizedTodayDateFormat"() {
    (new webCalendar.webCalendar()).customizedTodayDateFormat()
}


def static "webCalendar.webCalendar.changeDateFormat"(
    	String inputDate	
     , 	String originalformat	
     , 	String newformat	) {
    (new webCalendar.webCalendar()).changeDateFormat(
        	inputDate
         , 	originalformat
         , 	newformat)
}


def static "report.CompareTXT.extractDownloadedReport"(
    	String dirPath	
     , 	boolean shouldExtract	) {
    (new report.CompareTXT()).extractDownloadedReport(
        	dirPath
         , 	shouldExtract)
}


def static "report.CompareTXT.doCompare"(
    	List listContent	
     , 	File csvAutomate	
     , 	String startPeriod	
     , 	String endPeriod	
     , 	String requestDate	
     , 	String filename	
     , 	File downloadedZip	) {
    (new report.CompareTXT()).doCompare(
        	listContent
         , 	csvAutomate
         , 	startPeriod
         , 	endPeriod
         , 	requestDate
         , 	filename
         , 	downloadedZip)
}


def static "report.CompareTXT.getInquiryListContent"(
    	String idFrameLogin	
     , 	String idMainFrame	
     , 	String idTable	) {
    (new report.CompareTXT()).getInquiryListContent(
        	idFrameLogin
         , 	idMainFrame
         , 	idTable)
}


def static "report.CompareTXT.getDownloadParameter"(
    	String idFrameLogin	
     , 	String idMainFrame	
     , 	String idTable	
     , 	Object idFromDate	
     , 	Object idToDate	) {
    (new report.CompareTXT()).getDownloadParameter(
        	idFrameLogin
         , 	idMainFrame
         , 	idTable
         , 	idFromDate
         , 	idToDate)
}


def static "report.CompareTXT.compareTxtToWeb"(
    	List inqListContentTable	
     , 	String idLogin	
     , 	String idMainFrame	
     , 	String idTable	
     , 	String idFromDate	
     , 	String idToDate	
     , 	String dirPath	) {
    (new report.CompareTXT()).compareTxtToWeb(
        	inqListContentTable
         , 	idLogin
         , 	idMainFrame
         , 	idTable
         , 	idFromDate
         , 	idToDate
         , 	dirPath)
}


def static "report.CompareTXT.parseDate"(
    	String inputDate	
     , 	String format	) {
    (new report.CompareTXT()).parseDate(
        	inputDate
         , 	format)
}


def static "report.CompareTXT.formatDate"(
    	Date inputDate	
     , 	String format	) {
    (new report.CompareTXT()).formatDate(
        	inputDate
         , 	format)
}


def static "keys.Calendar.selectCalendar"(
    	TestObject calendarField	
     , 	String targetDate	) {
    (new keys.Calendar()).selectCalendar(
        	calendarField
         , 	targetDate)
}


def static "get.getTotalRows.countRowsPerPage"(
    	String xpath	) {
    (new get.getTotalRows()).countRowsPerPage(
        	xpath)
}


def static "approvalMatrix.setApprovalMatrix0A0R.runsetApprovalMatrix0A0R"() {
    (new approvalMatrix.setApprovalMatrix0A0R()).runsetApprovalMatrix0A0R()
}


def static "webDatabase.DownloadReportBO.generateFailCSV"(
    	String updatedBy	) {
    (new webDatabase.DownloadReportBO()).generateFailCSV(
        	updatedBy)
}


def static "keys.CheckorUncheck.unCheckUsingCustomKeyword"(
    	TestObject testobject	) {
    (new keys.CheckorUncheck()).unCheckUsingCustomKeyword(
        	testobject)
}


def static "keys.CheckorUncheck.CheckUsingCustomKeyword"(
    	TestObject testobject	) {
    (new keys.CheckorUncheck()).CheckUsingCustomKeyword(
        	testobject)
}


def static "webDatabase.RoleUser.insertRoleIntoUser"(
    	String userId	
     , 	String userCode	
     , 	String roleCode	) {
    (new webDatabase.RoleUser()).insertRoleIntoUser(
        	userId
         , 	userCode
         , 	roleCode)
}


def static "tcVariable.tcVariable.runVariable"(
    	String testData	
     , 	String column	
     , 	Integer row	
     , 	TestObject[] arrObject	) {
    (new tcVariable.tcVariable()).runVariable(
        	testData
         , 	column
         , 	row
         , 	arrObject)
}


def static "tcVariable.tcVariable.reuseRunVariable"(
    	String testData	
     , 	String column	
     , 	Integer row	
     , 	TestObject[] arrObject	) {
    (new tcVariable.tcVariable()).reuseRunVariable(
        	testData
         , 	column
         , 	row
         , 	arrObject)
}


def static "tcVariable.tcVariable.setVariable"(
    	String parameter	
     , 	String value	) {
    (new tcVariable.tcVariable()).setVariable(
        	parameter
         , 	value)
}


def static "tcVariable.tcVariable.getVariable"(
    	String parameter	) {
    (new tcVariable.tcVariable()).getVariable(
        	parameter)
}


def static "keys.SetTextHandler.handleInput"(
    	TestObject objectPath	
     , 	String inputValue	
     , 	FailureHandling handler	) {
    (new keys.SetTextHandler()).handleInput(
        	objectPath
         , 	inputValue
         , 	handler)
}


def static "keys.SetTextHandler.pickerTime"(
    	String time	) {
    (new keys.SetTextHandler()).pickerTime(
        	time)
}


def static "keys.SetTextHandler.handleInput"(
    	TestObject objectPath	
     , 	String inputValue	) {
    (new keys.SetTextHandler()).handleInput(
        	objectPath
         , 	inputValue)
}


def static "textProcessor.processText.removeText"(
    	String data	
     , 	TestObject textobject	) {
    (new textProcessor.processText()).removeText(
        	data
         , 	textobject)
}


def static "textProcessor.processText.removeTextAndReturnInteger"(
    	String data1	
     , 	String data2	
     , 	TestObject textobject	) {
    (new textProcessor.processText()).removeTextAndReturnInteger(
        	data1
         , 	data2
         , 	textobject)
}


def static "textProcessor.processText.substringTextUsingStringasIndex"(
    	String status	
     , 	String data	
     , 	TestObject textobject	) {
    (new textProcessor.processText()).substringTextUsingStringasIndex(
        	status
         , 	data
         , 	textobject)
}


def static "textProcessor.processText.substringTextBetweenStringIndex"(
    	String data	
     , 	String data2	
     , 	TestObject textobject	) {
    (new textProcessor.processText()).substringTextBetweenStringIndex(
        	data
         , 	data2
         , 	textobject)
}


def static "textProcessor.processText.formatPendingTaskSubHeader"(
    	String menu	
     , 	String action	) {
    (new textProcessor.processText()).formatPendingTaskSubHeader(
        	menu
         , 	action)
}


def static "textProcessor.processText.concatenate"(
    	List data	) {
    (new textProcessor.processText()).concatenate(
        	data)
}


def static "textProcessor.processText.removeTextFromText"(
    	String data	
     , 	String textCurrent	) {
    (new textProcessor.processText()).removeTextFromText(
        	data
         , 	textCurrent)
}


def static "webDatabase.DeviceRegistration.unregister"(
    	String registeredBy	
     , 	Timestamp registeredDate	
     , 	String updatedBy	
     , 	Timestamp updatedDate	
     , 	String deviceNo	
     , 	String serialNo	) {
    (new webDatabase.DeviceRegistration()).unregister(
        	registeredBy
         , 	registeredDate
         , 	updatedBy
         , 	updatedDate
         , 	deviceNo
         , 	serialNo)
}


def static "webDatabase.DeviceRegistration.unlock"(
    	String serialNo	
     , 	String updatedBy	
     , 	Timestamp updatedDate	) {
    (new webDatabase.DeviceRegistration()).unlock(
        	serialNo
         , 	updatedBy
         , 	updatedDate)
}


def static "webDatabase.DeviceRegistration.lock"(
    	String serialNo	
     , 	String updatedBy	
     , 	Timestamp updatedDate	) {
    (new webDatabase.DeviceRegistration()).lock(
        	serialNo
         , 	updatedBy
         , 	updatedDate)
}


def static "webDatabase.DeviceRegistration.register"(
    	Timestamp lastActivity	
     , 	String serialNo	
     , 	String updatedBy	
     , 	Timestamp updatedDate	) {
    (new webDatabase.DeviceRegistration()).register(
        	lastActivity
         , 	serialNo
         , 	updatedBy
         , 	updatedDate)
}


def static "webDatabase.KickerLogin.releaseLoginFO"(
    	String username	
     , 	String password	
     , 	String corpId	
     , 	String dbAlias	
     , 	String stepGroupName	) {
    (new webDatabase.KickerLogin()).releaseLoginFO(
        	username
         , 	password
         , 	corpId
         , 	dbAlias
         , 	stepGroupName)
}


def static "webDatabase.KickerLogin.releaseLoginBO"(
    	String username	
     , 	String password	
     , 	String dbAlias	
     , 	String stepGroupName	) {
    (new webDatabase.KickerLogin()).releaseLoginBO(
        	username
         , 	password
         , 	dbAlias
         , 	stepGroupName)
}


def static "approvalMatrix.setApprovalLevel.runsetApprovalMatrixLevel"(
    	String level	
     , 	String groupChosen	) {
    (new approvalMatrix.setApprovalLevel()).runsetApprovalMatrixLevel(
        	level
         , 	groupChosen)
}


def static "keys.SendKeys.handleInput"(
    	TestObject objectPath	
     , 	String inputValue	) {
    (new keys.SendKeys()).handleInput(
        	objectPath
         , 	inputValue)
}


def static "webDatabase.CorpUserMaintenance.inactivate"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.CorpUserMaintenance()).inactivate(
        	userId
         , 	corpId)
}


def static "webDatabase.CorpUserMaintenance.lock"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.CorpUserMaintenance()).lock(
        	userId
         , 	corpId)
}


def static "webDatabase.CorpUserMaintenance.activate"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.CorpUserMaintenance()).activate(
        	userId
         , 	corpId)
}


def static "keys.transactionRate.verifyEquivalent"() {
    (new keys.transactionRate()).verifyEquivalent()
}


def static "keys.transactionRate.getLocalSpecialRate"(
    	String foreignCurrency	
     , 	String anotherCurrency	
     , 	String targetStatus	) {
    (new keys.transactionRate()).getLocalSpecialRate(
        	foreignCurrency
         , 	anotherCurrency
         , 	targetStatus)
}


def static "keys.transactionRate.getForexCrossSpecialRate"(
    	String foreignCurrency	
     , 	String foreignCurrency2	
     , 	String targetStatus	) {
    (new keys.transactionRate()).getForexCrossSpecialRate(
        	foreignCurrency
         , 	foreignCurrency2
         , 	targetStatus)
}


def static "keys.basicOperation.sumResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	
     , 	int roundingValue	
     , 	String formatDate	) {
    (new keys.basicOperation()).sumResultInString(
        	addInput
         , 	currencyFormat
         , 	roundingValue
         , 	formatDate)
}


def static "keys.basicOperation.substractResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).substractResultInString(
        	addInput
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.multipleResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).multipleResultInString(
        	addInput
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.divideResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).divideResultInString(
        	addInput
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.getPercentageResultInString"(
    	String Amount	
     , 	String percentage	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).getPercentageResultInString(
        	Amount
         , 	percentage
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.compareWithMinMaxResultInString"(
    	String Amount	
     , 	String min	
     , 	String max	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).compareWithMinMaxResultInString(
        	Amount
         , 	min
         , 	max
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.verifyLessThanOrEquals"(
    	String record	
     , 	String totalRecord	) {
    (new keys.basicOperation()).verifyLessThanOrEquals(
        	record
         , 	totalRecord)
}


def static "keys.basicOperation.verifyLessThanOrEquals"(
    	String record	
     , 	int totalRecord	) {
    (new keys.basicOperation()).verifyLessThanOrEquals(
        	record
         , 	totalRecord)
}


def static "keys.basicOperation.sumResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new keys.basicOperation()).sumResultInString(
        	addInput
         , 	currencyFormat
         , 	roundingValue)
}


def static "keys.basicOperation.sumResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).sumResultInString(
        	addInput
         , 	currencyFormat)
}


def static "keys.basicOperation.sumResultInString"(
    	List addInput	) {
    (new keys.basicOperation()).sumResultInString(
        	addInput)
}


def static "keys.basicOperation.substractResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).substractResultInString(
        	addInput
         , 	currencyFormat)
}


def static "keys.basicOperation.substractResultInString"(
    	List addInput	) {
    (new keys.basicOperation()).substractResultInString(
        	addInput)
}


def static "keys.basicOperation.multipleResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).multipleResultInString(
        	addInput
         , 	currencyFormat)
}


def static "keys.basicOperation.multipleResultInString"(
    	List addInput	) {
    (new keys.basicOperation()).multipleResultInString(
        	addInput)
}


def static "keys.basicOperation.divideResultInString"(
    	List addInput	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).divideResultInString(
        	addInput
         , 	currencyFormat)
}


def static "keys.basicOperation.divideResultInString"(
    	List addInput	) {
    (new keys.basicOperation()).divideResultInString(
        	addInput)
}


def static "keys.basicOperation.getPercentageResultInString"(
    	String Amount	
     , 	String percentage	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).getPercentageResultInString(
        	Amount
         , 	percentage
         , 	currencyFormat)
}


def static "keys.basicOperation.getPercentageResultInString"(
    	String Amount	
     , 	String percentage	) {
    (new keys.basicOperation()).getPercentageResultInString(
        	Amount
         , 	percentage)
}


def static "keys.basicOperation.compareWithMinMaxResultInString"(
    	String Amount	
     , 	String min	
     , 	String max	
     , 	Boolean currencyFormat	) {
    (new keys.basicOperation()).compareWithMinMaxResultInString(
        	Amount
         , 	min
         , 	max
         , 	currencyFormat)
}


def static "keys.basicOperation.compareWithMinMaxResultInString"(
    	String Amount	
     , 	String min	
     , 	String max	) {
    (new keys.basicOperation()).compareWithMinMaxResultInString(
        	Amount
         , 	min
         , 	max)
}


def static "approvalMatrix.setApprovalMatrix1A1R.runsetApprovalMatrix1A1R"() {
    (new approvalMatrix.setApprovalMatrix1A1R()).runsetApprovalMatrix1A1R()
}


def static "approvalMatrix.setApprovalLevelBO.runsetApprovalMatrixLevelBO"(
    	String level	
     , 	String groupChosen	) {
    (new approvalMatrix.setApprovalLevelBO()).runsetApprovalMatrixLevelBO(
        	level
         , 	groupChosen)
}


def static "replaceDate.SpecialRateRefNo.replaceReferenceNo"(
    	String filePath	
     , 	int indexRefNo	) {
    (new replaceDate.SpecialRateRefNo()).replaceReferenceNo(
        	filePath
         , 	indexRefNo)
}


def static "replaceDate.handlePayroll.updateFileDate"(
    	String dirPath	
     , 	String date	
     , 	String param	
     , 	String dateformat	) {
    (new replaceDate.handlePayroll()).updateFileDate(
        	dirPath
         , 	date
         , 	param
         , 	dateformat)
}


def static "replaceDate.handlePayroll.updateFileDate"(
    	String dirPath	
     , 	String date	
     , 	String param	) {
    (new replaceDate.handlePayroll()).updateFileDate(
        	dirPath
         , 	date
         , 	param)
}


def static "replaceDate.handlePayroll.updateFileDate"(
    	String dirPath	
     , 	String date	) {
    (new replaceDate.handlePayroll()).updateFileDate(
        	dirPath
         , 	date)
}


def static "webCalendar.calendarEngine.resetCalendar"(
    	String[] arr	) {
    (new webCalendar.calendarEngine()).resetCalendar(
        	arr)
}


def static "webCalendar.calendarEngine.selectCalendar"(
    	String days	
     , 	String businessDay	
     , 	String fromTime	
     , 	String toTime	) {
    (new webCalendar.calendarEngine()).selectCalendar(
        	days
         , 	businessDay
         , 	fromTime
         , 	toTime)
}


def static "webCalendar.calendarEngine.selectTodayCalendar"(
    	boolean isWorkday	) {
    (new webCalendar.calendarEngine()).selectTodayCalendar(
        	isWorkday)
}


def static "webCalendar.calendarEngine.addCalendar"(
    	String description	
     , 	String currency	) {
    (new webCalendar.calendarEngine()).addCalendar(
        	description
         , 	currency)
}


def static "webCalendar.calendarEngine.selectCalendar"(
    	String days	
     , 	String fromTime	
     , 	String toTime	) {
    (new webCalendar.calendarEngine()).selectCalendar(
        	days
         , 	fromTime
         , 	toTime)
}


def static "report.CompareCSV.extractDownloadedReport"(
    	String dirPath	
     , 	boolean shouldExtract	) {
    (new report.CompareCSV()).extractDownloadedReport(
        	dirPath
         , 	shouldExtract)
}


def static "report.CompareCSV.doCompare"(
    	List listContent	
     , 	File csvAutomate	
     , 	String startPeriod	
     , 	String endPeriod	
     , 	String requestDate	
     , 	String filename	
     , 	File downloadedZip	) {
    (new report.CompareCSV()).doCompare(
        	listContent
         , 	csvAutomate
         , 	startPeriod
         , 	endPeriod
         , 	requestDate
         , 	filename
         , 	downloadedZip)
}


def static "report.CompareCSV.getInquiryListContent"(
    	String idFrameLogin	
     , 	String idMainFrame	
     , 	String idTable	) {
    (new report.CompareCSV()).getInquiryListContent(
        	idFrameLogin
         , 	idMainFrame
         , 	idTable)
}


def static "report.CompareCSV.getDownloadParameter"(
    	String idFrameLogin	
     , 	String idMainFrame	
     , 	String idTable	
     , 	String idFromDate	
     , 	String idToDate	) {
    (new report.CompareCSV()).getDownloadParameter(
        	idFrameLogin
         , 	idMainFrame
         , 	idTable
         , 	idFromDate
         , 	idToDate)
}


def static "report.CompareCSV.compareCsvToWeb"(
    	List inqListContentTable	
     , 	String idFrameLogin	
     , 	String idMainFrame	
     , 	String idTable	
     , 	String idFromDate	
     , 	String idToDate	
     , 	String dirPath	) {
    (new report.CompareCSV()).compareCsvToWeb(
        	inqListContentTable
         , 	idFrameLogin
         , 	idMainFrame
         , 	idTable
         , 	idFromDate
         , 	idToDate
         , 	dirPath)
}


def static "report.CompareCSV.parseDate"(
    	String inputDate	
     , 	String format	) {
    (new report.CompareCSV()).parseDate(
        	inputDate
         , 	format)
}


def static "report.CompareCSV.formatDate"(
    	Date inputDate	
     , 	String format	) {
    (new report.CompareCSV()).formatDate(
        	inputDate
         , 	format)
}


def static "verification.VerifyTextType.verifyTextIsNumerical"(
    	String text	
     , 	Integer indexBegin	
     , 	Integer indexEnd	) {
    (new verification.VerifyTextType()).verifyTextIsNumerical(
        	text
         , 	indexBegin
         , 	indexEnd)
}


def static "verification.VerifyTextType.verifyTextIsAlphabetical"(
    	String text	
     , 	Integer indexBegin	
     , 	Integer indexEnd	) {
    (new verification.VerifyTextType()).verifyTextIsAlphabetical(
        	text
         , 	indexBegin
         , 	indexEnd)
}


def static "verification.VerifyTextType.verifyTextIsAlphaNumeric"(
    	String text	
     , 	Integer indexBegin	
     , 	Integer indexEnd	) {
    (new verification.VerifyTextType()).verifyTextIsAlphaNumeric(
        	text
         , 	indexBegin
         , 	indexEnd)
}


def static "verification.VerifyTextType.verifyTextIsNumerical"(
    	String text	
     , 	Integer indexBegin	) {
    (new verification.VerifyTextType()).verifyTextIsNumerical(
        	text
         , 	indexBegin)
}


def static "verification.VerifyTextType.verifyTextIsNumerical"(
    	String text	) {
    (new verification.VerifyTextType()).verifyTextIsNumerical(
        	text)
}


def static "verification.VerifyTextType.verifyTextIsAlphabetical"(
    	String text	
     , 	Integer indexBegin	) {
    (new verification.VerifyTextType()).verifyTextIsAlphabetical(
        	text
         , 	indexBegin)
}


def static "verification.VerifyTextType.verifyTextIsAlphabetical"(
    	String text	) {
    (new verification.VerifyTextType()).verifyTextIsAlphabetical(
        	text)
}


def static "verification.VerifyTextType.verifyTextIsAlphaNumeric"(
    	String text	
     , 	Integer indexBegin	) {
    (new verification.VerifyTextType()).verifyTextIsAlphaNumeric(
        	text
         , 	indexBegin)
}


def static "verification.VerifyTextType.verifyTextIsAlphaNumeric"(
    	String text	) {
    (new verification.VerifyTextType()).verifyTextIsAlphaNumeric(
        	text)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnHeader"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnHeader(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_FO.getTotalRowPerPage"() {
    (new handleWebTable.HTMLTableHelper_FO()).getTotalRowPerPage()
}


def static "handleWebTable.HTMLTableHelper_FO.getTotalRowPerPageString"() {
    (new handleWebTable.HTMLTableHelper_FO()).getTotalRowPerPageString()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainsSpecificValue"(
    	List data	
     , 	FailureHandling handler	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainsSpecificValue(
        	data
         , 	handler)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainingSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainingSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickListOnTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickListOnTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainsSpecificValueOutputBoolean"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainsSpecificValueOutputBoolean(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnResultTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnResultTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnCurrentTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnCurrentTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnNewTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnNewTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.getTotalListOnTableAllPages"() {
    (new handleWebTable.HTMLTableHelper_FO()).getTotalListOnTableAllPages()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyAscendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyAscendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyDescendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyDescendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_FO.verifySortedRandomlyByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifySortedRandomlyByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyDateIsMatchWithSearchDate"(
    	String input_dateFrom	
     , 	String input_dateTo	
     , 	List columnIndexes	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyDateIsMatchWithSearchDate(
        	input_dateFrom
         , 	input_dateTo
         , 	columnIndexes
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_FO.checkOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.unCheckOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).unCheckOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.unCheckAllRowOnSpecificHeader"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).unCheckAllRowOnSpecificHeader(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.checkOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper_FO()).checkOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper_FO.unCheckOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper_FO()).unCheckOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper_FO.clickEditIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickEditIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDetailIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDetailIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickEyeIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickEyeIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDeleteLabelOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDeleteLabelOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDeleteIconOnSpecificRowPayroll"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDeleteIconOnSpecificRowPayroll(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDeleteIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDeleteIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDownloadIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDownloadIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickLockIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickUnLockIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickUnLockIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickResetIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickResendIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnHeaderPopUp"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnHeaderPopUp(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnPopUpTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnPopUpTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.checkOnSpecificRowPopUp"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkOnSpecificRowPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckOnSpecificRowPopUp"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckOnSpecificRowPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLink"(
    	List data	
     , 	String hyperlinkName	
     , 	FailureHandling handler	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLink(
        	data
         , 	hyperlinkName
         , 	handler)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLinkAlternative"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLinkAlternative(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickSpanHyperLink"(
    	List data	
     , 	String hyperlinkName	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickSpanHyperLink(
        	data
         , 	hyperlinkName)
}


def static "handleWebTable.HTMLTableHelper_FO.clickTdSpecificRow"(
    	List data	
     , 	String hyperlinkName	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickTdSpecificRow(
        	data
         , 	hyperlinkName)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLinkPopUp"(
    	String data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLinkPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.accessDetailApprovalMatrix"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).accessDetailApprovalMatrix(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableNotContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableNotContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.DoubleClickOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).DoubleClickOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnContainsSpecificValue"(
    	String input	
     , 	int colIndex	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnContainsSpecificValue(
        	input
         , 	colIndex)
}


def static "handleWebTable.HTMLTableHelper_FO.editonAccountSetupList"(
    	List data	
     , 	String aliasName	
     , 	String maxDebit	) {
    (new handleWebTable.HTMLTableHelper_FO()).editonAccountSetupList(
        	data
         , 	aliasName
         , 	maxDebit)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettings"(
    	String data	
     , 	String app	
     , 	String email	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettings(
        	data
         , 	app
         , 	email)
}


def static "handleWebTable.HTMLTableHelper_FO.clickonBellIconOnNotification"(
    	String index	
     , 	String type	
     , 	String message	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickonBellIconOnNotification(
        	index
         , 	type
         , 	message)
}


def static "handleWebTable.HTMLTableHelper_FO.clickonDeleteIconOnNotification"(
    	String index	
     , 	String type	
     , 	String message	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickonDeleteIconOnNotification(
        	index
         , 	type
         , 	message)
}


def static "handleWebTable.HTMLTableHelper_FO.checkonGeneralSetupOption"(
    	String option	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkonGeneralSetupOption(
        	option)
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckonGeneralSetupOption"(
    	String option	) {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckonGeneralSetupOption(
        	option)
}


def static "handleWebTable.HTMLTableHelper_FO.checkAllonGeneralSetupOption"() {
    (new handleWebTable.HTMLTableHelper_FO()).checkAllonGeneralSetupOption()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainsSpecificValueUsersMaintenance"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainsSpecificValueUsersMaintenance(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.customizeTableMoveItemfromSelectedtoAvailable"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).customizeTableMoveItemfromSelectedtoAvailable(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.customizeTableMoveItemfromAvailabletoSelected"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).customizeTableMoveItemfromAvailabletoSelected(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.clickonBellImportantIconOnNotification"(
    	String index	
     , 	String type	
     , 	String message	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickonBellImportantIconOnNotification(
        	index
         , 	type
         , 	message)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettingsUncheck"(
    	String data	
     , 	String app	
     , 	String email	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettingsUncheck(
        	data
         , 	app
         , 	email)
}


def static "handleWebTable.HTMLTableHelper_FO.removeEmailTag"() {
    (new handleWebTable.HTMLTableHelper_FO()).removeEmailTag()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyFormatDate"(
    	String index	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyFormatDate(
        	index
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLinkActivityLogBO"(
    	List data	
     , 	String index	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLinkActivityLogBO(
        	data
         , 	index)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnHeader2"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnHeader2(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_FO.dragandDropSelenium"(
    	int x	
     , 	int y	
     , 	String input	) {
    (new handleWebTable.HTMLTableHelper_FO()).dragandDropSelenium(
        	x
         , 	y
         , 	input)
}


def static "handleWebTable.HTMLTableHelper_FO.clickPrintButton"(
    	String fileName	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickPrintButton(
        	fileName)
}


def static "handleWebTable.HTMLTableHelper_FO.tableUploadListPayroll"(
    	List data	
     , 	String hyperlinkName	) {
    (new handleWebTable.HTMLTableHelper_FO()).tableUploadListPayroll(
        	data
         , 	hyperlinkName)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyCutOffTime"(
    	String head	
     , 	String item	
     , 	String verifyHour	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyCutOffTime(
        	head
         , 	item
         , 	verifyHour)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyPendingTaskSummarySelectedTask"() {
    (new handleWebTable.HTMLTableHelper_FO()).verifyPendingTaskSummarySelectedTask()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyPendingTaskSummaryTransactionAmount"() {
    (new handleWebTable.HTMLTableHelper_FO()).verifyPendingTaskSummaryTransactionAmount()
}


def static "handleWebTable.HTMLTableHelper_FO.customizeTableSelectMultipleFromAvailable"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).customizeTableSelectMultipleFromAvailable(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.customizeTableSelectMultipleFromSelected"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).customizeTableSelectMultipleFromSelected(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.checkAllowDebitAccountGroup"(
    	String product	
     , 	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkAllowDebitAccountGroup(
        	product
         , 	data)
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckAllowDebitAccountGroup"(
    	String product	
     , 	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckAllowDebitAccountGroup(
        	product
         , 	data)
}


def static "handleWebTable.HTMLTableHelper_FO.checkAllowCreditAccountGroup"(
    	String product	
     , 	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkAllowCreditAccountGroup(
        	product
         , 	data)
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckAllowCreditAccountGroup"(
    	String product	
     , 	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckAllowCreditAccountGroup(
        	product
         , 	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnContentMatchSpecificDateFormat"(
    	String format	
     , 	int colIndex	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnContentMatchSpecificDateFormat(
        	format
         , 	colIndex)
}


def static "handleWebTable.HTMLTableHelper_FO.checkLastRowonTable"() {
    (new handleWebTable.HTMLTableHelper_FO()).checkLastRowonTable()
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckLastRowonTable"() {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckLastRowonTable()
}


def static "handleWebTable.HTMLTableHelper_FO.clickTransactionNoHyperlinkLastRowonTable"() {
    (new handleWebTable.HTMLTableHelper_FO()).clickTransactionNoHyperlinkLastRowonTable()
}


def static "handleWebTable.HTMLTableHelper_FO.clickTransactionNoHyperlinkFirstRowonTable"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickTransactionNoHyperlinkFirstRowonTable(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyCloneResultOnMultipleTransferManualInput"(
    	List rowCompared	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyCloneResultOnMultipleTransferManualInput(
        	rowCompared)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLinkBasedOnColumnIndex"(
    	List data	
     , 	String colIndex	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLinkBasedOnColumnIndex(
        	data
         , 	colIndex)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLinkBasedOnRowIndex"(
    	List data	
     , 	String rowIndex	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLinkBasedOnRowIndex(
        	data
         , 	rowIndex)
}


def static "handleWebTable.HTMLTableHelper_FO.selectonSearchFilter"(
    	String textValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).selectonSearchFilter(
        	textValue)
}


def static "handleWebTable.HTMLTableHelper_FO.selectItemonDropdown"(
    	String indicatorId	
     , 	String textValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).selectItemonDropdown(
        	indicatorId
         , 	textValue)
}


def static "handleWebTable.HTMLTableHelper_FO.checkRadioButtonwithInput"(
    	String textValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).checkRadioButtonwithInput(
        	textValue)
}


def static "handleWebTable.HTMLTableHelper_FO.uncheckRadioButtonwithInput"(
    	String textValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).uncheckRadioButtonwithInput(
        	textValue)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupAddandVerify"(
    	String account	
     , 	List products	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupAddandVerify(
        	account
         , 	products)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupEditAccountAllow"(
    	String account	
     , 	List products	
     , 	String debitAllow	
     , 	String creditAllow	
     , 	String inquiryAllow	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupEditAccountAllow(
        	account
         , 	products
         , 	debitAllow
         , 	creditAllow
         , 	inquiryAllow)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupEditAccountAllow"(
    	String account	
     , 	List products	
     , 	String inquiryAllow	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupEditAccountAllow(
        	account
         , 	products
         , 	inquiryAllow)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupGetAccountProductList"() {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupGetAccountProductList()
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupVerifyDataAccountProductList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupVerifyDataAccountProductList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupVerifyNewValueAccountProductList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupVerifyNewValueAccountProductList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.AccountGroupVerifyCurrentValueAccountProductList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).AccountGroupVerifyCurrentValueAccountProductList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyRowResultonDateRange"(
    	String dateColumn	
     , 	String fromDate	
     , 	String toDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyRowResultonDateRange(
        	dateColumn
         , 	fromDate
         , 	toDate)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyRowResultonDateRangeBO"(
    	String dateColumn	
     , 	String fromDate	
     , 	String toDate	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyRowResultonDateRangeBO(
        	dateColumn
         , 	fromDate
         , 	toDate)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyRowResultonDateRangeWeeklyMonthly"(
    	String dateColumn	
     , 	String status	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyRowResultonDateRangeWeeklyMonthly(
        	dateColumn
         , 	status)
}


def static "handleWebTable.HTMLTableHelper_FO.userGroupAddtolist"(
    	List featureList	
     , 	List productList	) {
    (new handleWebTable.HTMLTableHelper_FO()).userGroupAddtolist(
        	featureList
         , 	productList)
}


def static "handleWebTable.HTMLTableHelper_FO.getUserGrouplist"(
    	String page	) {
    (new handleWebTable.HTMLTableHelper_FO()).getUserGrouplist(
        	page)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyDetailLimitList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyDetailLimitList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyDataLimitList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyDataLimitList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupEditDataLimitList"(
    	String feature	
     , 	String product	
     , 	String currencyMatrix	
     , 	String limitValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupEditDataLimitList(
        	feature
         , 	product
         , 	currencyMatrix
         , 	limitValue)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditCurrentDataLimitList"(
    	java.util.HashMap<String, List> parsedMap	
     , 	String curr	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditCurrentDataLimitList(
        	parsedMap
         , 	curr)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditCurrentDataLimitList2"(
    	java.util.HashMap<String, List> parsedMap	
     , 	String curr	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditCurrentDataLimitList2(
        	parsedMap
         , 	curr)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditUpdatedDataLimitList2"(
    	java.util.HashMap<String, List> parsedMap	
     , 	String curr	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditUpdatedDataLimitList2(
        	parsedMap
         , 	curr)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditUpdatedDataLimitList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditUpdatedDataLimitList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyRowResultonCurrencyRange"(
    	String currencyColumn	
     , 	String minValue	
     , 	String maxValue	
     , 	String currency	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyRowResultonCurrencyRange(
        	currencyColumn
         , 	minValue
         , 	maxValue
         , 	currency)
}


def static "handleWebTable.HTMLTableHelper_FO.getPendingTaskList"() {
    (new handleWebTable.HTMLTableHelper_FO()).getPendingTaskList()
}


def static "handleWebTable.HTMLTableHelper_FO.getTotalCheckedRowPerPage"() {
    (new handleWebTable.HTMLTableHelper_FO()).getTotalCheckedRowPerPage()
}


def static "handleWebTable.HTMLTableHelper_FO.getCheckedPendingTaskList"() {
    (new handleWebTable.HTMLTableHelper_FO()).getCheckedPendingTaskList()
}


def static "handleWebTable.HTMLTableHelper_FO.getCheckedTableList"() {
    (new handleWebTable.HTMLTableHelper_FO()).getCheckedTableList()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyPendingTask"(
    	java.util.HashMap<String, List> parsedData	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyPendingTask(
        	parsedData)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyTableList"(
    	java.util.HashMap<String, List> parsedData	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyTableList(
        	parsedData)
}


def static "handleWebTable.HTMLTableHelper_FO.getDataOnColumnSpecificValue"(
    	String filenamecolumn	
     , 	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).getDataOnColumnSpecificValue(
        	filenamecolumn
         , 	data)
}


def static "handleWebTable.HTMLTableHelper_FO.countRowContainingSpecificValue"(
    	String value	) {
    (new handleWebTable.HTMLTableHelper_FO()).countRowContainingSpecificValue(
        	value)
}


def static "handleWebTable.HTMLTableHelper_FO.countRowNotContainingSpecificValue"(
    	String value	) {
    (new handleWebTable.HTMLTableHelper_FO()).countRowNotContainingSpecificValue(
        	value)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainsSpecificObject"(
    	List data	
     , 	TestObject target	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainsSpecificObject(
        	data
         , 	target)
}


def static "handleWebTable.HTMLTableHelper_FO.sumColumnValues"(
    	String index	
     , 	String status	
     , 	Boolean currencyFormat	
     , 	int roundingValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).sumColumnValues(
        	index
         , 	status
         , 	currencyFormat
         , 	roundingValue)
}


def static "handleWebTable.HTMLTableHelper_FO.editContactonCorporateRegistration"(
    	String index	
     , 	String extName	
     , 	String Name	
     , 	String PhoneNo	
     , 	String MobilePhoneNo	
     , 	String Email	) {
    (new handleWebTable.HTMLTableHelper_FO()).editContactonCorporateRegistration(
        	index
         , 	extName
         , 	Name
         , 	PhoneNo
         , 	MobilePhoneNo
         , 	Email)
}


def static "handleWebTable.HTMLTableHelper_FO.editCorporateAdministrationOnCorporateRegistration"(
    	String index	
     , 	String userID	
     , 	String Name	
     , 	String Role	
     , 	String Email	
     , 	String PhoneNo	
     , 	String Token	) {
    (new handleWebTable.HTMLTableHelper_FO()).editCorporateAdministrationOnCorporateRegistration(
        	index
         , 	userID
         , 	Name
         , 	Role
         , 	Email
         , 	PhoneNo
         , 	Token)
}


def static "handleWebTable.HTMLTableHelper_FO.editChargeDefaultPackage"(
    	List data	
     , 	String Currency	
     , 	String Method	
     , 	String ChargeValue	
     , 	String billingInstruction	) {
    (new handleWebTable.HTMLTableHelper_FO()).editChargeDefaultPackage(
        	data
         , 	Currency
         , 	Method
         , 	ChargeValue
         , 	billingInstruction)
}


def static "handleWebTable.HTMLTableHelper_FO.editLimitDefaultPackage"(
    	String product	
     , 	String currencyMatrix	
     , 	String maxNoTrxPerDay	
     , 	String Currency	
     , 	String maxTrxAmountPerDay	
     , 	String minAmountPerTrx	
     , 	String maxAmountPerTrx	) {
    (new handleWebTable.HTMLTableHelper_FO()).editLimitDefaultPackage(
        	product
         , 	currencyMatrix
         , 	maxNoTrxPerDay
         , 	Currency
         , 	maxTrxAmountPerDay
         , 	minAmountPerTrx
         , 	maxAmountPerTrx)
}


def static "handleWebTable.HTMLTableHelper_FO.editServiceHourDefaultPackage"(
    	String product	
     , 	String startTime	
     , 	String endTime	
     , 	String businessDay	) {
    (new handleWebTable.HTMLTableHelper_FO()).editServiceHourDefaultPackage(
        	product
         , 	startTime
         , 	endTime
         , 	businessDay)
}


def static "handleWebTable.HTMLTableHelper_FO.accountMaintenanceEditAccountAllow"(
    	List accountInfo	
     , 	String debitAllow	
     , 	String creditAllow	
     , 	String inquiryAllow	) {
    (new handleWebTable.HTMLTableHelper_FO()).accountMaintenanceEditAccountAllow(
        	accountInfo
         , 	debitAllow
         , 	creditAllow
         , 	inquiryAllow)
}


def static "handleWebTable.HTMLTableHelper_FO.clickOnActionIconOnBankUserManager"(
    	List rowData	
     , 	String actionClicked	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickOnActionIconOnBankUserManager(
        	rowData
         , 	actionClicked)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyPageTableChanges"(
    	String destinationPage	
     , 	int totalRowPerPage	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyPageTableChanges(
        	destinationPage
         , 	totalRowPerPage)
}


def static "handleWebTable.HTMLTableHelper_FO.clickOnActionIconOnAuthenticationDevice"(
    	List rowData	
     , 	String actionClicked	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickOnActionIconOnAuthenticationDevice(
        	rowData
         , 	actionClicked)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyMenuPackage"(
    	List listMenu	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyMenuPackage(
        	listMenu)
}


def static "handleWebTable.HTMLTableHelper_FO.getBankLimitTransaction"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String column	) {
    (new handleWebTable.HTMLTableHelper_FO()).getBankLimitTransaction(
        	product
         , 	menu
         , 	currencyMatrix
         , 	column)
}


def static "handleWebTable.HTMLTableHelper_FO.editBankLimitTransaction"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String currency	
     , 	String minLimit	
     , 	String maxLimit	) {
    (new handleWebTable.HTMLTableHelper_FO()).editBankLimitTransaction(
        	product
         , 	menu
         , 	currencyMatrix
         , 	currency
         , 	minLimit
         , 	maxLimit)
}


def static "handleWebTable.HTMLTableHelper_FO.clickOnActionIconOnServicePackage"(
    	List rowData	
     , 	String actionClicked	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickOnActionIconOnServicePackage(
        	rowData
         , 	actionClicked)
}


def static "handleWebTable.HTMLTableHelper_FO.clickOnActionIconOnCustomPackage"(
    	List rowData	
     , 	String actionClicked	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickOnActionIconOnCustomPackage(
        	rowData
         , 	actionClicked)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyTableHeaderOnDefaultPackageCharge"(
    	List headerValue	
     , 	String section	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyTableHeaderOnDefaultPackageCharge(
        	headerValue
         , 	section)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyTableHeaderOnDefaultPackageLimit"(
    	List headerValue	
     , 	String section	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyTableHeaderOnDefaultPackageLimit(
        	headerValue
         , 	section)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyTableHeaderOnDefaultPackageServiceHour"(
    	List headerValue	
     , 	String section	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyTableHeaderOnDefaultPackageServiceHour(
        	headerValue
         , 	section)
}


def static "handleWebTable.HTMLTableHelper_FO.editChargeCustomPackage"(
    	List data	
     , 	String Currency	
     , 	String Method	
     , 	String ChargeValue	
     , 	String billingInstruction	) {
    (new handleWebTable.HTMLTableHelper_FO()).editChargeCustomPackage(
        	data
         , 	Currency
         , 	Method
         , 	ChargeValue
         , 	billingInstruction)
}


def static "handleWebTable.HTMLTableHelper_FO.editLimitCustomPackage"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String maxNoTrxPerDay	
     , 	String Currency	
     , 	String maxTrxAmountPerDay	
     , 	String minAmountPerTrx	
     , 	String maxAmountPerTrx	) {
    (new handleWebTable.HTMLTableHelper_FO()).editLimitCustomPackage(
        	product
         , 	menu
         , 	currencyMatrix
         , 	maxNoTrxPerDay
         , 	Currency
         , 	maxTrxAmountPerDay
         , 	minAmountPerTrx
         , 	maxAmountPerTrx)
}


def static "handleWebTable.HTMLTableHelper_FO.editServiceHourCustomPackage"(
    	String product	
     , 	String menu	
     , 	String startTime	
     , 	String endTime	
     , 	String businessDay	) {
    (new handleWebTable.HTMLTableHelper_FO()).editServiceHourCustomPackage(
        	product
         , 	menu
         , 	startTime
         , 	endTime
         , 	businessDay)
}


def static "handleWebTable.HTMLTableHelper_FO.addMenuServicePackage"(
    	List menuChoices	) {
    (new handleWebTable.HTMLTableHelper_FO()).addMenuServicePackage(
        	menuChoices)
}


def static "handleWebTable.HTMLTableHelper_FO.addProductServicePackage"(
    	List productChoices	) {
    (new handleWebTable.HTMLTableHelper_FO()).addProductServicePackage(
        	productChoices)
}


def static "handleWebTable.HTMLTableHelper_FO.editChargeServicePackage"(
    	List data	
     , 	String Currency	
     , 	String Method	
     , 	String ChargeValue	
     , 	String billingInstruction	) {
    (new handleWebTable.HTMLTableHelper_FO()).editChargeServicePackage(
        	data
         , 	Currency
         , 	Method
         , 	ChargeValue
         , 	billingInstruction)
}


def static "handleWebTable.HTMLTableHelper_FO.editLimitServicePackage"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String maxNoTrxPerDay	
     , 	String Currency	
     , 	String maxTrxAmountPerDay	
     , 	String minAmountPerTrx	
     , 	String maxAmountPerTrx	) {
    (new handleWebTable.HTMLTableHelper_FO()).editLimitServicePackage(
        	product
         , 	menu
         , 	currencyMatrix
         , 	maxNoTrxPerDay
         , 	Currency
         , 	maxTrxAmountPerDay
         , 	minAmountPerTrx
         , 	maxAmountPerTrx)
}


def static "handleWebTable.HTMLTableHelper_FO.editServiceHourServicePackage"(
    	String product	
     , 	String menu	
     , 	String startTime	
     , 	String endTime	
     , 	String businessDay	) {
    (new handleWebTable.HTMLTableHelper_FO()).editServiceHourServicePackage(
        	product
         , 	menu
         , 	startTime
         , 	endTime
         , 	businessDay)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyDetailActionResultScreenPendingTask"(
    	String successMSG	
     , 	String menu	
     , 	String actionValue	
     , 	String userID	
     , 	String rejectReason	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyDetailActionResultScreenPendingTask(
        	successMSG
         , 	menu
         , 	actionValue
         , 	userID
         , 	rejectReason)
}


def static "handleWebTable.HTMLTableHelper_FO.getChargeDataCustomPackage"() {
    (new handleWebTable.HTMLTableHelper_FO()).getChargeDataCustomPackage()
}


def static "handleWebTable.HTMLTableHelper_FO.getLimitDataCustomPackage"() {
    (new handleWebTable.HTMLTableHelper_FO()).getLimitDataCustomPackage()
}


def static "handleWebTable.HTMLTableHelper_FO.verifyBankLimitTransactionExceedingLength"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String minLimit	
     , 	String maxLimit	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyBankLimitTransactionExceedingLength(
        	product
         , 	menu
         , 	currencyMatrix
         , 	minLimit
         , 	maxLimit)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancing"(
    	String ReferenceOreInvoiceNo	
     , 	String drawdownPercentage	
     , 	String loanAccountOwner	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancing(
        	ReferenceOreInvoiceNo
         , 	drawdownPercentage
         , 	loanAccountOwner)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancingUsingRowNo"(
    	String rowNo	
     , 	String drawdownPercentage	
     , 	String loanAccountOwner	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancingUsingRowNo(
        	rowNo
         , 	drawdownPercentage
         , 	loanAccountOwner)
}


def static "handleWebTable.HTMLTableHelper_FO.clickEditIconOnSpecificRowBasedOnRowNo"(
    	String rowNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickEditIconOnSpecificRowBasedOnRowNo(
        	rowNo)
}


def static "handleWebTable.HTMLTableHelper_FO.clickDeleteIconOnSpecificRowBasedOnRowNo"(
    	String rowNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickDeleteIconOnSpecificRowBasedOnRowNo(
        	rowNo)
}


def static "handleWebTable.HTMLTableHelper_FO.clickHyperLinkPendingTask"(
    	List data	
     , 	String hyperlinkName	
     , 	FailureHandling handler	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickHyperLinkPendingTask(
        	data
         , 	hyperlinkName
         , 	handler)
}


def static "handleWebTable.HTMLTableHelper_FO.getDataAllRow"(
    	int column	
     , 	int Row	) {
    (new handleWebTable.HTMLTableHelper_FO()).getDataAllRow(
        	column
         , 	Row)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnHeader"(
    	List columnHeaders	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnHeader(
        	columnHeaders)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyListOnTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyListOnTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyAscendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyAscendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyDescendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyDescendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText)
}


def static "handleWebTable.HTMLTableHelper_FO.clickNameHyperLink"(
    	List data	
     , 	String hyperlinkName	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickNameHyperLink(
        	data
         , 	hyperlinkName)
}


def static "handleWebTable.HTMLTableHelper_FO.editonAccountSetupList"(
    	List data	
     , 	String aliasName	) {
    (new handleWebTable.HTMLTableHelper_FO()).editonAccountSetupList(
        	data
         , 	aliasName)
}


def static "handleWebTable.HTMLTableHelper_FO.editonAccountSetupList"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_FO()).editonAccountSetupList(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettings"(
    	String data	
     , 	String app	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettings(
        	data
         , 	app)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettings"(
    	String data	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettings(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettingsUncheck"(
    	String data	
     , 	String app	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettingsUncheck(
        	data
         , 	app)
}


def static "handleWebTable.HTMLTableHelper_FO.editNotificationSettingsUncheck"(
    	String data	) {
    (new handleWebTable.HTMLTableHelper_FO()).editNotificationSettingsUncheck(
        	data)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyColumnHeader2"(
    	List columnHeaders	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyColumnHeader2(
        	columnHeaders)
}


def static "handleWebTable.HTMLTableHelper_FO.userGroupAddtolist"(
    	List featureList	) {
    (new handleWebTable.HTMLTableHelper_FO()).userGroupAddtolist(
        	featureList)
}


def static "handleWebTable.HTMLTableHelper_FO.getUserGrouplist"() {
    (new handleWebTable.HTMLTableHelper_FO()).getUserGrouplist()
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditCurrentDataLimitList"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditCurrentDataLimitList(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditCurrentDataLimitList2"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditCurrentDataLimitList2(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.UserGroupVerifyEditUpdatedDataLimitList2"(
    	java.util.HashMap<String, List> parsedMap	) {
    (new handleWebTable.HTMLTableHelper_FO()).UserGroupVerifyEditUpdatedDataLimitList2(
        	parsedMap)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyRowResultonCurrencyRange"(
    	String currencyColumn	
     , 	String minValue	
     , 	String maxValue	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyRowResultonCurrencyRange(
        	currencyColumn
         , 	minValue
         , 	maxValue)
}


def static "handleWebTable.HTMLTableHelper_FO.sumColumnValues"(
    	String index	
     , 	String status	
     , 	Boolean currencyFormat	) {
    (new handleWebTable.HTMLTableHelper_FO()).sumColumnValues(
        	index
         , 	status
         , 	currencyFormat)
}


def static "handleWebTable.HTMLTableHelper_FO.sumColumnValues"(
    	String index	
     , 	String status	) {
    (new handleWebTable.HTMLTableHelper_FO()).sumColumnValues(
        	index
         , 	status)
}


def static "handleWebTable.HTMLTableHelper_FO.sumColumnValues"(
    	String index	) {
    (new handleWebTable.HTMLTableHelper_FO()).sumColumnValues(
        	index)
}


def static "handleWebTable.HTMLTableHelper_FO.editCorporateAdministrationOnCorporateRegistration"(
    	String index	
     , 	String userID	
     , 	String Name	
     , 	String Role	
     , 	String Email	
     , 	String PhoneNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).editCorporateAdministrationOnCorporateRegistration(
        	index
         , 	userID
         , 	Name
         , 	Role
         , 	Email
         , 	PhoneNo)
}


def static "handleWebTable.HTMLTableHelper_FO.editCorporateAdministrationOnCorporateRegistration"(
    	String index	
     , 	String Name	
     , 	String Role	
     , 	String Email	
     , 	String PhoneNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).editCorporateAdministrationOnCorporateRegistration(
        	index
         , 	Name
         , 	Role
         , 	Email
         , 	PhoneNo)
}


def static "handleWebTable.HTMLTableHelper_FO.getBankLimitTransaction"(
    	String product	
     , 	String currencyMatrix	
     , 	String column	) {
    (new handleWebTable.HTMLTableHelper_FO()).getBankLimitTransaction(
        	product
         , 	currencyMatrix
         , 	column)
}


def static "handleWebTable.HTMLTableHelper_FO.editBankLimitTransaction"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String currency	
     , 	String minLimit	) {
    (new handleWebTable.HTMLTableHelper_FO()).editBankLimitTransaction(
        	product
         , 	menu
         , 	currencyMatrix
         , 	currency
         , 	minLimit)
}


def static "handleWebTable.HTMLTableHelper_FO.editBankLimitTransaction"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String currency	) {
    (new handleWebTable.HTMLTableHelper_FO()).editBankLimitTransaction(
        	product
         , 	menu
         , 	currencyMatrix
         , 	currency)
}


def static "handleWebTable.HTMLTableHelper_FO.editBankLimitTransaction"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	) {
    (new handleWebTable.HTMLTableHelper_FO()).editBankLimitTransaction(
        	product
         , 	menu
         , 	currencyMatrix)
}


def static "handleWebTable.HTMLTableHelper_FO.editBankLimitTransaction"(
    	String product	
     , 	String currencyMatrix	) {
    (new handleWebTable.HTMLTableHelper_FO()).editBankLimitTransaction(
        	product
         , 	currencyMatrix)
}


def static "handleWebTable.HTMLTableHelper_FO.editLimitServicePackage"(
    	String product	
     , 	String currencyMatrix	
     , 	String maxNoTrxPerDay	
     , 	String Currency	
     , 	String maxTrxAmountPerDay	
     , 	String minAmountPerTrx	
     , 	String maxAmountPerTrx	) {
    (new handleWebTable.HTMLTableHelper_FO()).editLimitServicePackage(
        	product
         , 	currencyMatrix
         , 	maxNoTrxPerDay
         , 	Currency
         , 	maxTrxAmountPerDay
         , 	minAmountPerTrx
         , 	maxAmountPerTrx)
}


def static "handleWebTable.HTMLTableHelper_FO.editServiceHourServicePackage"(
    	String product	
     , 	String startTime	
     , 	String endTime	
     , 	String businessDay	) {
    (new handleWebTable.HTMLTableHelper_FO()).editServiceHourServicePackage(
        	product
         , 	startTime
         , 	endTime
         , 	businessDay)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyDetailActionResultScreenPendingTask"(
    	String successMSG	
     , 	String menu	
     , 	String actionValue	
     , 	String userID	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyDetailActionResultScreenPendingTask(
        	successMSG
         , 	menu
         , 	actionValue
         , 	userID)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyBankLimitTransactionExceedingLength"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	
     , 	String minLimit	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyBankLimitTransactionExceedingLength(
        	product
         , 	menu
         , 	currencyMatrix
         , 	minLimit)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyBankLimitTransactionExceedingLength"(
    	String product	
     , 	String menu	
     , 	String currencyMatrix	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyBankLimitTransactionExceedingLength(
        	product
         , 	menu
         , 	currencyMatrix)
}


def static "handleWebTable.HTMLTableHelper_FO.verifyBankLimitTransactionExceedingLength"(
    	String product	
     , 	String currencyMatrix	) {
    (new handleWebTable.HTMLTableHelper_FO()).verifyBankLimitTransactionExceedingLength(
        	product
         , 	currencyMatrix)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancing"(
    	String ReferenceOreInvoiceNo	
     , 	String drawdownPercentage	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancing(
        	ReferenceOreInvoiceNo
         , 	drawdownPercentage)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancing"(
    	String ReferenceOreInvoiceNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancing(
        	ReferenceOreInvoiceNo)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancingUsingRowNo"(
    	String rowNo	
     , 	String drawdownPercentage	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancingUsingRowNo(
        	rowNo
         , 	drawdownPercentage)
}


def static "handleWebTable.HTMLTableHelper_FO.editRequestSellerFinancingUsingRowNo"(
    	String rowNo	) {
    (new handleWebTable.HTMLTableHelper_FO()).editRequestSellerFinancingUsingRowNo(
        	rowNo)
}


def static "handleWebTable.HTMLTableHelper_FO.clickHyperLinkPendingTask"(
    	List data	
     , 	String hyperlinkName	) {
    (new handleWebTable.HTMLTableHelper_FO()).clickHyperLinkPendingTask(
        	data
         , 	hyperlinkName)
}


def static "uploadFile.uploadFile.uploadFiletest"(
    	TestObject to	
     , 	String filePath	) {
    (new uploadFile.uploadFile()).uploadFiletest(
        	to
         , 	filePath)
}

 /**
	 * Upload file.
	 *
	 * @param object The object from which we can click to choose files.
	 * @param file The full path of the file that needs to upload.
	 */ 
def static "uploadFile.uploadFile.uploadFiles"(
    	TestObject object	
     , 	String file	
     , 	Boolean passFileNotFound	) {
    (new uploadFile.uploadFile()).uploadFiles(
        	object
         , 	file
         , 	passFileNotFound)
}


def static "uploadFile.uploadFile.uploadFiles"(
    	TestObject object	
     , 	String fileKey	
     , 	java.util.HashMap<String, String> files	
     , 	Boolean passFileNotFound	) {
    (new uploadFile.uploadFile()).uploadFiles(
        	object
         , 	fileKey
         , 	files
         , 	passFileNotFound)
}


def static "uploadFile.uploadFile.uploadFiles"(
    	TestObject object	
     , 	String file	) {
    (new uploadFile.uploadFile()).uploadFiles(
        	object
         , 	file)
}


def static "uploadFile.uploadFile.uploadFiles"(
    	TestObject object	
     , 	String fileKey	
     , 	java.util.HashMap<String, String> files	) {
    (new uploadFile.uploadFile()).uploadFiles(
        	object
         , 	fileKey
         , 	files)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnHeader"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnHeader(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_BO.getTotalRowPerPage"() {
    (new handleWebTable.HTMLTableHelper_BO()).getTotalRowPerPage()
}


def static "handleWebTable.HTMLTableHelper_BO.verifyListOnTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyListOnTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyListOnTableContainsSpecificValueBO"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyListOnTableContainsSpecificValueBO(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.getTotalListOnTableAllPages"() {
    (new handleWebTable.HTMLTableHelper_BO()).getTotalListOnTableAllPages()
}


def static "handleWebTable.HTMLTableHelper_BO.verifyAscendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyAscendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyDescendingByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyDescendingByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_BO.verifySortedRandomlyByColumnIndex"(
    	String indexOfColumn	
     , 	String typeOfText	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifySortedRandomlyByColumnIndex(
        	indexOfColumn
         , 	typeOfText
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyDateIsMatchWithSearchDate"(
    	String input_dateFrom	
     , 	String input_dateTo	
     , 	List columnIndexes	
     , 	String formatDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyDateIsMatchWithSearchDate(
        	input_dateFrom
         , 	input_dateTo
         , 	columnIndexes
         , 	formatDate)
}


def static "handleWebTable.HTMLTableHelper_BO.checkOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).checkOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.unCheckOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).unCheckOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.checkOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper_BO()).checkOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper_BO.unCheckOnAllRowPerPageByTHeaderCheckbox"() {
    (new handleWebTable.HTMLTableHelper_BO()).unCheckOnAllRowPerPageByTHeaderCheckbox()
}


def static "handleWebTable.HTMLTableHelper_BO.clickEditIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickEditIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickEyeIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickEyeIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDeleteIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDeleteIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDeleteIconOnSpecificRowPayroll"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDeleteIconOnSpecificRowPayroll(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDeleteIconOnSpecificRow_downloadReportMenu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDeleteIconOnSpecificRow_downloadReportMenu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDownloadIconOnSpecificRow_downloadReportMenu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDownloadIconOnSpecificRow_downloadReportMenu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickLockIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickLockIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickUnLockIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickResetIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickResetIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickInActivateIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickResendIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickResendIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickReleaseIconOnSpecificRow_FE_UserMaintenance_Menu(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnHeaderPopUp"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnHeaderPopUp(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyListOnPopUpTableContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyListOnPopUpTableContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.checkOnSpecificRowPopUp"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).checkOnSpecificRowPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.uncheckOnSpecificRowPopUp"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).uncheckOnSpecificRowPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickNameHyperLink"(
    	String data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickNameHyperLink(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickNameHyperLinkPopUp"(
    	String data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickNameHyperLinkPopUp(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayDefaultPackage"(
    	List data	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayDefaultPackage(
        	data
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editAmountTransactionPerDayDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String amount	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editAmountTransactionPerDayDefaultPackage(
        	menuName
         , 	hierarchy
         , 	amount
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionDefaultPackage(
        	menuName
         , 	hierarchy
         , 	min
         , 	max
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String limitValue	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayDefaultPackage(
        	menuName
         , 	hierarchy
         , 	limitValue
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitBusinessDayDefaultPackage"(
    	String menuName	
     , 	String value	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitBusinessDayDefaultPackage(
        	menuName
         , 	value
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourDefaultPackage"(
    	String menuName	
     , 	String startDate	
     , 	String endDate	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourDefaultPackage(
        	menuName
         , 	startDate
         , 	endDate
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitAmountPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String amount	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitAmountPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	amount
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	min
         , 	max
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String startDate	
     , 	String endDate	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourServicePackage(
        	menuName
         , 	productName
         , 	startDate
         , 	endDate
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitBusinessDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String value	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitBusinessDayServicePackage(
        	menuName
         , 	productName
         , 	value
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String limitValue	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	limitValue
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitAmountPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String amount	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitAmountPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	amount
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	min
         , 	max
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String limitValue	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	limitValue
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.accessDetailApprovalMatrix"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).accessDetailApprovalMatrix(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.setOnBusinessDayCustomPackage"(
    	String menuName	
     , 	String product	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).setOnBusinessDayCustomPackage(
        	menuName
         , 	product
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.setOffBusinessDayCustomPackage"(
    	String menuName	
     , 	String product	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).setOffBusinessDayCustomPackage(
        	menuName
         , 	product
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourCustomPackage"(
    	String menuName	
     , 	String product	
     , 	String startDate	
     , 	String endDate	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourCustomPackage(
        	menuName
         , 	product
         , 	startDate
         , 	endDate
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.checkAccountMaxDebitLimit"(
    	String accId	
     , 	String value	) {
    (new handleWebTable.HTMLTableHelper_BO()).checkAccountMaxDebitLimit(
        	accId
         , 	value)
}


def static "handleWebTable.HTMLTableHelper_BO.editUserGroupMaxDebitLimit"(
    	String accId	) {
    (new handleWebTable.HTMLTableHelper_BO()).editUserGroupMaxDebitLimit(
        	accId)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnActionButtonStatus"(
    	String lockstatus	
     , 	String resetstatus	
     , 	String activestatus	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnActionButtonStatus(
        	lockstatus
         , 	resetstatus
         , 	activestatus)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyListOnTableNotContainsSpecificValue"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyListOnTableNotContainsSpecificValue(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.DoubleClickOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).DoubleClickOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.editCorporateRegistrationSTPLimit"(
    	String product	
     , 	String menuName	
     , 	String indiv1	
     , 	String indiv2	
     , 	String corp1	
     , 	String corp2	) {
    (new handleWebTable.HTMLTableHelper_BO()).editCorporateRegistrationSTPLimit(
        	product
         , 	menuName
         , 	indiv1
         , 	indiv2
         , 	corp1
         , 	corp2)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountBankTransactionLimit"(
    	String productName	
     , 	String menuName	
     , 	String hierarchy	
     , 	String currency	
     , 	String min	
     , 	String max	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountBankTransactionLimit(
        	productName
         , 	menuName
         , 	hierarchy
         , 	currency
         , 	min
         , 	max
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.chooseMenuonBankTransactionLimit"(
    	String productName	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).chooseMenuonBankTransactionLimit(
        	productName
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.openPopUponBankTransactionLimit"(
    	String productName	
     , 	String menuName	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).openPopUponBankTransactionLimit(
        	productName
         , 	menuName
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.clickActivateIconOnSpecificRow_AuthenticationDevice"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickActivateIconOnSpecificRow_AuthenticationDevice(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDeActivateIconOnSpecificRow_AuthenticationDevice"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDeActivateIconOnSpecificRow_AuthenticationDevice(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.editAccountOnSpecificRow_AccountMaintenance"(
    	List data	
     , 	String debitvalue	
     , 	String creditvalue	
     , 	String inquiryvalue	) {
    (new handleWebTable.HTMLTableHelper_BO()).editAccountOnSpecificRow_AccountMaintenance(
        	data
         , 	debitvalue
         , 	creditvalue
         , 	inquiryvalue)
}


def static "handleWebTable.HTMLTableHelper_BO.clickEditMenuIconOnSpecificRow"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickEditMenuIconOnSpecificRow(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnContainsSpecificValue"(
    	String input	
     , 	int colIndex	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnContainsSpecificValue(
        	input
         , 	colIndex)
}


def static "handleWebTable.HTMLTableHelper_BO.clickDeleteIconOnSpecificRow_AuthenticationDevice"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickDeleteIconOnSpecificRow_AuthenticationDevice(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.clickEditIconOnSpecificRow_AuthenticationDevice"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).clickEditIconOnSpecificRow_AuthenticationDevice(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.editChargeDefaultPackage"(
    	String productName	
     , 	String chargetype	
     , 	String currency	
     , 	String chargemethod	
     , 	String value	
     , 	String billInstruct	
     , 	String notInclude	) {
    (new handleWebTable.HTMLTableHelper_BO()).editChargeDefaultPackage(
        	productName
         , 	chargetype
         , 	currency
         , 	chargemethod
         , 	value
         , 	billInstruct
         , 	notInclude)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnHeaderJobFrame"(
    	List columnHeaders	
     , 	List objectOnColumnHeaders	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnHeaderJobFrame(
        	columnHeaders
         , 	objectOnColumnHeaders)
}


def static "handleWebTable.HTMLTableHelper_BO.setInputParameterBatch"(
    	String Data	
     , 	String HourMinute	) {
    (new handleWebTable.HTMLTableHelper_BO()).setInputParameterBatch(
        	Data
         , 	HourMinute)
}


def static "handleWebTable.HTMLTableHelper_BO.setInputParameterBatchWeekly"(
    	String Data	
     , 	String HourMinute	) {
    (new handleWebTable.HTMLTableHelper_BO()).setInputParameterBatchWeekly(
        	Data
         , 	HourMinute)
}


def static "handleWebTable.HTMLTableHelper_BO.setInputParameterBatchMonthly"(
    	String Data	
     , 	String HourMinute	) {
    (new handleWebTable.HTMLTableHelper_BO()).setInputParameterBatchMonthly(
        	Data
         , 	HourMinute)
}


def static "handleWebTable.HTMLTableHelper_BO.DoubleClickOnSpecificRowExchangeRateACU"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).DoubleClickOnSpecificRowExchangeRateACU(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.DoubleClickOnSpecificRowExchangeRateDBU"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).DoubleClickOnSpecificRowExchangeRateDBU(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.getRowContentValues"(
    	String value	) {
    (new handleWebTable.HTMLTableHelper_BO()).getRowContentValues(
        	value)
}


def static "handleWebTable.HTMLTableHelper_BO.getSpecificColumnContentValues"(
    	List value	
     , 	String columnIndex	) {
    (new handleWebTable.HTMLTableHelper_BO()).getSpecificColumnContentValues(
        	value
         , 	columnIndex)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnHeader"(
    	List columnHeaders	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnHeader(
        	columnHeaders)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayDefaultPackage"(
    	List data	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayDefaultPackage(
        	data)
}


def static "handleWebTable.HTMLTableHelper_BO.editAmountTransactionPerDayDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String amount	) {
    (new handleWebTable.HTMLTableHelper_BO()).editAmountTransactionPerDayDefaultPackage(
        	menuName
         , 	hierarchy
         , 	amount)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionDefaultPackage(
        	menuName
         , 	hierarchy
         , 	min
         , 	max)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayDefaultPackage"(
    	String menuName	
     , 	String hierarchy	
     , 	String limitValue	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayDefaultPackage(
        	menuName
         , 	hierarchy
         , 	limitValue)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitBusinessDayDefaultPackage"(
    	String menuName	
     , 	String value	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitBusinessDayDefaultPackage(
        	menuName
         , 	value)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourDefaultPackage"(
    	String menuName	
     , 	String startDate	
     , 	String endDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourDefaultPackage(
        	menuName
         , 	startDate
         , 	endDate)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitAmountPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String amount	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitAmountPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	amount)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	min
         , 	max)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String startDate	
     , 	String endDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourServicePackage(
        	menuName
         , 	productName
         , 	startDate
         , 	endDate)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitBusinessDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String value	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitBusinessDayServicePackage(
        	menuName
         , 	productName
         , 	value)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayServicePackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String limitValue	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayServicePackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	limitValue)
}


def static "handleWebTable.HTMLTableHelper_BO.getLimitPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	) {
    (new handleWebTable.HTMLTableHelper_BO()).getLimitPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitAmountPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String amount	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitAmountPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	amount)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountTransactionCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String min	
     , 	String max	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountTransactionCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	min
         , 	max)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitPerDayCustomPackage"(
    	String menuName	
     , 	String productName	
     , 	String hierarchy	
     , 	String limitValue	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitPerDayCustomPackage(
        	menuName
         , 	productName
         , 	hierarchy
         , 	limitValue)
}


def static "handleWebTable.HTMLTableHelper_BO.setOnBusinessDayCustomPackage"(
    	String menuName	
     , 	String product	) {
    (new handleWebTable.HTMLTableHelper_BO()).setOnBusinessDayCustomPackage(
        	menuName
         , 	product)
}


def static "handleWebTable.HTMLTableHelper_BO.setOffBusinessDayCustomPackage"(
    	String menuName	
     , 	String product	) {
    (new handleWebTable.HTMLTableHelper_BO()).setOffBusinessDayCustomPackage(
        	menuName
         , 	product)
}


def static "handleWebTable.HTMLTableHelper_BO.editLimitServiceHourCustomPackage"(
    	String menuName	
     , 	String product	
     , 	String startDate	
     , 	String endDate	) {
    (new handleWebTable.HTMLTableHelper_BO()).editLimitServiceHourCustomPackage(
        	menuName
         , 	product
         , 	startDate
         , 	endDate)
}


def static "handleWebTable.HTMLTableHelper_BO.editMinMaxAmountBankTransactionLimit"(
    	String productName	
     , 	String menuName	
     , 	String hierarchy	
     , 	String currency	
     , 	String min	
     , 	String max	) {
    (new handleWebTable.HTMLTableHelper_BO()).editMinMaxAmountBankTransactionLimit(
        	productName
         , 	menuName
         , 	hierarchy
         , 	currency
         , 	min
         , 	max)
}


def static "handleWebTable.HTMLTableHelper_BO.chooseMenuonBankTransactionLimit"(
    	String productName	) {
    (new handleWebTable.HTMLTableHelper_BO()).chooseMenuonBankTransactionLimit(
        	productName)
}


def static "handleWebTable.HTMLTableHelper_BO.openPopUponBankTransactionLimit"(
    	String productName	
     , 	String menuName	) {
    (new handleWebTable.HTMLTableHelper_BO()).openPopUponBankTransactionLimit(
        	productName
         , 	menuName)
}


def static "handleWebTable.HTMLTableHelper_BO.editChargeDefaultPackage"(
    	String productName	
     , 	String chargetype	
     , 	String currency	
     , 	String chargemethod	
     , 	String value	
     , 	String billInstruct	) {
    (new handleWebTable.HTMLTableHelper_BO()).editChargeDefaultPackage(
        	productName
         , 	chargetype
         , 	currency
         , 	chargemethod
         , 	value
         , 	billInstruct)
}


def static "handleWebTable.HTMLTableHelper_BO.verifyColumnHeaderJobFrame"(
    	List columnHeaders	) {
    (new handleWebTable.HTMLTableHelper_BO()).verifyColumnHeaderJobFrame(
        	columnHeaders)
}


def static "get.UniqueScreenShot.takeScreenShot"(
    	String path	
     , 	String name	) {
    (new get.UniqueScreenShot()).takeScreenShot(
        	path
         , 	name)
}


def static "keys.scrollElementAdjusted.scrollIntoElementWithOffset"(
    	TestObject targetedElement	
     , 	int YOffset	
     , 	int XOffset	) {
    (new keys.scrollElementAdjusted()).scrollIntoElementWithOffset(
        	targetedElement
         , 	YOffset
         , 	XOffset)
}


def static "keys.scrollElementAdjusted.scrollIntoElementWithOffset"(
    	TestObject targetedElement	
     , 	int YOffset	) {
    (new keys.scrollElementAdjusted()).scrollIntoElementWithOffset(
        	targetedElement
         , 	YOffset)
}


def static "keys.scrollElementAdjusted.scrollIntoElementWithOffset"(
    	TestObject targetedElement	) {
    (new keys.scrollElementAdjusted()).scrollIntoElementWithOffset(
        	targetedElement)
}


def static "verification.Verify.verifyFileIsDownloaded"(
    	String fileName	) {
    (new verification.Verify()).verifyFileIsDownloaded(
        	fileName)
}


def static "verification.Verify.verifyFilePartialNameString"(
    	String fileName	) {
    (new verification.Verify()).verifyFilePartialNameString(
        	fileName)
}


def static "approvalMatrix.setApprovalMatrix2A0R.runsetApprovalMatrix2A0R"() {
    (new approvalMatrix.setApprovalMatrix2A0R()).runsetApprovalMatrix2A0R()
}


def static "webDatabase.Kicker.releaseLoginFO"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.Kicker()).releaseLoginFO(
        	userId
         , 	corpId)
}


def static "webDatabase.Kicker.unlockLoginFO"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.Kicker()).unlockLoginFO(
        	userId
         , 	corpId)
}


def static "webDatabase.Kicker.activeFO"(
    	String userId	
     , 	String corpId	) {
    (new webDatabase.Kicker()).activeFO(
        	userId
         , 	corpId)
}


def static "webDatabase.Kicker.releaseLoginBO"(
    	String userId	) {
    (new webDatabase.Kicker()).releaseLoginBO(
        	userId)
}


def static "webDatabase.Kicker.unlockLoginBO"(
    	String userId	) {
    (new webDatabase.Kicker()).unlockLoginBO(
        	userId)
}


def static "webDatabase.Kicker.activeBO"(
    	String userId	) {
    (new webDatabase.Kicker()).activeBO(
        	userId)
}
